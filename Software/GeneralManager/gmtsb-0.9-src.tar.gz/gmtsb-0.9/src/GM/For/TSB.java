/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package GM.For;

import org.twofoos.gmtsb.gui.Main;

/**
 * Stub entry point for the application so as to set the application name to
 * something reasonable. I've found an answer on Linux that doesn't involve this
 * hack, but I'm keeping this as a backup and for Macs. (I haven't checked what
 * Windows does yet.)
 * <p>
 * <strong>The hack:</strong> Unix-y {@link java.awt.Toolkit} implementations
 * use the class containing main() as the application name, as described in <a
 * href="http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4805690">Sun bug
 * 4805690</a>. (Personal experience, as well as naive examination of the
 * bytecode, confirm this.)
 * 
 * @see sun.awt.motif.MToolkit
 * @see sun.awt.X11.XToolkit
 */
public class TSB
{
  public static void main(String[] args) throws Exception
  {
    Main.main(args);
  }
}
