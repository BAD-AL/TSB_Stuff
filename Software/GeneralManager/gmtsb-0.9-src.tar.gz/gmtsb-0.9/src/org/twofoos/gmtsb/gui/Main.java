/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui;

import static javax.swing.UIManager.getSystemLookAndFeelClassName;
import static javax.swing.UIManager.setLookAndFeel;
import static org.twofoos.gmtsb.gui.MainFrame.createAndShowNewMainFrame;
import static org.twofoos.gmtsb.gui.MainFrame.openFirst;
import static org.twofoos.gmtsb.gui.util.MacApplication.initMacLookAndFeelProperties;

import java.awt.Toolkit;
import java.io.File;
import java.lang.reflect.Field;

import org.twofoos.gmtsb.core.Appearance;
import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.AttributeList;
import org.twofoos.gmtsb.core.AttributeValue;
import org.twofoos.gmtsb.core.Depth;
import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.Formation;
import org.twofoos.gmtsb.core.IncompatiblePositionsException;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.OffensiveFormation;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.Slot;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.file.NesFile;
import org.twofoos.gmtsb.file.NesFileFormatException;
import org.twofoos.gmtsb.file.SupplementFileFormatException;
import org.twofoos.gmtsb.file.SupplementedNesFile;
import org.twofoos.gmtsb.file.TsbFile;
import org.twofoos.gmtsb.gui.dnd.SimpleDragMouseMotionListener;
import org.twofoos.gmtsb.gui.dnd.SimpleTransferHandler;
import org.twofoos.gmtsb.gui.player.AttributeSpinner;
import org.twofoos.gmtsb.gui.player.DepthPanel;
import org.twofoos.gmtsb.gui.player.FaceButton;
import org.twofoos.gmtsb.gui.player.FaceChooserPanel;
import org.twofoos.gmtsb.gui.player.Faces;
import org.twofoos.gmtsb.gui.player.PlayerPanel;
import org.twofoos.gmtsb.gui.player.TeamFrame;
import org.twofoos.gmtsb.gui.team.DivisionPanel;
import org.twofoos.gmtsb.gui.team.LeagueFrame;
import org.twofoos.gmtsb.gui.team.LogoButton;
import org.twofoos.gmtsb.gui.team.TeamPanel;
import org.twofoos.gmtsb.gui.team.chooser.PlayerDataColorChooserPanel;
import org.twofoos.gmtsb.gui.team.chooser.SpriteColorChooser;
import org.twofoos.gmtsb.gui.util.ComponentScalar;
import org.twofoos.gmtsb.gui.util.ComponentSizeIncrementScrollPane;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.gui.util.UpperCaseTextField;
import org.twofoos.gmtsb.userevent.UndoHandler;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.UserEventAggregator;
import org.twofoos.gmtsb.userevent.UserEventListener;
import org.twofoos.gmtsb.userevent.extrinsic.CopyEvent;
import org.twofoos.gmtsb.userevent.extrinsic.CreateEvent;
import org.twofoos.gmtsb.userevent.extrinsic.DeleteEvent;
import org.twofoos.gmtsb.userevent.extrinsic.ExtrinsicEvent;
import org.twofoos.gmtsb.userevent.extrinsic.MoveEvent;
import org.twofoos.gmtsb.userevent.extrinsic.SwapEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.MergeableIntrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.AppearanceChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.AttributeChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.FirstNameChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.LastNameChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.UniformNumberChangeEvent;
import org.twofoos.gmtsb.util.CollectionUtilities;
import org.twofoos.gmtsb.util.iterators.AbstractMapper;
import org.twofoos.gmtsb.util.iterators.Mapper;
import org.twofoos.gmtsb.util.iterators.Pair;
import org.twofoos.gmtsb.util.iterators.Range;

public class Main
{
  // TODO proper error-handling
  public static void main(String[] args) throws Exception
  {
    setApplicationNameIfPossible("GM for TSB");

    try
    {
      // TODO test this on Windows
      setLookAndFeel(getSystemLookAndFeelClassName());
    }
    catch(Exception e)
    {
    }

    initMacLookAndFeelProperties();

    if(args.length > 2)
    {
      System.err.println("Too many arguments.");
      System.err
          .println("  No arguments: program prompts for a ROM file and supplement to open");
      System.err.println("  One argument: program opens given ROM file");
      System.err
          .println("  Two arguments: program opens given ROM file and supplement file");
      System.exit(1);
    }
    else if(args.length == 0)
    {
      openFirst();
    }
    else
    {
      File nesFile = new File(args[0]);
      File tsbsupFile = null;

      if(args.length == 2)
      {
        tsbsupFile = new File(args[1]);
      }

      createAndShowNewMainFrame(new SupplementedNesFile(nesFile, tsbsupFile));
    }

    // This is probably the fastest, simplest way to make sure all are loaded.
    @SuppressWarnings("unused")
    Class<?> c;

    // TODO update list of classes
    c = Appearance.class;
    c = Attribute.class;
    c = AttributeList.class;
    c = AttributeValue.class;
    c = Depth.class;
    c = Division.class;
    c = Formation.class;
    c = IncompatiblePositionsException.class;
    c = League.class;
    c = OffensiveFormation.class;
    c = Player.class;
    c = Position.class;
    c = Slot.class;
    c = Team.class;

    c = NesFile.class;
    c = NesFileFormatException.class;
    c = SupplementedNesFile.class;
    c = SupplementFileFormatException.class;
    c = TsbFile.class;

    c = AttributeSpinner.class;
    c = ComponentScalar.class;
    c = ComponentSizeIncrementScrollPane.class;
    c = DepthPanel.class;
    c = DivisionPanel.class;
    c = FaceButton.class;
    c = FaceChooserPanel.class;
    c = Faces.class;
    c = GUIUtils.class;
    c = InternalFrame.class;
    c = LeagueFrame.class;
    c = LogoButton.class;
    c = Main.class;
    c = MainFrame.class;
    c = MainMenuBar.class;
    c = PlayerPanel.class;
    c = SimpleDragMouseMotionListener.class;
    c = SimpleTransferHandler.class;
    c = TeamFrame.class;
    c = TeamPanel.class;
    c = UpperCaseTextField.class;

    c = AppearanceChangeEvent.class;
    c = AttributeChangeEvent.class;
    c = FirstNameChangeEvent.class;
    c = LastNameChangeEvent.class;
    c = MergeableIntrinsicEvent.class;
    c = CopyEvent.class;
    c = CreateEvent.class;
    c = DeleteEvent.class;
    c = IntrinsicEvent.class;
    c = ExtrinsicEvent.class;
    c = MoveEvent.class;
    c = SwapEvent.class;
    c = UndoHandler.class;
    c = UniformNumberChangeEvent.class;
    c = UserEvent.class;
    c = UserEventAggregator.class;
    c = UserEventListener.class;

    c = CollectionUtilities.class;

    c = AbstractMapper.class;
    c = Mapper.class;
    c = Pair.class;
    c = Range.class;

    c = SpriteColorChooser.class;
    c = PlayerDataColorChooserPanel.class;
  }

  // http://elliotth.blogspot.com/2007/02/fixing-wmclass-for-your-java.html
  private static void setApplicationNameIfPossible(String applicationName)
  {
    try
    {
      Toolkit xToolkit = Toolkit.getDefaultToolkit();
      Field awtAppClassNameField =
          xToolkit.getClass().getDeclaredField("awtAppClassName");
      awtAppClassNameField.setAccessible(true);
      awtAppClassNameField.set(xToolkit, applicationName);
    }
    catch(Throwable t)
    {
    }
  }
}
