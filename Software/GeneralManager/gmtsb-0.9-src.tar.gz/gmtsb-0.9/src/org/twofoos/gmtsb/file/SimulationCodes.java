/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.file;

import static org.twofoos.gmtsb.core.Attribute.MS;
import static org.twofoos.gmtsb.core.AttributeValue._50;
import static org.twofoos.gmtsb.file.NesFile.byteIntoNybbles;
import static org.twofoos.gmtsb.file.SupplementedNesFile.PLAYERS_PER_TEAM_COUNT;
import static org.twofoos.gmtsb.file.TsbFile.TEAM_SIMULATION_CODE_SIZE_NYBBLES;
import static org.twofoos.gmtsb.file.TsbFile.TOTAL_SIMULATION_CODE_SIZE_NYBBLES;
import static org.twofoos.gmtsb.util.MathUtilities.indexOfMax;
import static org.twofoos.gmtsb.util.MathUtilities.nonneg;
import static org.twofoos.gmtsb.util.MathUtilities.sum;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.AttributeList;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Slot;
import org.twofoos.gmtsb.util.CollectionUtilities;

import com.google.common.collect.ImmutableList;

class SimulationCodes
{
  private final byte[] allSimulationBytes;

  SimulationCodes(List<Player> nesPlayers)
  {
    // Don't trash the original list.
    nesPlayers = new ArrayList<Player>(nesPlayers);

    allSimulationBytes = new byte[TOTAL_SIMULATION_CODE_SIZE_NYBBLES];

    for(int i = 0; i < League.NES_TEAMS_COUNT; i++)
    {
      List<Player> teamPlayers =
          CollectionUtilities.removeFirstN(nesPlayers, PLAYERS_PER_TEAM_COUNT);

      byte[] teamSimulationBytes =
          new TeamSimulationCodes(teamPlayers).getSimulationBytes();

      System.arraycopy(teamSimulationBytes, 0, allSimulationBytes, i
          * teamSimulationBytes.length, teamSimulationBytes.length);
    }
  }

  void writeSimulationBytes(TsbFile tsbFile) throws IOException
  {
    tsbFile.seek(tsbFile.SIMULATION_CODE_LOCATION);
    tsbFile.writeNybbles(allSimulationBytes);
  }

  static class TeamSimulationCodes
  {
    private final byte[] teamSimulationBytes;

    private static List<Player> getDefenders(List<Player> teamPlayers)
    {
      return teamPlayers.subList(17, 28);
    }

    private TeamSimulationCodes(List<Player> teamPlayers)
    {
      teamSimulationBytes = new byte[TEAM_SIMULATION_CODE_SIZE_NYBBLES];

      for(int i = 0; i < 2; i++)
      {
        Player player = teamPlayers.get(i);
        teamSimulationBytes[i * 4] = round(calculateQBRush(player));
        teamSimulationBytes[i * 4 + 1] = round(calculateQBPass(player));
        teamSimulationBytes[i * 4 + 3] = round(calculatePocket(player));
      }

      Player qb = teamPlayers.get(0);

      for(int i = 0; i < 10; i++)
      {
        Player player = teamPlayers.get(2 + i);

        teamSimulationBytes[i * 4 + 8] = round(calculateBCRush(player));
        teamSimulationBytes[i * 4 + 9] = round(calculateBCRec(player, qb));
        teamSimulationBytes[i * 4 + 10] = round(calculatePR(player));
        teamSimulationBytes[i * 4 + 11] = round(calculateKR(player, i));
      }

      byte[] allSacking = calculateSacks(getDefenders(teamPlayers));
      byte[] allIntercept = calculateInts(getDefenders(teamPlayers));
      for(int i = 0; i < DEFENDER_COUNT; i++)
      {
        // It's kind of silly to convert these into nybbles when they'll just be
        // converted back for writing, but it's easiest to translate the old
        // reader code into writer code this way. (Not that that code looked any
        // nicer.)
        byteIntoNybbles(allSacking[i], teamSimulationBytes, i * 2 + 48);
        byteIntoNybbles(allIntercept[i], teamSimulationBytes, i * 2 + 70);
      }

      for(int i = 0; i < 2; i++)
      {
        Player player = teamPlayers.get(28 + i);
        teamSimulationBytes[92 + i] =
            round(i == 0 ? calculateKick(player) : calculatePunt(player));
      }

      teamSimulationBytes[94] = calculateOffense(teamPlayers);
      teamSimulationBytes[95] = calculateDefense(teamPlayers);
    }

    private byte[] getSimulationBytes()
    {
      return teamSimulationBytes;
    }

    private static final int DEFENDER_COUNT = 11;
    private static final int SCALED_TOTAL = 255;

    static final Slot NT = Slot.NT;
    static final Slot DE = Slot.LDE;
    static final Slot ILB = Slot.LILB;
    static final Slot OLB = Slot.LOLB;
    static final Slot CB = Slot.LCB;
    static final Slot S = Slot.FS;
    static final ImmutableList<Slot> GENERAL_SLOTS =
        ImmutableList.of(NT, DE, ILB, OLB, CB, S);

    static Slot getLongPositionFromIndex(int i)
    {
      return i == 0 || i == 2 ? DE : i == 1 ? NT : i == 3 || i == 6 ? OLB
          : i == 4 || i == 5 ? ILB : i == 7 || i == 8 ? CB : S;
    }

    /**
     * Also makes sure the value is in [0, 16).
     */
    private byte round(double d)
    {
      long l = Math.round(d);
      byte b = (byte) l;

      if(b < 0)
      {
        b = 0;
      }
      else if(b > 15)
      {
        b = 15;
      }

      return b;
    }

    private int getAttribute(Player player, Attribute attribute)
    {
      return player.getAttribute(attribute).getComputerValue();
    }

    private double calculateQBRush(Player player)
    {
      int ms = getAttribute(player, Attribute.MS);

      return 1.0588 * ms + 1.2542;
    }

    private double calculateQBPass(Player player)
    {
      int ps = getAttribute(player, Attribute.PS);
      int pc = getAttribute(player, Attribute.PC);
      int pa = getAttribute(player, Attribute.PA);
      int ar = getAttribute(player, Attribute.AR);

      return 0.0789 * ps + 0.2227 * pc + 0.6584 * pa + 0.2426 * ar + -2.7443;
    }

    private double calculatePocket(Player player)
    {
      int ms = getAttribute(player, Attribute.MS);
      int ps = getAttribute(player, Attribute.PS);
      int pc = getAttribute(player, Attribute.PC);
      int pa = getAttribute(player, Attribute.PA);
      int ar = getAttribute(player, Attribute.AR);

      return -0.3942 * ms + 0.0202 * ps + 0.0494 * pc + 0.0251 * pa + 0.0318
          * ar + 1.7642;
    }

    private double calculateBCRush(Player player)
    {
      int rs = getAttribute(player, Attribute.RS);
      int ms = getAttribute(player, Attribute.MS);
      int hp = getAttribute(player, Attribute.HP);

      // ~ slow receivers
      if(rs <= 4 && ms <= 3)
      {
        return 0.0332 * rs + 0.059 * ms + 0.0222 * hp + 0.6772;
      }

      // ~ fullbacks
      if(hp >= 2 && ms <= 5)
      {
        return 0.9962 * rs + 0.1473 * ms + 0.1019 * hp - 2.6414;
      }

      // ~ receivers
      if(hp <= 1)
      {
        return 0.128 * ms + 0.0725 * hp + 0.7139;
      }

      // ~ halfbacks
      return 0.7927 * rs + 1.4848 * ms - 8.6986;
    }

    private double calculateBCRec(Player player, Player qb)
    {
      int rec = getAttribute(player, Attribute.Rec);
      int qbPC = getAttribute(qb, Attribute.PC);
      int qbPA = getAttribute(qb, Attribute.PA);
      int qbAR = getAttribute(qb, Attribute.AR);

      return 0.787 * rec + 0.0412 * qbPC + 0.1547 * qbPA + 0.108 * qbAR
          + -2.703;
    }

    private byte[] bytes(int[] ints)
    {
      byte[] bytes = new byte[ints.length];

      for(int i = 0; i < ints.length; i++)
      {
        bytes[i] = (byte) ints[i];
      }

      return bytes;
    }

    private byte[] normalize(double[] unscaled)
    {
      // TODO comments
      double unscaledTotal = sum(unscaled);
      double multiplier = SCALED_TOTAL / unscaledTotal;

      int[] wholes = new int[DEFENDER_COUNT];
      double[] remainders = new double[DEFENDER_COUNT];

      int currentTotal = 0;

      for(int i = 0; i < DEFENDER_COUNT; i++)
      {
        double quotient = unscaled[i] * multiplier;
        wholes[i] = (int) quotient;
        remainders[i] = quotient - wholes[i];
        currentTotal += wholes[i];
      }

      while(currentTotal < SCALED_TOTAL)
      {
        int index = indexOfMax(remainders);
        remainders[index] = 0;
        wholes[index]++;
        currentTotal++;
      }

      return bytes(wholes);
    }

    private double[] calculateUnscaledSacks(List<Player> players)
    {
      double[] unscaled = new double[DEFENDER_COUNT];

      for(int i = 0; i < DEFENDER_COUNT; i++)
      {
        Player player = players.get(i);
        Slot slot = getLongPositionFromIndex(i);

        int rs = getAttribute(player, Attribute.RS);
        int rp = getAttribute(player, Attribute.RP);
        int ms = getAttribute(player, Attribute.MS);
        int hp = getAttribute(player, Attribute.HP);
        int intercept = getAttribute(player, Attribute.Int);

        if(slot == ILB || slot == NT || slot == OLB || slot == DE)
        {
          // Front seven.
          unscaled[i] =
              12.9688 * rs - 1.9835 * rp + 5.8191 * ms + 0.1677 * hp - 2.4554
                  * intercept
                  + ((slot == NT || slot == OLB || slot == DE) ? 15.3936 : 0)
                  + ((slot == OLB || slot == DE) ? 12.0997 : 0) - 47.8889;
        }
        else
        {
          // Defensive backs.
          // Obviously the parts of this referring to DL and LB slots don't
          // matter, but I want to keep the formula here as close to what Weka
          // spit out as possible.
          unscaled[i] =
              -0.2225
                  * rs
                  + 0.4138
                  * rp
                  + 0.2786
                  * hp
                  - 0.3144
                  * intercept
                  + ((slot == S || slot == ILB || slot == NT || slot == OLB || slot == DE) ? 3.9041
                      : 0)
                  + ((slot == NT || slot == OLB || slot == DE) ? 0.9336 : 0)
                  + ((slot == OLB || slot == DE) ? 2.4582 : 0) + 2.0002;
        }

        unscaled[i] = nonneg(unscaled[i]);
      }

      return unscaled;
    }

    private byte[] calculateSacks(List<Player> players)
    {
      return normalize(calculateUnscaledSacks(players));
    }

    private double[] calculateUnscaledInts(List<Player> players)
    {
      double[] unscaled = new double[DEFENDER_COUNT];

      for(int i = 0; i < DEFENDER_COUNT; i++)
      {
        Player player = players.get(i);
        Slot slot = getLongPositionFromIndex(i);

        int rp = getAttribute(player, Attribute.RP);
        int hp = getAttribute(player, Attribute.HP);
        int intercept = getAttribute(player, Attribute.Int);

        unscaled[i] =
            nonneg(1.7862 * rp + -1.0504 * hp + 7.7233 * intercept
                + ((slot == CB || slot == S) ? 10.3394 : 0) + -14.5964);
      }

      return unscaled;
    }

    private byte[] calculateInts(List<Player> players)
    {
      return normalize(calculateUnscaledInts(players));
    }

    private double calculateKick(Player player)
    {
      int ka = getAttribute(player, Attribute.KA);

      return 0.9785 * ka + 0.2593;
    }

    private double calculatePunt(Player player)
    {
      int ka = getAttribute(player, Attribute.KA);

      return 0.971 * ka + 0.2609;
    }

    private double calculatePR(Player player)
    {
      int rs = getAttribute(player, Attribute.RS);
      int ms = getAttribute(player, Attribute.MS);
      int hp = getAttribute(player, Attribute.HP);
      int bc = getAttribute(player, Attribute.BC);

      // ~ running backs
      if(hp >= 2)
      {
        return -0.47 * rs + 0.2992 * ms + 0.1049 * hp + 0.0104 * bc + 6.3731;
      }

      // ~ receivers
      return -0.9047 * rs + 1.0145 * ms + 0.1534 * bc + 6.3571;
    }

    private double calculateKR(Player player, int index)
    {
      int rs = getAttribute(player, Attribute.RS);
      int ms = getAttribute(player, Attribute.MS);
      int hp = getAttribute(player, Attribute.HP);
      boolean isStarter = isStarter(index);

      // = backups
      if(!isStarter)
      {
        return -0.1659 * rs - 0.1458 * hp + 2.5542;
      }

      // ~ starting running backs
      if(hp >= 2)
      {
        return -0.3319 * rs + 0.258 * ms + 0.0865 * hp + 3.5282;
      }

      // ~ starting receivers
      return 0.4916 * ms + 4.7448;
    }

    private boolean isStarter(int i)
    {
      return !isBackup(i);
    }

    private boolean isBackup(int i)
    {
      // TODO use Formation methods, but keep in mind that these indexes start
      // with the RB, not the QB...
      return (i == 2 || i == 3 || i == 6 || i == 7 || i == 9);
    }

    private byte calculateOffense(List<Player> teamPlayers)
    {
      double qb = calculateQBPass(teamPlayers.get(0));

      int olTotal = 0;
      for(int i = 12; i < 17; i++)
      {
        Player player = teamPlayers.get(i);
        for(Attribute a : AttributeList.OL_ATTRIBUTES)
        {
          olTotal += player.getAttribute(a).getComputerValue();
        }
      }

      double offenseTotal = 0;

      for(int i = 0; i < 10; i++)
      {
        Player player = teamPlayers.get(2 + i);
        // Ignoring backups is worse; counting them as 0.25 is as good as
        // counting them at full value, which is what we do.
        // Also, weighting receivers' Rec and RB's Rush more heavily actually
        // hurts a little and has the additional annoying effect of making the
        // correlation with the result negative.
        offenseTotal += calculateBCRush(player);
        offenseTotal += calculateBCRec(player, teamPlayers.get(0));
      }

      double result =
          0.7651 * qb + 0.165 * olTotal + 0.0223 * offenseTotal + -19.4991;

      if(teamPlayers.get(0).getAttribute(MS).compareTo(_50) >= 0)
      {
        // Bump Eagles from 6 to 10, putting them in line with the Bengals, who
        // are basically the same team except with a solid RB pair instead of a
        // fast QB. Of course, the ROM has the Bengals rated at 5, the worst the
        // Tecmo people underrated any team if this formula is to be believed.
        // Still, they have the Eagles rated a 14, higher than anyone but the
        // 49ers, which is almost surely inaccurate.
        result += 4;
      }

      return round(result);
    }

    private byte calculateDefense(List<Player> teamPlayers)
    {
      int Int = 0;

      for(int i = 3; i < DEFENDER_COUNT; i++)
      {
        Int += getAttribute(teamPlayers, Attribute.Int, i);
      }

      /*
       * LDE actually represents all DE's, and the same is true of other
       * positions.
       */
      int NT_HP = getAttribute(teamPlayers, Attribute.HP, 1);
      int LDE_HP = getAttribute(teamPlayers, Attribute.HP, 0, 2);
      int LILB_HP = getAttribute(teamPlayers, Attribute.HP, 4, 5);
      int LOLB_MS = getAttribute(teamPlayers, Attribute.MS, 3, 6);
      int FS_HP = getAttribute(teamPlayers, Attribute.HP, 9, 10);

      double value = 0.3129 * NT_HP + //
          0.5495 * LDE_HP + //
          0.1432 * LILB_HP + //
          0.6188 * LOLB_MS + //
          0.4442 * FS_HP + //
          0.1501 * Int + //
          -23.8087;

      return round(value);
    }

    private int getAttribute(List<Player> teamPlayers, Attribute attribute,
        int... defensivePlayerIndexes)
    {
      int value = 0;
      for(int index : defensivePlayerIndexes)
      {
        value +=
            teamPlayers.get(17 + index).getAttribute(attribute)
                .getComputerValue();
      }
      return value;
    }
  }
}
