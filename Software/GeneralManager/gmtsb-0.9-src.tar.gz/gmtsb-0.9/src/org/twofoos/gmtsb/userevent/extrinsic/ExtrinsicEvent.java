/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.extrinsic;

import java.util.List;

import org.twofoos.gmtsb.core.Depth;
import org.twofoos.gmtsb.core.IncompatiblePositionsException;
import org.twofoos.gmtsb.userevent.UserEvent;

public abstract class ExtrinsicEvent implements UserEvent
{
  protected static void testDepthPositionCompatibility(Depth depth1,
      Depth depth2) throws IncompatiblePositionsException
  {
    // We must check for position compatibility ahead of time, even though the
    // addPlayer method will check for it, because we don't want to remove the
    // players and then die with an exception before they are added again.
    if(!depth1.isCompatibleWith(depth2))
    {
      throw new IncompatiblePositionsException(
          "depths have different attributes: " + depth1 + ", " + depth2);
    }
  }

  protected static void possiblyTestDepthPositionCompatibility(List<?> depth1,
      List<?> depth2) throws IncompatiblePositionsException
  {
    // TODO better way of doing this?
    if(depth1 instanceof Depth && depth2 instanceof Depth)
    {
      testDepthPositionCompatibility((Depth) depth1, (Depth) depth2);
    }
  }

  public abstract boolean isListAffected(List<?> list);

  public abstract boolean isTeamEvent();
}
