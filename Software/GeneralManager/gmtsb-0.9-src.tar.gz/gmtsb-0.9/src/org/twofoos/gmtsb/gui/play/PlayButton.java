/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.play;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.core.play.Page;
import org.twofoos.gmtsb.core.play.Play;
import org.twofoos.gmtsb.core.play.Playbook;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.PlayChangeEvent;

class PlayButton extends JButton implements ActionListener
{
  private static final long serialVersionUID = -8570373401972704320L;

  private final PlaybookDialog playbookDialog;
  private final Page page;

  PlayButton(PlaybookDialog playbookDialog, Page page)
  {
    this.playbookDialog = playbookDialog;
    this.page = page;

    addActionListener(this);

    updateTeamAndPlay();
  }

  private Team getTeam()
  {
    return playbookDialog.getTeam();
  }

  private MainFrame getMainFrame()
  {
    return playbookDialog.getMainFrame();
  }

  private League getLeague()
  {
    return playbookDialog.getLeague();
  }

  private Playbook getPlaybook()
  {
    return getTeam().getPlaybook();
  }

  private Play getPlay()
  {
    return getPlaybook().get(page);
  }

  public void performAndPublish(UserEvent e)
  {
    getMainFrame().performAndPublish(e);
  }

  void updateTeamAndPlay()
  {
    removeAll();
    PlayGraphics playGraphics = new PlayGraphics(getTeam(), getPlay());
    playGraphics.setOpaque(false);
    add(playGraphics);
    revalidate();
  }

  void playInPageUpdated(Page page)
  {
    if(page == this.page)
    {
      updateTeamAndPlay();
    }
  }

  public void actionPerformed(ActionEvent e)
  {
    Play result =
        PlayChooserPanel.showDialog(getMainFrame(), getLeague().getBinder()
            .getPlaysByPage(page), getPlay(), getTeam());

    if(result == null)
    {
      return;
    }

    performAndPublish(new PlayChangeEvent(getTeam(), page, getTeam()
        .getPlaybook().get(page), result));
  }
}
