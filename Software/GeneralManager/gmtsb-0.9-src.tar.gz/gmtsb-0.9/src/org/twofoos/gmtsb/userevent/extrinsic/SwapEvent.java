/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.extrinsic;

import java.util.List;

import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.IncompatiblePositionsException;
import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.userevent.UserEvent;

/**
 * A "trade," though it could be an intra-team "trade."
 */
public class SwapEvent<D extends TSBTransferableData<D>> extends ExtrinsicEvent
{
  private final List<D> list1;
  private final List<D> list2;
  private final int index1;
  private final int index2;
  private final String name1;
  private final String name2;

  private SwapEvent(List<D> list1, int index1, List<D> list2, int index2)
  {
    this.list1 = list1;
    this.list2 = list2;
    this.index1 = index1;
    this.index2 = index2;
    this.name1 = list1.get(index1).toString();
    this.name2 = list2.get(index2).toString();
  }

  // Not using a public constructor only to be consistent with PlayerMoveEvent.
  public static <D extends TSBTransferableData<D>> SwapEvent<D> createSwapEvent(
      List<D> list1, int index1, List<D> list2, int index2)
  {
    return new SwapEvent<D>(list1, index1, list2, index2);
  }

  // Not using a public constructor only to be consistent with PlayerMoveEvent.
  public static <D extends TSBTransferableData<D>> SwapEvent<D> createSwapEvent(
      List<D> list1, D data1, List<D> list2, D data2)
  {
    return new SwapEvent<D>(list1, list1.indexOf(data1), list2, list2
        .indexOf(data2));
  }

  public boolean doEvent() throws IncompatiblePositionsException
  {
    // See note at testPositionCompatibility() method.
    possiblyTestDepthPositionCompatibility(list1, list2);

    D data1 = list1.get(index1);
    D data2 = list2.get(index2);

    list1.set(index1, data2);
    list2.set(index2, data1);

    return true;
  }

  public void undoEvent()
  {
    // Swapping again undoes the swap.
    doEvent();
  }

  public String getDescription()
  {
    return "Swap " + name1 + " and " + name2;
  }

  @Override
  public boolean isListAffected(List<?> list)
  {
    return list == list1 || list == list2;
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }

  // javac rejects without the cast
  @SuppressWarnings("cast")
  @Override
  public boolean isTeamEvent()
  {
    return (Object) list1 instanceof Division;
  }
}
