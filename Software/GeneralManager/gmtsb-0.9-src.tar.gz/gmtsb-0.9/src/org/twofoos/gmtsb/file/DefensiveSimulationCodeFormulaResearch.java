/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.file;

import static com.google.common.base.Join.join;
import static com.google.common.collect.Iterables.concat;
import static com.google.common.collect.Lists.newArrayList;
import static org.twofoos.gmtsb.core.League.NES_TEAMS_COUNT;
import static org.twofoos.gmtsb.file.SimulationCodes.TeamSimulationCodes.CB;
import static org.twofoos.gmtsb.file.SimulationCodes.TeamSimulationCodes.DE;
import static org.twofoos.gmtsb.file.SimulationCodes.TeamSimulationCodes.ILB;
import static org.twofoos.gmtsb.file.SimulationCodes.TeamSimulationCodes.NT;
import static org.twofoos.gmtsb.file.SimulationCodes.TeamSimulationCodes.OLB;
import static org.twofoos.gmtsb.file.SimulationCodes.TeamSimulationCodes.S;
import static org.twofoos.gmtsb.file.SimulationCodes.TeamSimulationCodes.getLongPositionFromIndex;
import static org.twofoos.gmtsb.file.TsbFile.TEAM_SIMULATION_CODE_SIZE_NYBBLES;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.Slot;
import org.twofoos.gmtsb.core.Team;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMultimapBuilder;
import com.google.common.collect.Multimap;

class DefensiveSimulationCodeFormulaResearch
{
  /*
   * I keep getting a negative correlation for safety Int, but it goes away if I
   * split FS and SS. Granted, it's still not a positive correlation, so I could
   * just add it to the IGNORED list, but it may be a sign that Tecmo
   * distinguishes between the two (or not). (Wait, no, it doesn't go away.
   * Maybe it will later.)
   */
  private static final ImmutableList<Slot> GENERAL_SLOTS;
  static
  {
    // List<Slot> slots =
    // newArrayList(SimulationCodes.TeamSimulationCodes.GENERAL_SLOTS);
    // slots.add(Slot.SS);
    // GENERAL_SLOTS = ImmutableList.copyOf(slots);
    GENERAL_SLOTS = SimulationCodes.TeamSimulationCodes.GENERAL_SLOTS;
  }

  private static Slot getGeneralSlot(int playerIndex)
  {
    return getLongPositionFromIndex(playerIndex);
    // return playerIndex == 10 ? Slot.SS : playerIndex == 9 ? Slot.FS
    // : getLongPositionFromIndex(playerIndex);
  }

  public static void main(String[] args) throws Exception
  {
    readAndPrint(new File(args[0]));
  }

  private static void readAndPrint(File file) throws Exception
  {
    DefensiveSimulationCodeFormulaResearch o =
        new DefensiveSimulationCodeFormulaResearch(file);
    o.readSimulationBytes();
    o.readPlayers();
    o.print();
  }

  private final File file;

  private DefensiveSimulationCodeFormulaResearch(File file)
  {
    this.file = file;
  }

  private final List<Byte> allOffense = newArrayList();
  private final List<Byte> allDefense = newArrayList();
  private final List<List<Player>> allDefensePlayers = newArrayList();

  private void readSimulationBytes() throws IOException
  {
    TsbFile tsbFile = new TsbFile(file, "r");
    tsbFile.seek(tsbFile.SIMULATION_CODE_LOCATION);
    for(int i = 0; i < NES_TEAMS_COUNT; i++)
    {
      byte[] teamSimulationBytes =
          tsbFile.readNybbles(TEAM_SIMULATION_CODE_SIZE_NYBBLES);

      // TODO constants for indexes
      allOffense.add(teamSimulationBytes[94]);
      allDefense.add(teamSimulationBytes[95]);
    }
    tsbFile.close();
  }

  private void readPlayers() throws IOException, SupplementFileFormatException,
    NesFileFormatException
  {
    League league = new SupplementedNesFile(file, null).readLeague();
    for(Team team : league.nesTeamsOrDummies())
    {
      List<Player> dl = team.getDepth(Position.DL).subList(0, 3);
      List<Player> lb = team.getDepth(Position.LB).subList(0, 4);
      List<Player> db = team.getDepth(Position.DB).subList(0, 4);
      @SuppressWarnings("unchecked")
      List<Player> defensePlayers = newArrayList(concat(dl, lb, db));

      allDefensePlayers.add(defensePlayers);
    }
  }

  private static final Multimap<Slot, Attribute> IGNORED =
      new ImmutableMultimapBuilder<Slot, Attribute>() //
          .put(NT, Attribute.MS) //
          .put(NT, Attribute.RP) //
          .put(NT, Attribute.RS) //
          .put(DE, Attribute.RS) //
          .put(DE, Attribute.RP) //
          .put(DE, Attribute.MS) // Adding this isn't terrible.
          .put(ILB, Attribute.RP) //
          .put(ILB, Attribute.RS) //
          .put(ILB, Attribute.MS) //
          .put(OLB, Attribute.RP) //
          .put(OLB, Attribute.RS) //
          .put(OLB, Attribute.HP) //
          /*
           * Adding in any CB attribute increases error and minimizes the
           * importance of Int (though adding MS actually increases the
           * correlation coefficient).
           */
          .put(CB, Attribute.RS) //
          .put(CB, Attribute.RP) //
          .put(CB, Attribute.HP) //
          .put(CB, Attribute.MS) //
          .put(S, Attribute.RP) //
          .put(S, Attribute.RS) //
          .put(S, Attribute.MS) //

          .put(NT, Attribute.Qui) //
          .put(DE, Attribute.Qui) //
          .put(ILB, Attribute.Qui) //
          .put(OLB, Attribute.Qui) //
          .put(CB, Attribute.Qui) //
          .put(S, Attribute.Qui) //

          /*
           * Too large (0.6734) for OLB, OK for ILB, negative for everyone else,
           * including CB and S. I'll handle it specially.
           */
          .put(NT, Attribute.Int) //
          .put(DE, Attribute.Int) //
          .put(ILB, Attribute.Int) //
          .put(OLB, Attribute.Int) //
          .put(CB, Attribute.Int) //
          .put(S, Attribute.Int) //

          .getMultimap();

  private void print() throws FileNotFoundException
  {
    PrintWriter out = new PrintWriter("defense.arff");
    printHeader(out);

    printData(out);

    out.close();
  }

  private void printHeader(PrintWriter out)
  {
    out.println("@RELATION defense");
    for(Slot slot : GENERAL_SLOTS)
    {
      for(Attribute attribute : slot.getPosition().getAttributeList())
      {
        if(IGNORED.containsEntry(slot, attribute))
        {
          continue;
        }
        out.println("@ATTRIBUTE " + slot + "_" + attribute + " NUMERIC");
      }
    }
    out.println("@ATTRIBUTE Int NUMERIC");
    out.println("@ATTRIBUTE Total NUMERIC");
    out.println("@ATTRIBUTE output NUMERIC");
  }

  // Note: I'm using the linear classifier with -S 1.
  private void printData(PrintWriter out)
  {
    out.println("@DATA");
    for(int teamIndex = 0; teamIndex < NES_TEAMS_COUNT; teamIndex++)
    {
      List<Number> line = newArrayList();

      List<Player> defensePlayers = allDefensePlayers.get(teamIndex);

      for(Slot slot : GENERAL_SLOTS)
      {
        for(Attribute attribute : slot.getPosition().getAttributeList())
        {
          if(IGNORED.containsEntry(slot, attribute))
          {
            continue;
          }

          int value = 0;

          for(int playerIndex = 0; playerIndex < defensePlayers.size(); playerIndex++)
          {
            Player player = defensePlayers.get(playerIndex);

            if(getGeneralSlot(playerIndex) == slot)
            {
              value += player.getAttribute(attribute).getComputerValue();
            }
          }

          line.add(value);
        }
      }

      line.add(calculateIntercept(defensePlayers));

      line.add(calculateTotal(defensePlayers));

      line.add(allDefense.get(teamIndex));

      out.println(join(",", line));
    }
  }

  private static int calculateIntercept(List<Player> defensePlayers)
  {
    int intercept = 0;

    for(int playerIndex = 0; playerIndex < defensePlayers.size(); playerIndex++)
    {
      Player player = defensePlayers.get(playerIndex);

      // Don't include DL in Int.
      if(playerIndex > 2)
      {
        intercept += player.getAttribute(Attribute.Int).getComputerValue();
      }
    }
    return intercept;
  }

  private static int calculateTotal(List<Player> defensePlayers)
  {
    int total = 0;

    for(int playerIndex = 0; playerIndex < defensePlayers.size(); playerIndex++)
    {
      Player player = defensePlayers.get(playerIndex);

      /*
       * Including a total causes multiple coefficients, notably Int, to go
       * negative. Adding just HP doesn't cause that specific problem, but it
       * increases error. Adding specific other attributes usually produces a
       * result somewhere between those two outcomes.
       */
      for(Attribute attribute : ImmutableList.<Attribute> of())
      {
        total += player.getAttribute(attribute).getComputerValue();
      }
    }
    return total;
  }
}
