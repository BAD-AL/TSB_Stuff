/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.dnd;

import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.TransferHandler;
import javax.swing.event.MouseInputAdapter;

import org.twofoos.gmtsb.gui.util.GUIUtils;

public class SimpleDragMouseMotionListener extends MouseInputAdapter
{
  private MouseEvent firstMouseEvent = null;

  public SimpleDragMouseMotionListener()
  {
    super();
  }

  private void setGrabCursor(MouseEvent e)
  {
    e.getComponent().setCursor(GUIUtils.GRAB_CURSOR);
  }

  private void setGrabbingCursor(MouseEvent e)
  {
    e.getComponent().setCursor(GUIUtils.GRABBING_CURSOR);
  }

  @Override
  public void mousePressed(MouseEvent e)
  {
    firstMouseEvent = e;
    setGrabbingCursor(e);
    e.consume();
  }

  @Override
  public void mouseDragged(MouseEvent e)
  {
    if(firstMouseEvent != null)
    {
      e.consume();

      // If they are holding down the control key, COPY rather than MOVE
      int ctrlMask = InputEvent.CTRL_DOWN_MASK;
      int action =
          ((e.getModifiersEx() & ctrlMask) == ctrlMask) ? TransferHandler.COPY
              : TransferHandler.MOVE;

      int dx = Math.abs(e.getX() - firstMouseEvent.getX());
      int dy = Math.abs(e.getY() - firstMouseEvent.getY());
      // Arbitrarily define a 5-pixel shift as the
      // official beginning of a drag.
      if(dx > 5 || dy > 5)
      {
        // This is a drag, not a click.
        JComponent component = (JComponent) e.getSource();
        TransferHandler handler = component.getTransferHandler();
        // Tell the transfer handler to initiate the drag.
        handler.exportAsDrag(component, firstMouseEvent, action);
        firstMouseEvent = null;
        setGrabCursor(e);
      }
    }
  }

  @Override
  public void mouseReleased(MouseEvent e)
  {
    setGrabCursor(e);
    firstMouseEvent = null;
  }
}
