/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import static javax.swing.BorderFactory.createTitledBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;

public class GUIUtils
{
  private GUIUtils()
  {
    super();
  }

  public static final Insets DEFAULT_INSETS = new Insets(2, 4, 2, 4);
  public static final Insets EMPTY_INSETS = new Insets(0, 0, 0, 0);

  public static final Insets BUTTON_VERTICAL_INSETS;
  static
  {
    Insets defaultButtonInsets = new JButton().getMargin();
    BUTTON_VERTICAL_INSETS = new Insets(defaultButtonInsets.top, 0,
        defaultButtonInsets.bottom, 0);
  }

  public static final Cursor GRAB_CURSOR;
  public static final Cursor GRABBING_CURSOR;

  public static final ImageIcon createImageIcon(String resourceName)
  {
    ClassLoader classLoader = GUIUtils.class.getClassLoader();
    URL resource = classLoader.getResource(resourceName);
    return new ImageIcon(resource);
  }

  public static final Image createImage(String resourceName)
  {
    ClassLoader classLoader = GUIUtils.class.getClassLoader();
    URL resource = classLoader.getResource(resourceName);
    return Toolkit.getDefaultToolkit().createImage(resource);
  }

  private static final Cursor createCursor(String resourceName, Point hotspot,
      String cursorName)
  {
    return Toolkit.getDefaultToolkit().createCustomCursor(
        createImage(resourceName), hotspot, cursorName);
  }

  static
  {
    GRAB_CURSOR = createCursor("grab.gif", new Point(7, 8), "grab");
    GRABBING_CURSOR = createCursor("grabbing.gif", new Point(5, 3), "grabbing");
  }

  public static final Dimension dimensionMinusInsets(Dimension dimension,
      Insets insets)
  {
    Dimension result = new Dimension(dimension);
    result.height -= insets.top + insets.bottom;
    result.width -= insets.left + insets.right;
    return result;
  }

  /*
   * private static final boolean noFieldsAreMaxInt(Rectangle rectangle) {
   * return (rectangle.x != Integer.MAX_VALUE && rectangle.y !=
   * Integer.MAX_VALUE && rectangle.width != Integer.MAX_VALUE &&
   * rectangle.height != Integer.MAX_VALUE); }
   */

  public static final void setBoundsToMaximum(Component component)
  {
    /*
     * if(component instanceof Frame) { Frame frame = (Frame)component;
     * Rectangle bounds = frame.getMaximizedBounds(); // getMaximizedBounds()
     * may return fields with Integer.MAX_VALUE if there // is no other maximum
     * set. In reality, I should probably test them one- // by-one, but so far
     * as I know, this part of the code is never even used. if(bounds != null &&
     * noFieldsAreMaxInt(bounds)) { component.setBounds(bounds); return; } }
     */

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Insets screenInsets = Toolkit.getDefaultToolkit().getScreenInsets(
        GraphicsEnvironment.getLocalGraphicsEnvironment()
            .getDefaultScreenDevice().getDefaultConfiguration());
    Dimension usableScreenSize = dimensionMinusInsets(screenSize, screenInsets);
    component.setBounds(screenInsets.left, screenInsets.top,
        usableScreenSize.width, usableScreenSize.height);
  }

  public static void gridBagAdd(Container contentPane, GridBagLayout layout,
      GridBagConstraints constraints, Component component)
  {
    layout.setConstraints(component, constraints);
    contentPane.add(component);
  }

  public static void resetCursor(Component c)
  {
    c.setCursor(Cursor.getDefaultCursor());
  }

  public static Color deriveTransparentColor(Color color, int alpha)
  {
    return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
  }

  public static Dimension add(Dimension d, Insets i)
  {
    return new Dimension(d.width + i.left + i.right, d.height + i.top
        + i.bottom);
  }

  public static JPanel surroundWithTitleBorder(JComponent component,
      String title)
  {
    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    panel.setBorder(createTitledBorder(title));
    panel.add(component, BorderLayout.CENTER);
    return panel;
  }

  public static GridBagConstraints gridSize(int width, int height)
  {
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = DEFAULT_INSETS;
    constraints.gridheight = height;
    constraints.gridwidth = width;
    constraints.weightx = width;
    constraints.weighty = height;
    return constraints;
  }
}
