/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.intrinsic.player;

import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.MergeableIntrinsicEvent;

public class FirstNameChangeEvent extends
    MergeableIntrinsicEvent<FirstNameChangeEvent, Player, String>
{
  public FirstNameChangeEvent(Player player, String from, String to,
      Object source)
  {
    super(player, from, to, source);
  }

  public String getDescription()
  {
    return "Change first name from " + getFrom() + " to " + getTo();
  }

  @Override
  protected UserEvent newEventForMerge(String from, String to)
  {
    return new FirstNameChangeEvent(getSubject(), from, to, getSource());
  }

  @Override
  protected void changeSubjectAttribute(String value)
  {
    getSubject().setFirst(value);
  }
}
