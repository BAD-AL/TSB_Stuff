/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core.play;

import org.twofoos.gmtsb.core.Team;

public class Play
{
  public static final int PLAYS_PER_PAGE = 8;
  public static final int PAGES = 8;
  public static final int NAME_LENGTH = 15;
  public static final int TILE_ROWS = 7;
  public static final int TILE_COLS = 6;
  public static final int TILES = TILE_ROWS * TILE_COLS;

  private String name;
  private Ballcarrier ballcarrier;
  private int[] graphics;
  private RunPass runPass;

  public Play(String name, Ballcarrier ballcarrier, int[] graphics,
      RunPass runPass)
  {
    this.name = name;
    this.ballcarrier = ballcarrier;
    this.graphics = graphics;
    this.runPass = runPass;
  }

  public Play(RunPass runPass)
  {
    this("NEW PLAY", Ballcarrier.RB1, new int[TILES], runPass);
  }

  public String getName()
  {
    return name;
  }

  public Ballcarrier getBallcarrier()
  {
    return ballcarrier;
  }

  public int[] getGraphics()
  {
    return graphics;
  }

  public String getBallCarrierPlayerName(Team team)
  {
    if(isPass())
    {
      return "(PASS)";
    }

    return ballcarrier.getPlayerName(team);
  }

  public void setBallcarrier(Ballcarrier ballcarrier)
  {
    this.ballcarrier = ballcarrier;
  }

  public void setGraphics(int[] graphics)
  {
    this.graphics = graphics;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  @Override
  public String toString()
  {
    return getName();
  }

  public RunPass getRunPass()
  {
    return runPass;
  }

  public void setRunPass(RunPass runPass)
  {
    this.runPass = runPass;
  }

  public boolean isRush()
  {
    return runPass == RunPass.RUN;
  }

  public boolean isPass()
  {
    return runPass == RunPass.PASS;
  }
}
