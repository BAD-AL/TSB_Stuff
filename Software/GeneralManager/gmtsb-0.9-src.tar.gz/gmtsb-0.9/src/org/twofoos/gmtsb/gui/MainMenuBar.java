/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui;

import static java.awt.Toolkit.getDefaultToolkit;
import static org.twofoos.gmtsb.gui.util.MacApplication.isMac;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Iterator;
import java.util.List;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import org.twofoos.gmtsb.gui.player.TeamFrame;
import org.twofoos.gmtsb.userevent.UndoHandler;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.UserEventListener;

public class MainMenuBar extends JMenuBar implements ActionListener,
    MenuListener, UserEventListener
{
  private static final long serialVersionUID = -6051544273294375137L;

  private final MainFrame mainFrame;

  private final JMenu windowMenu;

  private final JMenuItem openItem;
  private final JMenuItem saveItem;
  private final JMenuItem exitItem;

  private final JMenuItem undoItem;
  private final JMenuItem redoItem;

  private final JMenuItem leagueItem;
  private final JMenuItem teamItem;
  private final JMenuItem tableItem;

  private final JMenuItem aboutItem;

  private JMenuItem createMenuItem(String name, int mnemonic,
      int acceleratorKeyCode)
  {
    JMenuItem item = createMenuItem(name, mnemonic);
    item.setAccelerator(KeyStroke.getKeyStroke(acceleratorKeyCode,
        getDefaultToolkit().getMenuShortcutKeyMask()));
    return item;
  }

  private JMenuItem createMenuItem(String name, int mnemonic)
  {
    JMenuItem item = new JMenuItem(name, mnemonic);
    item.addActionListener(this);
    return item;
  }

  private JMenu createMenu(String name, int mnemonic)
  {
    JMenu menu = new JMenu(name);
    menu.setMnemonic(mnemonic);
    return menu;
  }

  public MainMenuBar(MainFrame mainFrame)
  {
    super();

    this.mainFrame = mainFrame;

    JMenu fileMenu = createMenu("File", KeyEvent.VK_F);
    openItem = createMenuItem("Open...", KeyEvent.VK_O, KeyEvent.VK_O);
    saveItem = createMenuItem("Save", KeyEvent.VK_S, KeyEvent.VK_S);
    // TODO Save As...?
    exitItem = createMenuItem("Quit", KeyEvent.VK_Q, KeyEvent.VK_Q);
    fileMenu.add(openItem);
    fileMenu.add(saveItem);
    if(!isMac())
    {
      fileMenu.addSeparator();
      fileMenu.add(exitItem);
    }
    add(fileMenu);

    JMenu editMenu = createMenu("Edit", KeyEvent.VK_E);
    undoItem = createMenuItem("Undo", KeyEvent.VK_U, KeyEvent.VK_Z);
    redoItem = createMenuItem("Redo", KeyEvent.VK_R, KeyEvent.VK_Y);
    editMenu.add(undoItem);
    editMenu.add(redoItem);
    add(editMenu);

    windowMenu = createMenu("Window", KeyEvent.VK_W);
    leagueItem =
        createMenuItem("Show League Window", KeyEvent.VK_L, KeyEvent.VK_L);
    teamItem =
        createMenuItem("Show Another Team Window", KeyEvent.VK_T, KeyEvent.VK_T);
    teamItem.setDisplayedMnemonicIndex(13);
    tableItem =
        createMenuItem("Show Another Table of All Players by Position",
            KeyEvent.VK_B, KeyEvent.VK_B);

    readWindowMenuItems();
    windowMenu.addMenuListener(this);
    add(windowMenu);

    if(!isMac())
    {
      JMenu helpMenu = createMenu("Help", KeyEvent.VK_H);
      aboutItem = createMenuItem("About", KeyEvent.VK_A);
      helpMenu.add(aboutItem);
      add(helpMenu);
    }
    else
    {
      aboutItem = null;
    }

    updateUndoRedoEnabled();
  }

  private void readWindowMenuItems()
  {
    windowMenu.removeAll();

    windowMenu.add(leagueItem);
    windowMenu.add(teamItem);
    windowMenu.add(tableItem);

    List<TeamFrame> teamFrames = mainFrame.getTeamFrames();
    synchronized(teamFrames)
    {
      if(teamFrames.size() > 0)
      {
        windowMenu.addSeparator();

        TeamFrameMenuItemFactory factory = new TeamFrameMenuItemFactory();

        Iterator<TeamFrame> teamFrameIterator = teamFrames.iterator();
        while(teamFrameIterator.hasNext())
        {
          windowMenu.add(factory.createTeamFrameMenuItem(teamFrameIterator
              .next()));
        }
      }
    }
  }

  private class TeamFrameMenuItemFactory
  {
    private int nextShortcut = 1;

    private TeamFrameMenuItemFactory()
    {
    }

    private TeamFrameMenuItem createTeamFrameMenuItem(TeamFrame teamFrame)
    {
      if(nextShortcut == -1)
      {
        return new TeamFrameMenuItem(teamFrame);
      }
      else
      {
        int shortcut = nextShortcut++;

        if(nextShortcut == 10)
        {
          // 10 is 0.
          nextShortcut = 0;
        }
        else if(nextShortcut == 1)
        {
          // No shortcuts left.
          nextShortcut = -1;
        }

        return new TeamFrameMenuItem(teamFrame, shortcut);
      }
    }
  }

  private class TeamFrameMenuItem extends JMenuItem
  {
    private static final long serialVersionUID = -7976176408631128083L;

    private final TeamFrame teamFrame;

    private TeamFrameMenuItem(TeamFrame teamFrame, int shortcut)
    {
      super(shortcut + " " + teamFrame.getDescription(), 0x30 + shortcut);

      this.addActionListener(MainMenuBar.this);
      this.teamFrame = teamFrame;
    }

    private TeamFrameMenuItem(TeamFrame teamFrame)
    {
      super(teamFrame.getDescription());

      this.addActionListener(MainMenuBar.this);
      this.teamFrame = teamFrame;
    }

    private TeamFrame getTeamFrame()
    {
      return teamFrame;
    }
  }

  public void actionPerformed(ActionEvent e)
  {
    Object source = e.getSource();
    if(source == openItem)
    {
      mainFrame.promptForOpen();
    }
    else if(source == saveItem)
    {
      mainFrame.promptForSave();
    }
    else if(source == exitItem)
    {
      mainFrame.promptForExit();
    }
    else if(source == undoItem)
    {
      getUndoHandler().undo();
    }
    else if(source == redoItem)
    {
      getUndoHandler().redo();
    }
    else if(source == leagueItem)
    {
      mainFrame.showLeagueFrame();
    }
    else if(source == teamItem)
    {
      mainFrame.showTeamFrame();
    }
    else if(source == tableItem)
    {
      mainFrame.showTableFrame();
    }
    else if(source == aboutItem)
    {
      mainFrame.showAbout();
    }
    else if(source instanceof TeamFrameMenuItem)
    {
      ((TeamFrameMenuItem) source).getTeamFrame().tryToSelect();
    }
  }

  public void menuCanceled(MenuEvent e)
  {
    // nothing
  }

  public void menuDeselected(MenuEvent e)
  {
    // nothing
  }

  public void menuSelected(MenuEvent e)
  {
    readWindowMenuItems();
  }

  public void userEventPerformed(UserEvent e, boolean isUndoRedoEvent)
  {
    updateUndoRedoEnabled();
  }

  private static void updateUndoRedoEnabled(JMenuItem menuItem,
      boolean enabled, String actionDescription, String eventDescription)
  {
    menuItem.setEnabled(enabled);
    if(enabled)
    {
      menuItem.setText(actionDescription + " : " + eventDescription);
    }
    else
    {
      menuItem.setText("Nothing to " + actionDescription);
    }
  }

  private void updateUndoRedoEnabled()
  {
    UndoHandler undoHandler = getUndoHandler();

    String eventDescription;
    boolean canUndoOrRedo;

    eventDescription = null;
    // Yes, that's = and not ==.
    if(canUndoOrRedo = undoHandler.canUndo())
    {
      eventDescription = undoHandler.getEventToUndoDescription();
    }
    updateUndoRedoEnabled(undoItem, canUndoOrRedo, "Undo", eventDescription);

    eventDescription = null;
    if(canUndoOrRedo = undoHandler.canRedo())
    {
      eventDescription = undoHandler.getEventToRedoDescription();
    }
    updateUndoRedoEnabled(redoItem, canUndoOrRedo, "Redo", eventDescription);
  }

  private UndoHandler getUndoHandler()
  {
    return mainFrame.getUndoHandler();
  }
}
