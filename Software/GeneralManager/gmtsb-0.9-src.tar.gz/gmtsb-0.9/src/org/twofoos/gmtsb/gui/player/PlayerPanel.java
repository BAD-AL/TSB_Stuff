/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player;

import static org.twofoos.gmtsb.gui.util.GUIUtils.gridBagAdd;
import static org.twofoos.gmtsb.gui.util.GUIUtils.gridSize;
import static org.twofoos.gmtsb.gui.util.GUIUtils.resetCursor;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.AttributeList;
import org.twofoos.gmtsb.core.AttributeValue;
import org.twofoos.gmtsb.core.Depth;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.ReturnJob;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.TransferablePanel;
import org.twofoos.gmtsb.gui.player.badge.Lapel;
import org.twofoos.gmtsb.gui.player.badge.ProBowlLapel;
import org.twofoos.gmtsb.gui.player.badge.ReturnerLapel;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.userevent.ProBowlSlotChangeEvent;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.extrinsic.DeleteEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.AppearanceChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.AttributeChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.FirstNameChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.LastNameChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.UniformNumberChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.ReturnerChangeEvent;

public class PlayerPanel extends TransferablePanel<Player> implements
    ActionListener
{
  private final DepthPanel depthPanel;

  private static final long serialVersionUID = 7316374296539239242L;

  private final Player player;

  private final Map<Attribute, AttributeSpinner> attributeSpinners;
  private final FaceButton faceButton;
  private final FirstNameField firstNameField;
  private final LastNameField lastNameField;
  private final JSpinner uniformNumberSpinner;
  private final JButton deleteButton;
  private final JButton notesButton;
  private final Lapel proBowlLapel;
  private final Lapel kickReturnerLapel;
  private final Lapel puntReturnerLapel;

  // TODO having this be a constant is misleading
  private static final GridBagConstraints ATTRIBUTE_SPINNER_CONSTRAINTS =
      gridSize(1, 1);
  private static final GridBagConstraints FACE_BUTTON_CONSTRAINTS =
      gridSize(1, 2);
  private static final GridBagConstraints MIDDLE_PANEL_CONSTRAINTS;
  static
  {
    MIDDLE_PANEL_CONSTRAINTS = gridSize(1, 1);
    MIDDLE_PANEL_CONSTRAINTS.insets = GUIUtils.EMPTY_INSETS;
    MIDDLE_PANEL_CONSTRAINTS.anchor = GridBagConstraints.WEST;
  }

  /** Sets insets on the added components. */
  private static class OneDimensionalGridPanel extends JPanel
  {
    private static final long serialVersionUID = 5120210832937855386L;

    private static final GridBagConstraints CONSTRAINTS = gridSize(1, 1);
    private static final GridBagConstraints FLUSH_RIGHT_CONSTRAINTS;
    static
    {
      FLUSH_RIGHT_CONSTRAINTS = gridSize(1, 1);
      FLUSH_RIGHT_CONSTRAINTS.insets =
          new Insets(GUIUtils.DEFAULT_INSETS.top, GUIUtils.DEFAULT_INSETS.left,
              GUIUtils.DEFAULT_INSETS.bottom, 0);
      FLUSH_RIGHT_CONSTRAINTS.anchor = GridBagConstraints.EAST;
    }

    private final GridBagLayout layout = new GridBagLayout();

    private OneDimensionalGridPanel()
    {
      setLayout(layout);
    }

    @Override
    public Component add(Component comp)
    {
      // Calling gridBagAdd() would produce an infinite loop.
      layout.setConstraints(comp, CONSTRAINTS);
      return super.add(comp);
    }

    public Component addFlushRight(Component comp)
    {
      // Calling gridBagAdd() would produce an infinite loop.
      layout.setConstraints(comp, FLUSH_RIGHT_CONSTRAINTS);
      return super.add(comp);
    }
  }

  PlayerPanel(final DepthPanel depthPanel, final Player player)
  {
    super(depthPanel.getMainFrame().getPlayerTransferHandler());
    this.depthPanel = depthPanel;

    this.player = player;

    // Will be null originally, but will be calculated later.
    setPreferredSize(TeamFrame.PLAYER_PANEL_SIZE);

    GridBagLayout layout = new GridBagLayout();
    setLayout(layout);

    // Face button.

    faceButton = new FaceButton(this);
    resetCursor(faceButton);
    gridBagAdd(this, layout, FACE_BUTTON_CONSTRAINTS, faceButton);

    // Middle panels.

    OneDimensionalGridPanel topMiddle = new OneDimensionalGridPanel();
    OneDimensionalGridPanel bottomMiddle = new OneDimensionalGridPanel();

    // Uniform number label and spinner.

    JLabel uniformNumberLabel = new JLabel("#", JLabel.RIGHT);
    uniformNumberSpinner = new JSpinner(new SpinnerNumberModel(20, 0, 99, 1));
    resetCursor(uniformNumberSpinner);
    uniformNumberSpinner.setValue(new Integer(player.getUniformNumber()));
    uniformNumberSpinner.addChangeListener(new UniformNumberListener());

    topMiddle.addFlushRight(uniformNumberLabel);
    topMiddle.add(uniformNumberSpinner);

    // Name fields.

    // TODO linked fields with joint maximum length?
    firstNameField = new FirstNameField(this, player.getFirst());
    lastNameField = new LastNameField(this, player.getLast());

    topMiddle.add(firstNameField);
    topMiddle.add(lastNameField);

    gridBagAdd(this, layout, MIDDLE_PANEL_CONSTRAINTS, topMiddle);

    // Attribute labels.

    for(Iterator<Attribute> attributeIterator = displayOrderAttributeIterator(); attributeIterator
        .hasNext();)
    {
      Attribute currentAttribute = attributeIterator.next();

      if(!attributeIterator.hasNext())
      {
        ATTRIBUTE_SPINNER_CONSTRAINTS.gridwidth = GridBagConstraints.REMAINDER;
      }
      else
      {
        ATTRIBUTE_SPINNER_CONSTRAINTS.gridwidth = 1;
      }

      JLabel currentLabel = new JLabel(currentAttribute.getAbbreviation());
      currentLabel.setToolTipText(currentAttribute.getName());
      gridBagAdd(this, layout, ATTRIBUTE_SPINNER_CONSTRAINTS, currentLabel);
    }

    bottomMiddle.add(new JPanel());

    // Delete button.

    deleteButton = new JButton("Delete");
    resetCursor(deleteButton);
    bottomMiddle.add(deleteButton);
    deleteButton.addActionListener(this);

    // Notes button.

    notesButton = new JButton("Notes");
    resetCursor(notesButton);
    bottomMiddle.add(notesButton);
    notesButton.addActionListener(this);

    bottomMiddle.add(new JPanel());

    // Lapels.

    // TODO proper conference
    // TODO be sure to repaint this when a team is moved in case it changes
    // conference
    proBowlLapel = new ProBowlLapel(this);
    kickReturnerLapel = new ReturnerLapel(this, ReturnJob.KR);
    puntReturnerLapel = new ReturnerLapel(this, ReturnJob.PR);

    bottomMiddle.add(proBowlLapel);
    bottomMiddle.add(kickReturnerLapel);
    bottomMiddle.add(puntReturnerLapel);

    gridBagAdd(this, layout, MIDDLE_PANEL_CONSTRAINTS, bottomMiddle);

    // Attribute spinners.

    attributeSpinners = new HashMap<Attribute, AttributeSpinner>();

    int i = 0;
    for(Iterator<Attribute> attributeIterator = displayOrderAttributeIterator(); attributeIterator
        .hasNext();)
    {
      Attribute currentAttribute = attributeIterator.next();

      if(!attributeIterator.hasNext())
      {
        ATTRIBUTE_SPINNER_CONSTRAINTS.gridwidth = GridBagConstraints.REMAINDER;
      }
      else
      {
        ATTRIBUTE_SPINNER_CONSTRAINTS.gridwidth = 1;
      }

      AttributeSpinner currentSpinner =
          new AttributeSpinner(this, currentAttribute);
      attributeSpinners.put(currentAttribute, currentSpinner);
      gridBagAdd(this, layout, ATTRIBUTE_SPINNER_CONSTRAINTS, currentSpinner);

      i++;
    }
  }

  public Player getPlayer()
  {
    return player;
  }

  private AttributeSpinner getAttributeSpinner(Attribute desiredAttribute)
  {
    return attributeSpinners.get(desiredAttribute);
  }

  public Position getPosition()
  {
    return depthPanel.getPosition();
  }

  public AttributeList getAttributeList()
  {
    return getPosition().getAttributeList();
  }

  public Iterator<Attribute> attributeIterator()
  {
    return getPosition().attributeIterator();
  }

  public Iterator<Attribute> displayOrderAttributeIterator()
  {
    return getAttributeList().displayOrderAttributes().iterator();
  }

  // TODO move UniformNumberListener to its own UniformNumberSpinner class?
  private class UniformNumberListener implements ChangeListener
  {
    private UniformNumberListener()
    {
    }

    public void stateChanged(ChangeEvent jSpinnerChangeEvent)
    {
      int from = player.getUniformNumber();
      int to =
          (Integer) ((JSpinner) jSpinnerChangeEvent.getSource()).getValue();
      UniformNumberChangeEvent uniformNumberChangeEvent =
          new UniformNumberChangeEvent(player, from, to, jSpinnerChangeEvent
              .getSource());
      performAndPublish(uniformNumberChangeEvent);
    }
  }

  @Override
  public Dimension getMaximumSize()
  {
    return getPreferredSize();
  }

  @Override
  public Dimension getMinimumSize()
  {
    return getPreferredSize();
  }

  public MainFrame getMainFrame()
  {
    return depthPanel.getMainFrame();
  }

  public void performAndPublish(UserEvent e)
  {
    getMainFrame().performAndPublish(e);
  }

  private boolean isFirstNameField(JTextField field)
  {
    return field == firstNameField;
  }

  private boolean isLastNameField(JTextField field)
  {
    return field == lastNameField;
  }

  public Depth getDepth()
  {
    return depthPanel.getDepth();
  }

  @Override
  public void paint(Graphics g)
  {
    super.paint(g);
    depthPanel.paintOverlayOnTransferablePanel(this, g);
  }

  @Override
  public Player getData()
  {
    return getPlayer();
  }

  @Override
  public List<Player> getList()
  {
    return getDepth();
  }

  // Events are delegated from TeamFrame; PlayerPanel isn't actually a
  // listener.
  public void intrinsicPlayerEventPerformed(IntrinsicEvent<Player, ?> event,
      boolean isUndoRedoEvent)
  {
    if(event instanceof AttributeChangeEvent)
    {
      AttributeChangeEvent attributeChangeEvent = (AttributeChangeEvent) event;

      Attribute attribute = attributeChangeEvent.getAttribute();

      AttributeValue newValue = getPlayer().getAttribute(attribute);
      AttributeSpinner spinner = getAttributeSpinner(attribute);
      spinner.setValue(newValue);
    }
    else if(event instanceof FirstNameChangeEvent)
    {
      FirstNameChangeEvent firstNameChangeEvent = (FirstNameChangeEvent) event;
      String newValue = getPlayer().getFirst();

      // Don't modify the text of the field where the user made the change.
      // Doing so moves the caret, which is annoying.
      if(!isFirstNameField((JTextField) firstNameChangeEvent.getSource())
          || isUndoRedoEvent)
      {
        firstNameField.setTextSilent(newValue);
      }
    }
    else if(event instanceof LastNameChangeEvent)
    {
      LastNameChangeEvent lastNameChangeEvent = (LastNameChangeEvent) event;
      String newValue = getPlayer().getLast();

      // See above in FirstNameChangeEvent.
      if(!isLastNameField((JTextField) lastNameChangeEvent.getSource())
          || isUndoRedoEvent)
      {
        lastNameField.setTextSilent(newValue);
      }
    }
    else if(event instanceof AppearanceChangeEvent)
    {
      faceButton.updateIcon();
    }
    else if(event instanceof UniformNumberChangeEvent)
    {
      uniformNumberSpinner.setValue(getPlayer().getUniformNumber());
    }
  }

  public void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    if(event instanceof ReturnerChangeEvent)
    {
      kickReturnerLapel.repaint();
      puntReturnerLapel.repaint();
    }
  }

  public void actionPerformed(ActionEvent e)
  {
    Object source = e.getSource();
    if(source == deleteButton)
    {
      DeleteEvent<Player> deleteEvent =
          DeleteEvent.createDeleteEvent(getDepth(), getPlayer());
      performAndPublish(deleteEvent);
    }
    else if(source == notesButton)
    {
      getMainFrame().showNotesFrame(getPlayer());
    }
  }

  public void otherEventPerformed(UserEvent event, boolean isUndoRedoEvent)
  {
    if(event instanceof ProBowlSlotChangeEvent)
    {
      proBowlLapel.repaint();
    }
  }
}
