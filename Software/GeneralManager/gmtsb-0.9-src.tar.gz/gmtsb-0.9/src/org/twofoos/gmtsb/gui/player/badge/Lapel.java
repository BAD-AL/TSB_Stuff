/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player.badge;

import static org.twofoos.gmtsb.gui.util.GUIUtils.deriveTransparentColor;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.UIManager;

import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.player.PlayerPanel;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.gui.util.MenuButton;
import org.twofoos.gmtsb.userevent.UserEvent;

import com.google.common.base.Supplier;

public abstract class Lapel extends MenuButton
{
  private static final Font FONT;

  static
  {
    Font oldFont = new JLabel().getFont();
    FONT = new Font("Monospaced", oldFont.getStyle(), oldFont.getSize());
  }

  private final PlayerPanel playerPanel;

  protected Lapel(PlayerPanel playerPanel, String abbreviation,
      String tooltipText)
  {
    super(newMonospaceFontButtonSupplier(abbreviation), tooltipText);

    this.playerPanel = playerPanel;
  }

  private static Supplier<JButton> newMonospaceFontButtonSupplier(
      final String abbreviation)
  {
    return new Supplier<JButton>()
    {
      public JButton get()
      {
        JButton appearance = new JButton();
        appearance.setText(abbreviation);
        // appearance.setText((abbreviation + "\u25bc").intern());
        appearance.setFont(FONT);
        return appearance;
      }
    };
  }

  private static final Font OVERLAY_FONT;

  static
  {
    Font oldFont = new JLabel().getFont();
    OVERLAY_FONT =
        new Font("Monospaced", oldFont.getStyle(),
            (int) (oldFont.getSize() / 1.5));
  }

  public void performAndPublish(UserEvent e)
  {
    getPlayerPanel().performAndPublish(e);
  }

  protected static class OverlayTextLabel extends JLabel
  {
    private static final long serialVersionUID = 6408507081784008467L;

    protected OverlayTextLabel(String text)
    {
      super(text);
      setOpaque(false);
      setFont(OVERLAY_FONT);
      setForeground(Color.YELLOW);
      setHorizontalAlignment(CENTER);
    }

    protected OverlayTextLabel()
    {
      this(null);
    }
  }

  protected PlayerPanel getPlayerPanel()
  {
    return playerPanel;
  }

  protected Player getPlayer()
  {
    return playerPanel.getPlayer();
  }

  protected Position getPosition()
  {
    return getPlayerPanel().getPosition();
  }

  protected Team getTeam()
  {
    return playerPanel.getDepth().getTeam();
  }

  private static final Color SELECTED_MENU_ITEM_BACKGROUND =
      UIManager.getColor("MenuItem.selectionBackground");
  private static final Color TRANSPARENT_SELECTED_MENU_ITEM_BACKGROUND =
      deriveTransparentColor(SELECTED_MENU_ITEM_BACKGROUND, 192);

  protected static JLabel createTransparentImageLabel(String imageResourceName)
  {
    ImageIcon icon = GUIUtils.createImageIcon(imageResourceName);
    JLabel label = new JLabel(icon);
    label.setOpaque(false);
    return label;
  }

  protected void paintSemiTransparentComponent(Graphics g, JComponent label)
  {
    g.setColor(TRANSPARENT_SELECTED_MENU_ITEM_BACKGROUND);
    g.fillRect(0, 0, getWidth(), getHeight());
    paintFullyTransparentComponent(g, label);
  }

  protected void paintFullyTransparentComponent(Graphics g, JComponent label)
  {
    label.setBounds(getBounds());
    label.paint(g);
  }

  private static final long serialVersionUID = 8870487872979956793L;
}
