/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.intrinsic.team;

import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.ReturnJob;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

public class ReturnerChangeEvent extends IntrinsicEvent<Team, Player>
{
  private final ReturnJob returnJob;

  public ReturnerChangeEvent(Team subject, ReturnJob returnJob, Player from,
      Player to)
  {
    super(subject, from, to);

    this.returnJob = returnJob;
  }

  @Override
  protected void changeSubjectAttribute(Player value)
  {
    getSubject().setReturner(returnJob, value);
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }

  public String getDescription()
  {
    return "Change " + returnJob.getAbbreviation() + " from "
        + getFrom().getFullName() + " to " + getTo().getFullName();
  }
}
