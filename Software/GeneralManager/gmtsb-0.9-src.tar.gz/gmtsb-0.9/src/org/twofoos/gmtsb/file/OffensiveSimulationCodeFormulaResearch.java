/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.file;

import static com.google.common.base.Join.join;
import static com.google.common.collect.Iterables.addAll;
import static com.google.common.collect.Iterables.concat;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Multimaps.newArrayListMultimap;
import static com.google.common.collect.Sets.newLinkedHashSet;
import static java.util.Collections.singleton;
import static org.twofoos.gmtsb.core.League.NES_TEAMS_COUNT;
import static org.twofoos.gmtsb.file.TsbFile.TEAM_SIMULATION_CODE_SIZE_NYBBLES;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.AttributeList;
import org.twofoos.gmtsb.core.AttributeValue;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.OffensiveFormation;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.Team;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMultimapBuilder;
import com.google.common.collect.Multimap;

/*
 * These calculations place too much weight on the offensive line at the expense
 * of everything else, so I am not using them.
 */
class OffensiveSimulationCodeFormulaResearch
{
  private static final ImmutableList<Attribute> QB_ATTRIBUTES =
      ImmutableList.of(Attribute.PS, Attribute.PC, Attribute.PA, Attribute.AR);
  private static final ImmutableList<Position> GENERAL_POSITIONS =
      ImmutableList.copyOf(newLinkedHashSet(concat(
          OffensiveFormation.OFF_2RB_2WR_1TE.rosterPositions(),
          singleton(Position.OL))));

  public static void main(String[] args) throws Exception
  {
    readAndPrint(new File(args[0]));
  }

  private static void readAndPrint(File file) throws Exception
  {
    OffensiveSimulationCodeFormulaResearch o =
        new OffensiveSimulationCodeFormulaResearch(file);
    o.readSimulationBytes();
    o.readPlayers();
    o.print();
  }

  private final File file;

  private OffensiveSimulationCodeFormulaResearch(File file)
  {
    this.file = file;
  }

  private final List<Byte> allOffense = newArrayList();
  private final List<Byte> allDefense = newArrayList();
  private final List<List<Player>> allOffensePlayers = newArrayList();

  private void readSimulationBytes() throws IOException
  {
    TsbFile tsbFile = new TsbFile(file, "r");
    tsbFile.seek(tsbFile.SIMULATION_CODE_LOCATION);
    for(int i = 0; i < NES_TEAMS_COUNT; i++)
    {
      byte[] teamSimulationBytes =
          tsbFile.readNybbles(TEAM_SIMULATION_CODE_SIZE_NYBBLES);

      // TODO constants for indexes
      allOffense.add(teamSimulationBytes[94]);
      allDefense.add(teamSimulationBytes[95]);
    }
    tsbFile.close();
  }

  private final List<Multimap<Position, Player>> allPlayersByPosition =
      newArrayList();
  private final List<Team> allTeams = newArrayList();

  private void readPlayers() throws IOException, SupplementFileFormatException,
    NesFileFormatException
  {
    League league = new SupplementedNesFile(file, null).readLeague();
    addAll(allTeams, league.nesTeamsOrDummies());
    for(Team team : league.nesTeamsOrDummies())
    {
      List<Player> qb = team.getDepth(Position.QB);
      List<Player> rb = team.getDepth(Position.RB);
      List<Player> wr = team.getDepth(Position.WR);
      List<Player> te = team.getDepth(Position.TE);
      List<Player> ol = team.getDepth(Position.OL);
      @SuppressWarnings("unchecked")
      List<Player> offensePlayers = newArrayList(concat(qb, rb, wr, te, ol));

      allOffensePlayers.add(offensePlayers);

      Multimap<Position, Player> byPosition = newArrayListMultimap();
      byPosition.putAll(Position.QB, qb);
      byPosition.putAll(Position.RB, rb);
      byPosition.putAll(Position.WR, wr);
      byPosition.putAll(Position.TE, te);
      byPosition.putAll(Position.OL, ol);
      allPlayersByPosition.add(byPosition);
    }
  }

  private static final Multimap<Position, Attribute> IGNORED =
      new ImmutableMultimapBuilder<Position, Attribute>() //
          /*
           * I handle QB passing stats specially because the importance of the
           * four bounces around (including from positive to negative) as I make
           * other changes.
           */
          .put(Position.QB, Attribute.AR) //
          .put(Position.QB, Attribute.PS) //
          .put(Position.QB, Attribute.PC) //
          .put(Position.QB, Attribute.PA) //

          /*
           * I get a better correlation coefficient (and brush the negative
           * coefficient of WR Rec under the table) by handling this manually.
           */
          .put(Position.WR, Attribute.Rec) //
          .put(Position.RB, Attribute.MS) //

          .put(Position.RB, Attribute.RS) //
          .put(Position.RB, Attribute.Rec) //
          .put(Position.RB, Attribute.BC) //
          .put(Position.RB, Attribute.HP) //
          .put(Position.WR, Attribute.RS) //
          .put(Position.WR, Attribute.MS) //
          .put(Position.WR, Attribute.HP) //
          .put(Position.WR, Attribute.BC) //
          .put(Position.TE, Attribute.RS) //
          .put(Position.TE, Attribute.MS) //
          .put(Position.TE, Attribute.HP) //
          .put(Position.TE, Attribute.BC) //
          .put(Position.TE, Attribute.Rec) //
          .put(Position.OL, Attribute.RS) //
          .put(Position.OL, Attribute.MS) //

          .put(Position.QB, Attribute.RP) //
          .put(Position.RB, Attribute.RP) //
          .put(Position.WR, Attribute.RP) //
          .put(Position.TE, Attribute.RP) //
          .put(Position.OL, Attribute.RP) //
          .getMultimap();

  private void print() throws FileNotFoundException
  {
    PrintWriter out = new PrintWriter("offense.arff");
    printHeader(out);

    printData(out);

    out.close();
  }

  private void printHeader(PrintWriter out)
  {
    out.println("@RELATION offense");
    for(Position position : GENERAL_POSITIONS)
    {
      for(Attribute attribute : position.getAttributeList())
      {
        if(IGNORED.containsEntry(position, attribute))
        {
          continue;
        }
        out.println("@ATTRIBUTE " + position + "_" + attribute + " NUMERIC");
      }
    }
    for(Position position : GENERAL_POSITIONS)
    {
      out.println("@ATTRIBUTE " + position + "_count NUMERIC");
    }
    out.println("@ATTRIBUTE QBPass NUMERIC");
    out.println("@ATTRIBUTE SkillPos NUMERIC");
    out.println("@ATTRIBUTE Total NUMERIC");
    out.println("@ATTRIBUTE output NUMERIC");
  }

  private static final double backupDivisor = 5.0;

  /*
   * javac 1.5 dies if I put this on the foreach variable:
   * http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6294589
   */
  @SuppressWarnings("unused")
  // Note: I'm using the linear classifier with -S 1.
  private void printData(PrintWriter out)
  {
    out.println("@DATA");
    for(int teamIndex = 0; teamIndex < NES_TEAMS_COUNT; teamIndex++)
    {
      List<Number> line = newArrayList();

      List<Player> offensePlayers = allOffensePlayers.get(teamIndex);

      for(Position position : GENERAL_POSITIONS)
      {
        for(Attribute attribute : position.getAttributeList())
        {
          if(IGNORED.containsEntry(position, attribute))
          {
            continue;
          }

          line.add(getTotal(teamIndex, position, attribute));
        }
      }

      for(Position position : GENERAL_POSITIONS)
      {
        line.add(0);
        /*
         * TE and WR bounce back and forth between good and bad. This is
         * probably not a good signal.
         */
        // line.add(allPlayersByPosition.get(teamIndex).get(position).size());
      }

      line.add(calculateQBPass(teamIndex));

      line.add(calculateSkillPos(teamIndex));

      line.add(calculateTotal(offensePlayers));

      line.add(allOffense.get(teamIndex));

      out.println(join(",", line));
    }
  }

  private double getTotal(int teamIndex, Position position, Attribute attribute)
  {
    Team team = allTeams.get(teamIndex);

    double value = 0;

    List<Player> startersAndBackups =
        newArrayList(allPlayersByPosition.get(teamIndex).get(position));
    int starterCount =
        false ? startersAndBackups.size() : team
            .getStarterCountForPosition(position);
    int backupCount = startersAndBackups.size() - starterCount;

    List<Player> starters = startersAndBackups.subList(0, starterCount);
    for(Player player : starters)
    {
      value += getAttribute(player, attribute);
    }

    List<Player> backups =
        startersAndBackups.subList(starterCount, startersAndBackups.size());
    for(Player player : backups)
    {
      value += getAttribute(player, attribute) / backupDivisor;
    }

    double count = starterCount + backupCount / backupDivisor;
    if(count > 0)
    {
      value /= count;
    }

    return value;
  }

  private double calculateSkillPos(int teamIndex)
  {
    /*
     * * 1.2 hurts the correlation slightly but also increases the importance of
     * QB's, RB's, and WR's.
     */
    return getTotal(teamIndex, Position.RB, Attribute.MS) * 1.2
        + getTotal(teamIndex, Position.WR, Attribute.Rec);
  }

  private int calculateQBPass(int teamIndex)
  {
    int qbPass = 0;
    Player qb =
        allPlayersByPosition.get(teamIndex).get(Position.QB).iterator().next();
    for(Attribute attribute : QB_ATTRIBUTES)
    {
      qbPass += getAttribute(qb, attribute);
    }
    return qbPass;
  }

  private static int getAttribute(Player player, Attribute attribute)
  {
    int value = player.getAttribute(attribute).getComputerValue();
    /*
     * Justification: The jump from 38 to 50 gives you a big boost by providing
     * genuine running threat at quarterback, while the jump from 13 to 25 or 25
     * to 38 isn't nearly so helpful.
     */
    if(attribute == Attribute.MS
        && player.attributes() == AttributeList.QB_ATTRIBUTES)
    {
      /*
       * Squaring sometimes produces a better function but with a more negative
       * WR_Rec coefficient.
       */
      // return value * value;
      return Math.max(value - AttributeValue._38.getComputerValue(), 0);
    }
    return value;
  }

  private static int calculateTotal(List<Player> offensePlayers)
  {
    if(true)
    {
      return 0;
    }
    int total = 0;

    for(int playerIndex = 0; playerIndex < offensePlayers.size(); playerIndex++)
    {
      Player player = offensePlayers.get(playerIndex);

      for(Attribute attribute : player.attributes())
      {
        total += getAttribute(player, attribute);
      }
    }
    return total;
  }
}
