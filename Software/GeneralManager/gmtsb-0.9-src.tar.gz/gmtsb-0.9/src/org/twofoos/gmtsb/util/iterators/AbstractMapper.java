/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.util.iterators;

import java.util.Iterator;

import com.google.common.base.Function;

public abstract class AbstractMapper<I, O> implements Mapper<I, O>,
    Function<I, O>
{
  protected AbstractMapper()
  {
  }

  public abstract O apply(I input);

  private class MapperIterator implements Iterator<O>
  {
    private final Iterator<I> input;

    private MapperIterator(Iterator<I> input)
    {
      this.input = input;
    }

    public boolean hasNext()
    {
      return input.hasNext();
    }

    public O next()
    {
      return apply(input.next());
    }

    public void remove()
    {
      input.remove();
    }
  }

  private class MapperIterable implements Iterable<O>
  {
    private final Iterable<I> input;

    private MapperIterable(Iterable<I> input)
    {
      this.input = input;
    }

    public Iterator<O> iterator()
    {
      return new MapperIterator(input.iterator());
    }
  }

  public Iterable<O> applyAll(Iterable<I> input)
  {
    return new MapperIterable(input);
  }
}
