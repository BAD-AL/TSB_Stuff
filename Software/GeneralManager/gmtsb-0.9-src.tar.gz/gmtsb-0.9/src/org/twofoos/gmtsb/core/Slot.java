/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import org.twofoos.gmtsb.util.iterators.AbstractMapper;
import org.twofoos.gmtsb.util.iterators.Mapper;

public enum Slot
{
  QB(Position.QB),

  HB(Position.RB), FB(Position.RB),

  RB(Position.RB),

  SE(Position.WR), FL(Position.WR),

  SLOT(Position.WR, "Slot"), LWR(Position.WR), RWR(Position.WR),

  LSLOT(Position.WR, "LSlot"), LSE(Position.WR), RSE(Position.WR), RSLOT(
      Position.WR, "RSlot"),

  WR(Position.WR),

  LTE_SLOT(Position.TE, "LSlot"), RTE(Position.TE),

  TE(Position.TE),

  C(Position.OL), LG(Position.OL), RG(Position.OL), LT(Position.OL), RT(
      Position.OL),

  RDE(Position.DL), NT(Position.DL), LDE(Position.DL),

  ROLB(Position.LB), RILB(Position.LB), LILB(Position.LB), LOLB(Position.LB),

  RCB(Position.DB), LCB(Position.DB), FS(Position.DB), SS(Position.DB),

  K(Position.K), P(Position.P);

  private final Position position;
  private final String slotAbbreviation;

  private Slot(Position position, String slotAbbreviation)
  {
    this.position = position;
    this.slotAbbreviation = slotAbbreviation;
  }

  private Slot(Position position)
  {
    this(position, null);
  }

  public Position getPosition()
  {
    return position;
  }

  public String getSlotAbbreviation()
  {
    return (slotAbbreviation == null) ? name() : slotAbbreviation;
  }

  private static class SlotToPositionMapper extends
      AbstractMapper<Slot, Position>
  {
    private SlotToPositionMapper()
    {
    }

    @Override
    public Position apply(Slot slot)
    {
      return slot.getPosition();
    }
  }

  private static final Mapper<Slot, Position> SLOT_TO_POSITION_MAPPER =
      new SlotToPositionMapper();

  public static Mapper<Slot, Position> getSlotToPositionMapper()
  {
    return SLOT_TO_POSITION_MAPPER;
  }
}
