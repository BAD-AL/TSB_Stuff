/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

public class Appearance
{
  public static final int WHITE = 0;
  public static final int BLACK = 1;

  public static final int WHITE_FACE_COUNT = 84;
  public static final int BLACK_FACE_COUNT = 85;

  private static final Appearance[][] appearances;

  static
  {
    appearances = new Appearance[2][];
    appearances[Appearance.WHITE] = new Appearance[Appearance.WHITE_FACE_COUNT];
    appearances[Appearance.BLACK] = new Appearance[Appearance.BLACK_FACE_COUNT];

    for(int raceCode = 0; raceCode <= 1; raceCode++)
    {
      for(int faceCode = 0; (raceCode == Appearance.WHITE && faceCode < Appearance.WHITE_FACE_COUNT)
          || (raceCode == Appearance.BLACK && faceCode < Appearance.BLACK_FACE_COUNT); faceCode++)
      {
        appearances[raceCode][faceCode] = new Appearance(raceCode, faceCode);
      }
    }
  }

  private final int raceCode;
  private final int faceCode;

  private Appearance(int raceCode, int faceCode)
  {
    this.raceCode = raceCode;
    this.faceCode = faceCode;
  }

  public static Appearance getAppearance(int raceCode, int faceCode)
  {
    if(faceCode >= appearances[raceCode].length)
    {
      // TODO log this?
      faceCode = appearances[raceCode].length - 1;
    }
    return appearances[raceCode][faceCode];
  }

  // TODO some of this should perhaps be in the file package?
  public static Appearance getAppearance(int raceFaceCode)
  {
    int raceCode = raceFaceCode >> 7;
    int faceCode = (0x007F) & raceFaceCode;
    return getAppearance(raceCode, faceCode);
  }

  public static Appearance getBlankBlackAppearance()
  {
    return getAppearance(BLACK, BLACK_FACE_COUNT - 1);
  }

  public int getRaceFaceCode()
  {
    return (raceCode << 7) | faceCode;
  }

  public int getFaceCode()
  {
    return faceCode;
  }

  public int getRaceCode()
  {
    return raceCode;
  }

  @Override
  public String toString()
  {
    return "Race: " + raceCode + "; Face: " + faceCode;
  }

  @Override
  public int hashCode()
  {
    return getRaceFaceCode();
  }

  @Override
  public boolean equals(Object obj)
  {
    if(!(obj instanceof Appearance))
    {
      return false;
    }
    Appearance that = (Appearance) obj;
    return this.getRaceFaceCode() == that.getRaceFaceCode();
  }
}
