/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.util.iterators;

import java.util.Iterator;
import java.util.NoSuchElementException;

import com.google.common.base.Predicate;

public abstract class AbstractFilter<T> implements Filter<T>, Predicate<T>
{
  public abstract boolean apply(T input);

  public Iterable<T> applyAll(Iterable<T> input)
  {
    return new FilterIterable(input);
  }

  private class FilterIterator implements Iterator<T>
  {
    private final Iterator<T> input;
    private T next;
    private boolean hasNext;

    private FilterIterator(Iterator<T> input)
    {
      this.input = input;
      updateNext();
    }

    private void updateNext()
    {
      while(input.hasNext())
      {
        next = input.next();

        if(apply(next))
        {
          hasNext = true;
          return;
        }
      }

      hasNext = false;
    }

    public boolean hasNext()
    {
      return hasNext;
    }

    public T next()
    {
      if(!hasNext())
      {
        throw new NoSuchElementException();
      }

      try
      {
        return next;
      }
      finally
      {
        updateNext();
      }
    }

    public void remove()
    {
      throw new UnsupportedOperationException("remove() not supported");
    }
  }

  private class FilterIterable implements Iterable<T>
  {
    private final Iterable<T> input;

    private FilterIterable(Iterable<T> input)
    {
      this.input = input;
    }

    public Iterator<T> iterator()
    {
      return new FilterIterator(input.iterator());
    }
  }
}
