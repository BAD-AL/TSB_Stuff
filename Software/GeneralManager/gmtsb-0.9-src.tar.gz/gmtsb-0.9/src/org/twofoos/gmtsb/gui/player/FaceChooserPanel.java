/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player;

import java.awt.Frame;
import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import org.twofoos.gmtsb.core.Appearance;
import org.twofoos.gmtsb.gui.chooser.SingleChooserPanel;

public class FaceChooserPanel extends SingleChooserPanel<Appearance>
{
  private static final long serialVersionUID = 1771242023089827209L;

  private FaceChooserPanel(Frame chooserOwner, Appearance initialAppearance,
      String playerName)
  {
    super(chooserOwner, "Face Chooser - " + playerName);

    JTabbedPane tabbedPane = new JTabbedPane();

    addRaceTab(tabbedPane, "Black", Appearance.BLACK,
        Appearance.BLACK_FACE_COUNT, initialAppearance);
    addRaceTab(tabbedPane, "White", Appearance.WHITE,
        Appearance.WHITE_FACE_COUNT, initialAppearance);

    add(tabbedPane);
  }

  private static final int FACES_PER_ROW = 13;

  private final void addRaceTab(JTabbedPane tabbedPane, String title,
      int raceCode, int faceCount, Appearance initialAppearance)
  {
    JPanel panel = new JPanel();
    boolean isInitialAppearanceInThisPanel = false;

    panel.setLayout(new GridLayout(0, FACES_PER_ROW, 2, 2));

    // TODO Iterator for this?
    for(int faceCode = 0; faceCode < faceCount; faceCode++)
    {
      Appearance currentAppearance =
          Appearance.getAppearance(raceCode, faceCode);

      FaceRadioButton currentButton = new FaceRadioButton(currentAppearance);

      // setSelected() must happen after ChooserButtonGroup.add(); see comment
      // in UniformColorChooser.createChoiceComponent().
      if(currentAppearance == initialAppearance)
      {
        currentButton.setSelected(true);
        isInitialAppearanceInThisPanel = true;
      }

      panel.add(currentButton.getBorderedContainer());
    }

    tabbedPane.addTab(title, panel);
    if(isInitialAppearanceInThisPanel)
    {
      tabbedPane.setSelectedComponent(panel);
    }
  }

  public static Appearance showDialog(Frame chooserOwner,
      Appearance initialAppearance, String playerName)
  {
    FaceChooserPanel chooserPanel =
        new FaceChooserPanel(chooserOwner, initialAppearance, playerName);
    return showDialog(chooserPanel);
  }

  private final class FaceRadioButton extends ChooserRadioButton
  {
    private static final long serialVersionUID = -2906907114716358628L;

    private FaceRadioButton(Appearance appearance)
    {
      super(appearance);
      setIcon(Faces.getImageIcon(appearance));
    }
  }
}
