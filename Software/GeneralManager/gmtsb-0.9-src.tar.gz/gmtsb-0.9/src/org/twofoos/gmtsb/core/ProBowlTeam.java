/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/*
 * Beware trying to merge this with Team. When I tried, I ran up against the
 * distinction between TSBTransferableData<AbstractTeam> and
 * TSBTransferableData<Team>.
 */
// TODO maybe use BiMap internally?
public class ProBowlTeam
{
  private final Conference conference;
  private final Map<ProBowlSlot, Player> slotToPlayer =
      new EnumMap<ProBowlSlot, Player>(ProBowlSlot.class);
  private final Map<Player, ProBowlSlot> playerToSlot =
      new HashMap<Player, ProBowlSlot>();

  public ProBowlTeam(Conference conference)
  {
    this.conference = conference;
  }

  public Conference getConference()
  {
    return conference;
  }

  public Player getPlayer(ProBowlSlot slot)
  {
    return slotToPlayer.get(slot);
  }

  public ProBowlSlot getSlot(Player player)
  {
    return playerToSlot.get(player);
  }

  public boolean isSlotFilled(ProBowlSlot slot)
  {
    return getPlayer(slot) != null;
  }

  public boolean isPlayerOnTeam(Player player)
  {
    return getSlot(player) != null;
  }

  public void clearSlot(ProBowlSlot slot)
  {
    Player player = getPlayer(slot);
    clear(player, slot);
  }

  public void clearPlayer(Player player)
  {
    ProBowlSlot slot = getSlot(player);
    clear(player, slot);
  }

  private void clear(Player player, ProBowlSlot slot)
  {
    ProBowlSlot actualSlot = getSlot(player);
    Player actualPlayer = getPlayer(slot);

    if(slot != actualSlot)
    {
      throw new IllegalArgumentException(player + " is in slot " + actualSlot
          + ", not " + slot);
    }
    if(player != actualPlayer)
    {
      throw new IllegalArgumentException(slot + " is occupied by "
          + actualPlayer + ", not " + player);
    }

    playerToSlot.remove(player);
    slotToPlayer.remove(slot);
  }

  /**
   * <strong>The slot you are filling must be empty, and the player you are
   * adding must not already appear in the team.</strong> Yes, this is
   * annoying, but I need to separate the event classes from the core classes.
   */
  public void putPlayer(ProBowlSlot slot, Player player)
  {
    ProBowlSlot previousSlot = getSlot(player);
    Player previousPlayer = getPlayer(slot);

    if(previousSlot != null)
    {
      throw new IllegalArgumentException(player + " is already on the "
          + getConference() + " Pro Bowl team at slot " + previousSlot);
    }
    if(previousPlayer != null)
    {
      throw new IllegalArgumentException(slot + " is already filled on the "
          + getConference() + " Pro Bowl team by " + previousPlayer);
    }

    playerToSlot.put(player, slot);
    slotToPlayer.put(slot, player);
  }

  @Override
  public String toString()
  {
    return conference + " Pro Bowl team: " + slotToPlayer;
  }
}
