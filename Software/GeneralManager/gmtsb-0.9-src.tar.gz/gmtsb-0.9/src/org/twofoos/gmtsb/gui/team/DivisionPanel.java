/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import javax.swing.BorderFactory;

import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.ListPanel;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.TransferablePanel;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

// TODO division names?
public class DivisionPanel extends ListPanel<Team>
{
  private static final long serialVersionUID = -252220244801647068L;

  DivisionPanel(MainFrame mainFrame, Division division)
  {
    super(mainFrame, mainFrame.getTeamTransferHandler(), division);

    setBorder(BorderFactory.createEtchedBorder());
  }

  // TODO make superclass generic so cast is not required?
  public Division getDivision()
  {
    return (Division) getList();
  }

  // Events are delegated from LeagueFrame; DivisionPanel isn't actually a
  // listener.
  // TODO very similar to DepthPanel.intrinsicPlayerEventPerformed()
  void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    Team team = event.getSubject();

    TeamPanel teamPanel = (TeamPanel) findPanel(team);

    if(teamPanel == null)
    {
      // Team involved not in this frame.
      return;
    }

    teamPanel.intrinsicTeamEventPerformed(event, isUndoRedoEvent);
  }

  private LeagueFrame getLeagueFrame()
  {
    return getMainFrame().getLeagueFrame();
  }

  private class TeamOverlay extends Overlay
  {
    private static final long serialVersionUID = -1267205704026324546L;

    private TeamOverlay(int index)
    {
      super(Integer.toString(index + 1), index);
    }

    @Override
    protected int getTransferablePanelHeight()
    {
      return getLeagueFrame().getTeamPanelSize().height;
    }
  }

  @Override
  protected void initOverlays()
  {
    for(int i = 0; i < getDivision().getNESTeamCount(); i++)
    {
      addOverlay(new TeamOverlay(i));
    }
  }

  @Override
  protected TransferablePanel<Team> newTransferablePanel(Team data)
  {
    return new TeamPanel(this, data);
  }
}
