/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player;

import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.FirstNameChangeEvent;

public class FirstNameField extends PlayerTextField
{
  private static final long serialVersionUID = -8006095261788642812L;

  public FirstNameField(PlayerPanel playerPanel, String text)
  {
    super(playerPanel, text);
  }

  @Override
  protected UserEvent createUserEvent()
  {
    Player player = getPlayer();
    String from = player.getFirst();
    String to = getText();
    return new FirstNameChangeEvent(player, from, to, this);
  }
}
