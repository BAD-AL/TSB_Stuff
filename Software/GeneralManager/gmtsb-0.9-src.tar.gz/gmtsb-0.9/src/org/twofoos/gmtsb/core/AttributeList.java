/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static org.twofoos.gmtsb.core.Attribute.DISPLAY_ORDER_MAPPER;

import java.util.Iterator;
import java.util.List;

import org.twofoos.gmtsb.util.iterators.AbstractFilter;
import org.twofoos.gmtsb.util.iterators.Filter;

import com.google.common.collect.ImmutableList;

public enum AttributeList implements Iterable<Attribute>
{
  // Rushing Speed and Rushing Power are not in the file in the order that they
  // appear in player data.
  QB_ATTRIBUTES(Attribute.RP, Attribute.RS, Attribute.MS, Attribute.HP,
      Attribute.PS, Attribute.PC, Attribute.PA, Attribute.AR),

  OL_ATTRIBUTES(Attribute.RP, Attribute.RS, Attribute.MS, Attribute.HP),

  OFF_ATTRIBUTES(Attribute.RP, Attribute.RS, Attribute.MS, Attribute.HP,
      Attribute.BC, Attribute.Rec),

  DEF_ATTRIBUTES(Attribute.RP, Attribute.RS, Attribute.MS, Attribute.HP,
      Attribute.Int, Attribute.Qui),

  KP_ATTRIBUTES(Attribute.RP, Attribute.RS, Attribute.MS, Attribute.HP,
      Attribute.KA, Attribute.AB);

  private final List<Attribute> attributes;

  private AttributeList(Attribute... attributes)
  {
    this.attributes = ImmutableList.of(attributes);
  }

  public int size()
  {
    return attributes.size();
  }

  public Iterator<Attribute> iterator()
  {
    return attributes.iterator();
  }

  private class AttributeListFilter extends AbstractFilter<Player>
  {
    @Override
    public boolean apply(Player input)
    {
      return input.attributes() == AttributeList.this;
    }
  }

  public Filter<Player> getAttributeListFilter()
  {
    return new AttributeListFilter();
  }

  public Iterable<Attribute> displayOrderAttributes()
  {
    return DISPLAY_ORDER_MAPPER.applyAll(this);
  }
}
