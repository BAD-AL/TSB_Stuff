/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Comparators.compound;
import static com.google.common.collect.Iterables.concat;
import static com.google.common.collect.Iterables.limit;
import static org.twofoos.gmtsb.core.PaletteColor.getColor;
import static org.twofoos.gmtsb.core.RunPassRatio.PASS_FIRST;
import static org.twofoos.gmtsb.util.CollectionUtilities.list;
import static org.twofoos.gmtsb.util.iterators.Pair.pairIterable;
import static org.twofoos.gmtsb.util.iterators.Range.range;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicLong;

import org.twofoos.gmtsb.core.play.Page;
import org.twofoos.gmtsb.core.play.Playbook;
import org.twofoos.gmtsb.util.iterators.Pair;

import com.google.common.collect.ImmutableSet;

public class Team implements TSBTransferableData<Team>, Notable
{
  private String city;
  private String name;
  private String abbreviation;
  private OffensiveFormation offensiveFormation;
  private Map<ReturnJob, Player> returners =
      new EnumMap<ReturnJob, Player>(ReturnJob.class);
  private String notes = "";
  private final List<List<PaletteColor>> spriteColors;
  private final Playbook playbook = new Playbook();
  private RunPassRatio runPassRatio = PASS_FIRST;

  private static final AtomicLong NEXT_ID = new AtomicLong();
  private final long idForFullySpecifiedSorting = NEXT_ID.getAndIncrement();

  private Set<Team> alternateColorsVersus =
      new TreeSet<Team>(FULL_NAME_COMPARATOR);

  // private int alternateCutsceneColorsCode;
  private PaletteColor playerDataColor = getColor(0);

  /*
   * ADD ANYTHING NEW TO ISIDENTICAL() AND MAKE SURE ITS TYPE'S EQUALS() IS
   * DEFINED
   */

  // Recalculated with each change to city or name. (Likely to be needed a lot
  // for display in combo boxes and during sorting.)
  private transient String fullName;

  private final Map<Position, Depth> depthAtPosition;

  @SuppressWarnings("unchecked")
  public static final Comparator<Team> FULL_NAME_COMPARATOR =
      compound(new Comparator<Team>()
      {
        public int compare(Team t1, Team t2)
        {
          return t1.getFullName().compareTo(t2.getFullName());
        }
      },
      /*
       * It's nice to break ties in a way that will not change within this
       * instance of the program. Otherwise, when a team is deleted, etc., two
       * teams with the same name might switch places in a TeamFrame, and that
       * would be confusing from a user perspective.
       */
      new Comparator<Team>()
      {
        public int compare(Team o1, Team o2)
        {
          return new Long(o1.idForFullySpecifiedSorting)
              .compareTo(o2.idForFullySpecifiedSorting);
        }
      });

  /** Next call {@link #fillPlaybookWithDefaultPlays(League)}! */
  public Team(OffensiveFormation offensiveFormation, String city, String name,
      String abbreviation)
  {
    setOffensiveFormation(offensiveFormation);
    setCity(city);
    setName(name);
    setAbbreviation(abbreviation);

    depthAtPosition = new EnumMap<Position, Depth>(Position.class);

    List<PaletteColor> dummyColors =
        Arrays.asList(PaletteColor.getAllColors().iterator().next(),
            PaletteColor.getAllColors().iterator().next(), PaletteColor
                .getSkinColors().iterator().next());

    spriteColors = new ArrayList<List<PaletteColor>>(2);
    spriteColors.add(dummyColors);
    spriteColors.add(dummyColors);

    for(Position currentPosition : Position.allPositions())
    {
      depthAtPosition.put(currentPosition, new Depth(this, currentPosition));
    }
  }

  /** Next call {@link #fillPlaybookWithDefaultPlays(League)}! */
  public Team()
  {
    // Dummy values.
    this(OffensiveFormation.OFF_2RB_2WR_1TE, "CITY", "NAMES", "C.N.");
  }

  public String getAbbreviation()
  {
    return abbreviation;
  }

  public void setAbbreviation(String abbreviation)
  {
    this.abbreviation = abbreviation.toUpperCase().intern();
  }

  public String getCity()
  {
    return city;
  }

  public void setCity(String city)
  {
    this.city = city.toUpperCase().intern();
    updateToString();
  }

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name.toUpperCase().intern();
    updateToString();
  }

  public OffensiveFormation getOffensiveFormation()
  {
    return offensiveFormation;
  }

  public void setOffensiveFormation(OffensiveFormation offensiveFormation)
  {
    this.offensiveFormation = offensiveFormation;
  }

  // TODO enum for oneOrTwo
  public List<PaletteColor> getSpriteColors(int oneOrTwo)
  {
    return spriteColors.get(oneOrTwo - 1);
  }

  public void setSpriteColors(int oneOrTwo, Iterable<PaletteColor> colors)
  {
    this.spriteColors.set(oneOrTwo - 1, Collections
        .unmodifiableList(list(colors)));
  }

  public List<PaletteColor> getSpriteColors1()
  {
    return getSpriteColors(1);
  }

  public void setSpriteColors1(Iterable<PaletteColor> colors)
  {
    setSpriteColors(1, colors);
  }

  public List<PaletteColor> getSpriteColors2()
  {
    return getSpriteColors(2);
  }

  public void setSpriteColors2(Iterable<PaletteColor> colors)
  {
    setSpriteColors(2, colors);
  }

  public void addAlternateUniformWhenPlaying(Team otherTeam)
  {
    alternateColorsVersus.add(otherTeam);
  }

  public boolean removeAlternateUniformWhenPlaying(Team otherTeam)
  {
    return alternateColorsVersus.remove(otherTeam);
  }

  public void setAlternateUniformWhenPlaying(Set<Team> teams)
  {
    alternateColorsVersus.clear();
    alternateColorsVersus.addAll(teams);
  }

  public boolean getWearsAlternateUniformWhenPlayingTeam(Team otherTeam)
  {
    return alternateColorsVersus.contains(otherTeam);
  }

  public ImmutableSet<Team> getAlternateUniformWhenPlayingTeams()
  {
    return ImmutableSet.copyOf(alternateColorsVersus);
  }

  // I'm not keeping separate alternate sprite-colors and cutscene-colors
  // codes.
  // Too bad for the Dolphins, Chiefs, Redskins, and Buccaneers.
  // TODO maybe someday change that

  // TODO might rearrange things so that this isn't public
  public Formation getFormationWithPosition(Position position)
  {
    for(Formation formation : getAllFormations())
    {
      if(formation.getStarterCountForPosition(position) > 0)
      {
        return formation;
      }
    }

    // Can't return null because we still call a method on it.
    // null would be a problem when we ask for the Formation containing a TE for
    // a 4-WR team.
    return Formation.DUMMY;
  }

  public Slot getSlotAtPosition(Position position, int index)
  {
    return getFormationWithPosition(position)
        .getSlotAtPosition(position, index);
  }

  public int getStarterCountForPosition(Position position)
  {
    return getFormationWithPosition(position).getStarterCountForPosition(
        position);
  }

  /**
   * This would break if a Formation ever had backups for a Position but not
   * starters. Fortunately, this never happens is TSB, and even if I fake other
   * formations (like 2-TE), I don't intend to create such a situation.
   */
  public int getBackupCountForPosition(Position position)
  {
    return getFormationWithPosition(position).getBackupCountForPosition(
        position);
  }

  public Iterable<Formation> getAllFormations()
  {
    // TODO might as well be unmodifiable; modify
    // CollectionUtilities.unmodifiableList() to take varargs
    return Arrays.asList(getOffensiveFormation(), Formation.OL, Formation.DEF,
        Formation.ST);
  }

  private Iterable<Iterable<Position>> positionsOfEachFormation()
  {
    return Formation.getFormationToRosterPositionsMapper().applyAll(
        getAllFormations());
  }

  public Iterable<Position> positionOfEachPlayerInAllFormations()
  {
    return concat(positionsOfEachFormation());
  }

  public Iterable<Pair<Position, Integer>> positionOfEachPlayerInAllFormationsAndIndexes()
  {
    // TODO not hard-coded number
    return pairIterable(positionOfEachPlayerInAllFormations(), range(30));
  }

  private Iterable<Iterable<Boolean>> getIsStarterListForEachFormation()
  {
    return Formation.getFormationToIsStarterListMapper().applyAll(
        getAllFormations());
  }

  public Iterable<Boolean> getIsStarterListForAllFormations()
  {
    return concat(getIsStarterListForEachFormation());
  }

  private Iterable<Iterable<Position>> startersOrBackupsOfEachFormation(
      boolean wantStarters)
  {
    return Formation.getFormationToStarterOrBackupPositionsMapper(wantStarters)
        .applyAll(getAllFormations());
  }

  public Iterable<Position> startersOrBackupsOfAllFormations(
      boolean wantStarters)
  {
    return concat(startersOrBackupsOfEachFormation(wantStarters));
  }

  public Depth getDepth(Position position)
  {
    return depthAtPosition.get(position);
  }

  private void updateToString()
  {
    fullName = (city + " " + name).intern();
  }

  public String getFullName()
  {
    return fullName;
  }

  @Override
  public String toString()
  {
    return getFullName();
  }

  public Player getNthPlayer(int n)
  {
    PlayersByPositionIterator playersByPositionIterator =
        playersByPositionIterator();

    Player player = null;

    for(Position position : limit(positionOfEachPlayerInAllFormations(), n + 1))
    {
      /*
       * When we have <4 RB's, we still need to know who the ballcarrier on a WR
       * reverse is. Don't die just because an unrelated player is missing.
       */
      if(playersByPositionIterator.hasNextPlayerAtPosition(position))
      {
        player = playersByPositionIterator.nextPlayerAtPosition(position);
      }
    }

    return player;
  }

  public int getIndexOfPlayer(Player desiredPlayer)
  {
    PlayersByPositionIterator playersByPositionIterator =
        playersByPositionIterator();

    for(Pair<Position, Integer> positionAndIndex : positionOfEachPlayerInAllFormationsAndIndexes())
    {
      Position position = positionAndIndex.getFirst();
      Integer index = positionAndIndex.getSecond();

      // TODO is this a sign that I should be using
      // PlayersOrDummiesByPositionIterator?
      if(playersByPositionIterator.hasNextPlayerAtPosition(position))
      {
        if(playersByPositionIterator.nextPlayerAtPosition(position) == desiredPlayer)
        {
          return index;
        }
      }
    }

    return -1;
  }

  public Map<Player, Integer> getIndexesOfNesPlayers()
  {
    Map<Player, Integer> indexes = new HashMap<Player, Integer>();

    PlayersByPositionIterator playersByPositionIterator =
        playersByPositionIterator();

    for(Pair<Position, Integer> positionAndIndex : positionOfEachPlayerInAllFormationsAndIndexes())
    {
      Position position = positionAndIndex.getFirst();
      Integer index = positionAndIndex.getSecond();

      // TODO is this a sign that I should be using
      // PlayersOrDummiesByPositionIterator?
      if(playersByPositionIterator.hasNextPlayerAtPosition(position))
      {
        Player player =
            playersByPositionIterator.nextPlayerAtPosition(position);
        indexes.put(player, index);
      }
    }

    return indexes;
  }

  public PlayersByPositionIterator playersByPositionIterator()
  {
    return new PlayersByPositionIterator(this);
  }

  // Used in SupplementedNesFile.
  public static class PlayersByPositionIterator
  {
    private final Map<Position, ListIterator<Player>> positionToDepthIteratorMap;
    private final Team team;

    protected PlayersByPositionIterator(Team team)
    {
      this.team = team;
      positionToDepthIteratorMap =
          new EnumMap<Position, ListIterator<Player>>(Position.class);
      for(Position currentPosition : Position.allPositions())
      {
        Depth currentDepth = team.getDepth(currentPosition);
        ListIterator<Player> currentDepthIterator = currentDepth.listIterator();
        positionToDepthIteratorMap.put(currentPosition, currentDepthIterator);
      }
    }

    public boolean hasNextPlayerAtPosition(Position position)
    {
      ListIterator<Player> playersAtPositionIterator =
          positionToDepthIteratorMap.get(position);
      return playersAtPositionIterator.hasNext();
    }

    public Player nextPlayerAtPosition(Position position)
    {
      ListIterator<Player> playersAtPositionIterator =
          positionToDepthIteratorMap.get(position);
      if(playersAtPositionIterator.hasNext())
      {
        return playersAtPositionIterator.next();
      }
      else
      {
        throw new NoSuchElementException(team + " " + position
            + "no remaining players");
      }
    }

    public void addPlayerAtPosition(Position position, Player player)
    {
      ListIterator<Player> playersAtPositionIterator =
          positionToDepthIteratorMap.get(position);
      playersAtPositionIterator.add(player);
    }
  }

  public Player getReturner(ReturnJob returnJob)
  {
    return returners.get(returnJob);
  }

  public void setReturner(ReturnJob returnJob, Player player)
  {
    returners.put(returnJob, player);
  }

  public Team copyOrSelfIfCopyNotSupported()
  {
    return this;
  }

  public boolean isCopyable()
  {
    return false;
  }

  // See Player for the reason that I don't override equals() and hashCode().

  // TODO Player.isDefaultPlayer() instead of its isIdenticalTo()?
  public boolean isDefaultTeam(League league)
  {
    Team other = new Team();
    other.fillPlaybookWithDefaultPlays(league);

    if(abbreviation == null)
    {
      if(other.abbreviation != null)
        return false;
    }
    else if(!abbreviation.equals(other.abbreviation))
      return false;
    if(alternateColorsVersus == null)
    {
      if(other.alternateColorsVersus != null)
        return false;
    }
    else if(!alternateColorsVersus.equals(other.alternateColorsVersus))
      return false;
    if(city == null)
    {
      if(other.city != null)
        return false;
    }
    else if(!city.equals(other.city))
      return false;

    /*
     * Because Player.equals() uses the default implementation,
     * this.depthAtPosition.equals(that.depthAtPosition) only when both have no
     * players. So let's be explicit:
     */
    for(Depth depth : depthAtPosition.values())
    {
      if(!depth.isEmpty())
      {
        return false;
      }
    }

    // No fullName

    if(name == null)
    {
      if(other.name != null)
        return false;
    }
    else if(!name.equals(other.name))
      return false;
    if(notes == null)
    {
      if(other.notes != null)
        return false;
    }
    else if(!notes.equals(other.notes))
      return false;
    if(offensiveFormation == null)
    {
      if(other.offensiveFormation != null)
        return false;
    }
    else if(!offensiveFormation.equals(other.offensiveFormation))
      return false;
    if(playbook == null)
    {
      if(other.playbook != null)
        return false;
    }
    else if(!playbook.equals(other.playbook))
      return false;
    if(playerDataColor == null)
    {
      if(other.playerDataColor != null)
        return false;
    }
    else if(!playerDataColor.equals(other.playerDataColor))
      return false;

    // Ignore returners.
    // TODO that's not ideal, though it's hardly a killer

    if(spriteColors == null)
    {
      if(other.spriteColors != null)
        return false;
    }
    else if(!spriteColors.equals(other.spriteColors))
      return false;
    if(runPassRatio == null)
    {
      if(other.runPassRatio != null)
        return false;
    }
    else if(!runPassRatio.equals(other.runPassRatio))
      return false;
    return true;
  }

  public void setPlayerDataColor(PaletteColor playerDataColor)
  {
    this.playerDataColor = playerDataColor;
  }

  public PaletteColor getPlayerDataColor()
  {
    return playerDataColor;
  }

  public RunPassRatio getRunPassRatio()
  {
    return runPassRatio;
  }

  public void setRunPassRatio(RunPassRatio runPassRatio)
  {
    this.runPassRatio = runPassRatio;
  }

  public Playbook getPlaybook()
  {
    return playbook;
  }

  public void fillPlaybookWithDefaultPlays(League league)
  {
    for(Page page : Page.values())
    {
      playbook.put(page, league.getBinder().getPlaysByPage(page).get(0));
    }
  }

  public String getNotes()
  {
    return notes;
  }

  public void setNotes(String notes)
  {
    this.notes = notes;
  }
}
