/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import java.awt.Component;
import java.awt.Container;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JViewport;

// If this scroll pane displays a Container, then its scroll increment will be
// equal to the size of that Container's first child.
// Also, make page up / page down move the height of the viewport.
// TODO try to prevent the scroll wheel from scrolling three times the scroll
// increment
// TODO this may vary with Swing UI, so probably just leave it alone
public class ComponentSizeIncrementScrollPane extends JScrollPane
{
  private static final long serialVersionUID = 4610225530305334237L;

  public ComponentSizeIncrementScrollPane(Component view)
  {
    super(view);
  }

  public ComponentSizeIncrementScrollPane(Component view, int vsbPolicy,
      int hsbPolicy)
  {
    super(view, vsbPolicy, hsbPolicy);
  }

  @Override
  public JScrollBar createHorizontalScrollBar()
  {
    return new ComponentSizeIncrementScrollBar(JScrollBar.HORIZONTAL);
  }

  @Override
  public JScrollBar createVerticalScrollBar()
  {
    return new ComponentSizeIncrementScrollBar(JScrollBar.VERTICAL);
  }

  private class ComponentSizeIncrementScrollBar extends JScrollBar
  {
    private static final long serialVersionUID = -4231217588073206582L;

    private ComponentSizeIncrementScrollBar(int orientation)
    {
      super(orientation);
    }

    @Override
    public int getBlockIncrement()
    {
      return getViewportBorderBounds().height;
    }

    @Override
    public int getBlockIncrement(int direction)
    {
      return getBlockIncrement();
    }

    @Override
    public int getUnitIncrement()
    {
      JViewport viewPort = getViewport();
      if(viewPort.getComponentCount() == 0)
      {
        return 0; // No components, so it doesn't matter.
      }
      else
      {
        Component singleComponent = viewPort.getComponent(0);

        if(singleComponent instanceof Container
            && ((Container) singleComponent).getComponentCount() > 0)
        {
          Component firstComponent =
              ((Container) singleComponent).getComponent(0);

          return firstComponent.getPreferredSize().height;
        }
        else
        {
          // No components inside the main component -- use default size.
          return super.getUnitIncrement();
        }
      }
    }

    @Override
    public int getUnitIncrement(int direction)
    {
      return getUnitIncrement();
    }
  }
}