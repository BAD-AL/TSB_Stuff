/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import org.twofoos.gmtsb.core.PaletteColor;

public abstract class NesFile
{
  private static final String ISO_8859_1 = "ISO-8859-1";

  public abstract NesLocation newLocationFromJava(int location);

  public class NesLocation
  {
    private final int javaLocation;

    protected NesLocation(int javaLocation)
    {
      this.javaLocation = javaLocation;
    }

    public int getJavaLocation()
    {
      return javaLocation;
    }

    public NesLocation add(int addend)
    {
      return newLocationFromJava(getJavaLocation() + addend);
    }

    public int subtract(NesLocation other)
    {
      return getJavaLocation() - other.getJavaLocation();
    }

    @Override
    public String toString()
    {
      return Integer.toHexString(javaLocation);
      // return Integer.toHexString(javaLocation)
      // + " ("
      // + Integer
      // .toHexString(((TsbLocation)this).getTSBTeamRelatedLocation())
      // + ")";
    }
  }

  protected final RandomAccessFile raf;

  public NesFile(File file, String mode) throws FileNotFoundException
  {
    this.raf = new RandomAccessFile(file, mode);
  }

  private static byte intToUByte(int i)
  {
    return (byte) ((i > Byte.MAX_VALUE) ? (i + 2 * Byte.MIN_VALUE) : (i));
  }

  private static int uByteToInt(byte b)
  {
    return (b < 0) ? (b - 2 * Byte.MIN_VALUE) : (b);
  }

  /**
   * IIRC, converts the hex value 10 (which is 16 decimal, but we don't care) to
   * the decimal number 10.
   */
  private static int hexValueThatLooksLikeAnIntToThatInt(int i)
  {
    return Integer.parseInt(Integer.toHexString(i));
  }

  /**
   * IIRC, converts the decimal value 20 to the hex value 20 (which is 32
   * decimal, but we don't care).
   */
  private static int intToValueThatInHexLooksLikeIt(int i)
  {
    return Integer.parseInt(Integer.toString(i), 16);
  }

  public void close() throws IOException
  {
    raf.close();
  }

  public void seek(NesLocation location) throws IOException
  {
    raf.seek(location.getJavaLocation());
  }

  private byte[] readBytes(int length) throws IOException
  {
    byte[] bytes = new byte[length];
    raf.readFully(bytes);
    return bytes;
  }

  public String readPaddedString(int length) throws IOException
  {
    return readString(length).trim();
  }

  public void writePaddedString(String string, int length) throws IOException
  {
    int paddingLength = string.length() - length;
    if(paddingLength < 0)
    {
      throw new IllegalArgumentException("string \"" + string
          + "\" is too long to fit in length " + length);
    }
    writeString(string);
    for(int i = 0; i < paddingLength; i++)
    {
      writeByte((byte) ' ');
    }
  }

  // TODO might see if there are any other characters that are different in NES
  // and ASCII and possibly modify the method I'm using
  public String readString(int length) throws IOException
  {
    // Need to specify a character set that preserves the 8 bits untouched.
    // TODO does this always work?
    String string = new String(readBytes(length), ISO_8859_1);
    string = string.replaceAll(";", "-");
    return string;
  }

  public void writeString(String string) throws IOException
  {
    string = string.replaceAll("-", ";");
    raf.writeBytes(string);
  }

  public int readIntThatLooksLikeByteValueInHex() throws IOException
  {
    return hexValueThatLooksLikeAnIntToThatInt(raf.readUnsignedByte());
  }

  public void writeByteValueThatLooksInHexLikeInt(int i) throws IOException
  {
    raf.writeByte(intToValueThatInHexLooksLikeIt(i));
  }

  public NesLocation getFileLocation() throws IOException
  {
    return newLocationFromJava((int) raf.getFilePointer());
  }

  public void writeByte(byte b) throws IOException
  {
    raf.writeByte(b);
  }

  public void writeUnsignedByte(int b) throws IOException
  {
    raf.writeByte(intToUByte(b));
  }

  public byte readByte() throws IOException
  {
    return raf.readByte();
  }

  public int readUnsignedByte() throws IOException
  {
    return uByteToInt(readByte());
  }

  public int[] readUnsignedBytes(int length) throws IOException
  {
    byte[] bytes = readBytes(length);

    int[] unsignedBytes = new int[length];
    for(int i = 0; i < length; i++)
    {
      unsignedBytes[i] = uByteToInt(bytes[i]);
    }

    return unsignedBytes;
  }

  public void writeUnsignedBytes(int[] unsignedBytes) throws IOException
  {
    byte[] bytes = new byte[unsignedBytes.length];

    for(int i = 0; i < unsignedBytes.length; i++)
    {
      bytes[i] = intToUByte(unsignedBytes[i]);
    }

    raf.write(bytes);
  }

  public void writeNybbles(byte[] nybbles) throws IOException
  {
    if(nybbles.length % 2 != 0)
    {
      throw new IllegalArgumentException(
          "length of nybbles must be a multiple of two");
    }

    byte[] bytes = new byte[nybbles.length / 2];

    for(int i = 0; i < bytes.length; i++)
    {
      int highBits = nybbles[2 * i] << 4;
      int lowBits = nybbles[2 * i + 1];
      bytes[i] = intToUByte(highBits | lowBits);
    }

    raf.write(bytes);
  }

  public static void byteIntoNybbles(byte bite, byte[] nybbles, int i)
  {
    int unsignedByte = uByteToInt(bite);
    nybbles[i] = (byte) (unsignedByte >> 4);
    nybbles[i + 1] = (byte) (unsignedByte & 0x0F);
  }

  private void readNybbles(byte[] nybbles) throws IOException
  {
    if(nybbles.length % 2 != 0)
    {
      throw new IllegalArgumentException(
          "length of nybbles must be a multiple of two");
    }

    byte[] bytes = new byte[nybbles.length / 2];
    raf.readFully(bytes);

    for(int i = 0; i < bytes.length; i++)
    {
      byteIntoNybbles(bytes[i], nybbles, 2 * i);
    }
  }

  public byte[] readNybbles(int count) throws IOException
  {
    byte[] nybbles = new byte[count];
    readNybbles(nybbles);
    return nybbles;
  }

  public int readInt() throws IOException
  {
    return raf.readInt();
  }

  public void writeInt(int i) throws IOException
  {
    raf.writeInt(i);
  }

  public void writePaletteColor(PaletteColor color) throws IOException
  {
    writeUnsignedByte(color.getIndex());
  }

  public PaletteColor readPaletteColor() throws IOException
  {
    return PaletteColor.getColor(readUnsignedByte());
  }
}
