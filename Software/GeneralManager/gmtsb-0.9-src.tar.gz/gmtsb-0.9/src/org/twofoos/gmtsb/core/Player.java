/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Maps.newHashMapWithExpectedSize;

import java.util.Iterator;
import java.util.Map;

public class Player implements TSBTransferableData<Player>, Notable
{
  private final AttributeList attributeList;

  private String first;
  private String last;
  private int uniformNumber;
  private Appearance appearance;
  private String notes = "";

  /*
   * ADD ANYTHING NEW TO ISIDENTICAL() AND MAKE SURE ITS TYPE'S EQUALS() IS
   * DEFINED
   */

  // Updated with changes to first and last.
  private transient String fullName;

  private final Map<Attribute, AttributeValue> attributes;

  public Player(Position position, String first, String last, int uniformNumber)
  {
    this(position, first, last, uniformNumber, Appearance
        .getBlankBlackAppearance());
  }

  public Player(Position position, String first, String last,
      int uniformNumber, Appearance appearance)
  {
    this(position.getAttributeList(), first, last, uniformNumber, appearance);
  }

  public Player(AttributeList attributeList, String first, String last,
      int uniformNumber, Appearance appearance)
  {
    this.attributeList = attributeList;

    setFirst(first);
    setLast(last);
    setUniformNumber(uniformNumber);

    attributes = newHashMapWithExpectedSize(getAttributeCount());

    // TODO allow for default values
    // may or may not need the cast to Attribute then
    for(Attribute currentAttribute : attributes())
    {
      // A two-digit default is probably a good idea for the moment.
      // (1 is 13.)
      setComputerAttribute(currentAttribute, 1);
    }

    this.appearance = appearance;
  }

  public Player(Player player)
  {
    this(player.attributeList, player.first, player.last, player.uniformNumber,
        player.appearance);

    for(Attribute currentAttribute : attributes())
    {
      setAttribute(currentAttribute, player.getAttribute(currentAttribute));
    }
  }

  public boolean isCompatibleWith(Position position)
  {
    return position.isCompatibleWith(this);
  }

  public int getAttributeCount()
  {
    return attributeList.size();
  }

  public AttributeList attributes()
  {
    return attributeList;
  }

  public Iterator<Attribute> attributesIterator()
  {
    return attributes().iterator();
  }

  public void setAttribute(Attribute attribute, AttributeValue value)
  {
    attributes.put(attribute, value);
  }

  public void setComputerAttribute(Attribute attribute, int value)
  {
    attributes.put(attribute, AttributeValue.forComputerValue(value));
  }

  public void setHumanAttribute(Attribute attribute, int value)
  {
    attributes.put(attribute, AttributeValue.forHumanValue(value));
  }

  public AttributeValue getAttribute(Attribute attribute)
  {
    return attributes.get(attribute);
  }

  public int getComputerAttribute(Attribute attribute)
  {
    return getAttribute(attribute).getComputerValue();
  }

  public int getHumanAttribute(Attribute attribute)
  {
    return getAttribute(attribute).getHumanValue();
  }

  private final void updateFullName()
  {
    // Is called during construction before both names are set, so beware nulls.
    if(first == null || last == null)
    {
      fullName = "";
    }
    else
    {
      fullName = (first + " " + last).intern();
    }
  }

  // Always uppercase for both first and last.
  // That's how the game displays it, anyway.
  // This also makes the GUI code simpler, since I use all uppercase there.
  // I had one bug where I was comparing the old name, which was in lowercase,
  // to the new name, which was in uppercase. Not good.
  public void setFirst(String first)
  {
    this.first = first.toUpperCase().intern();
    updateFullName();
  }

  public void setLast(String last)
  {
    this.last = last.toUpperCase().intern();
    updateFullName();
  }

  public String getFirst()
  {
    return first;
  }

  public String getLast()
  {
    return last;
  }

  public int getUniformNumber()
  {
    return uniformNumber;
  }

  public void setUniformNumber(int uniformNumber)
  {
    this.uniformNumber = uniformNumber;
  }

  public Appearance getAppearance()
  {
    return appearance;
  }

  public void setAppearance(Appearance appearance)
  {
    this.appearance = appearance;
  }

  public String getFullName()
  {
    return fullName;
  }

  public boolean isValidReturnerPosition()
  {
    return attributeList == AttributeList.OFF_ATTRIBUTES;
  }

  // Used by NotesFrame.
  @Override
  public String toString()
  {
    return getFullName();
  }

  public String debugToString()
  {
    StringBuffer info =
        new StringBuffer("[" + getUniformNumber() + "] " + getLast() + ", "
            + getFirst() + ": ");

    Iterator<Attribute> attributeIterator = attributes().iterator();
    boolean first = true;
    while(attributeIterator.hasNext())
    {
      Attribute currentAttribute = attributeIterator.next();

      if(!first)
      {
        info.append(",");
      }

      info.append(currentAttribute + "=" + getAttribute(currentAttribute));

      first = false;
    }

    return info.toString();
  }

  public Player copyOrSelfIfCopyNotSupported()
  {
    return new Player(this);
  }

  public boolean isCopyable()
  {
    return true;
  }

  /*
   * Note to self: Do NOT override equals(). If we copy a player, we must (of
   * course) create a copy, but the copy should NOT be equals() to the original,
   * or else moving players (and probably other stuff) will break.
   * 
   * Additionally, Do NOT override hashCode(). Players are used as keys in a
   * hash map storing notes windows, so if the hash code changes based on a
   * renaming or other action, the map will break.
   */

  public boolean isIdentical(Player other)
  {
    if(this == other)
      return true;
    if(other == null)
      return false;
    if(appearance == null)
    {
      if(other.appearance != null)
        return false;
    }
    else if(!appearance.equals(other.appearance))
      return false;
    if(attributeList == null)
    {
      if(other.attributeList != null)
        return false;
    }
    else if(!attributeList.equals(other.attributeList))
      return false;
    if(attributes == null)
    {
      if(other.attributes != null)
        return false;
    }
    else if(!attributes.equals(other.attributes))
      return false;
    if(first == null)
    {
      if(other.first != null)
        return false;
    }
    else if(!first.equals(other.first))
      return false;
    if(last == null)
    {
      if(other.last != null)
        return false;
    }
    else if(!last.equals(other.last))
      return false;
    if(notes == null)
    {
      if(other.notes != null)
        return false;
    }
    else if(!notes.equals(other.notes))
      return false;
    if(uniformNumber != other.uniformNumber)
      return false;
    return true;
  }

  public String getNotes()
  {
    return notes;
  }

  public void setNotes(String notes)
  {
    this.notes = notes;
  }
}
