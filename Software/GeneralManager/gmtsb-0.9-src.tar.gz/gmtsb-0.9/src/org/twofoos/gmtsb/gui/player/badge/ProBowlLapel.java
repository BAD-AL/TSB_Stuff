/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player.badge;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;

import org.twofoos.gmtsb.core.AFC_NFC_Other;
import org.twofoos.gmtsb.core.Conference;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.ProBowlSlot;
import org.twofoos.gmtsb.core.ProBowlTeam;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.player.PlayerPanel;
import org.twofoos.gmtsb.userevent.ProBowlSlotChangeEvent;

public class ProBowlLapel extends Lapel
{
  private static final String ABBREVIATION = "PB";

  private static final long serialVersionUID = 4695344221200871912L;

  private final JLabel slotLabel;

  public ProBowlLapel(PlayerPanel playerPanel)
  {
    super(playerPanel, ABBREVIATION, "Pro Bowl Team");
    /*
     * TODO effects of allowing setting of, e.g., a RB to WR Pro Bowl slot?
     * Don't forget that we can drag players from one position to another, even,
     * say, OL to DL. Consider this also for return men, or I guess it can't
     * happen there?
     */
    slotLabel = new OverlayTextLabel();
  }

  private static final JLabel AFC_STAR_LABEL =
      createTransparentImageLabel("afcstar.png");
  private static final JLabel NFC_STAR_LABEL =
      createTransparentImageLabel("nfcstar.png");

  // TODO shouldn't I disable the menu when a player is on a non-conference
  // team?

  public MainFrame getMainFrame()
  {
    return getPlayerPanel().getMainFrame();
  }

  private League getLeague()
  {
    return getMainFrame().getLeague();
  }

  private Conference getConference()
  {
    return getLeague().getConferenceWithTeam(getTeam());
  }

  private ProBowlTeam getProBowlTeam()
  {
    return getConference().getProBowlTeam();
  }

  private AFC_NFC_Other getAFCNFCOther()
  {
    return getConference().getAFCNFCOther();
  }

  private boolean isInNESConference()
  {
    return !(getAFCNFCOther() == AFC_NFC_Other.OTHER);
  }

  private JLabel getStarLabel(AFC_NFC_Other afcNFCOther)
  {
    switch(afcNFCOther)
    {
      case AFC:
        return AFC_STAR_LABEL;

      case NFC:
        return NFC_STAR_LABEL;

      default:
        return null;
    }
  }

  @Override
  public void paint(Graphics g)
  {
    setEnabled(isInNESConference());
    super.paint(g);

    ProBowlSlot slot = getProBowlTeam().getSlot(getPlayer());

    if(slot != null)
    {
      paintSemiTransparentComponent(g, getStarLabel(getAFCNFCOther()));
      slotLabel.setText(slot.getNumber());
      paintFullyTransparentComponent(g, slotLabel);
    }
  }

  private boolean isPlayerInSlot(ProBowlSlot slot)
  {
    return (getProBowlTeam().getPlayer(slot) == getPlayer());
  }

  private String getText(ProBowlSlot slot)
  {
    if(isPlayerInSlot(slot))
    {
      return "Currently " + getConference() + " " + slot;
    }

    if(getProBowlTeam().isSlotFilled(slot)
        && getProBowlTeam().isPlayerOnTeam(getPlayer()))
    {
      return "Set as " + getConference() + " " + slot + " ("
          + getProBowlTeam().getPlayer(slot).getFullName() + " will become "
          + getProBowlTeam().getSlot(getPlayer()) + ")";
    }

    // TODO deal with other cases

    return "Set as " + getConference() + " " + slot + " (replacing "
        + getProBowlTeam().getPlayer(slot).getFullName() + ")";
  }

  @Override
  protected void menuActivated(JMenu menu)
  {
    menu.removeAll();

    if(isInNESConference())
    {
      addMenuItems(menu);
    }
    else
    {
      addCannotAssignMenuItem(menu);
    }
  }

  private void addMenuItems(JMenu menu)
  {
    for(ProBowlSlot slot : ProBowlSlot.getSlotsForPosition(getPosition()))
    {
      menu.add(new MenuItem(slot));
    }

    Collection<ProBowlSlot> otherSlots =
        ProBowlSlot.getSlotsForOtherCompatiblePositions(getPosition());

    if(otherSlots.isEmpty())
    {
      return;
    }

    menu.add(new JSeparator());

    for(ProBowlSlot slot : otherSlots)
    {
      menu.add(new MenuItem(slot));
    }
  }

  private void addCannotAssignMenuItem(JMenu menu)
  {
    JMenuItem cannotAssignToTeamItem =
        new JMenuItem(
            getTeam()
                + " are not in either conference, so their players may not assigned to a Pro Bowl Team");
    cannotAssignToTeamItem.setEnabled(false);
    menu.add(cannotAssignToTeamItem);

    return;
  }

  private class MenuItem extends JMenuItem implements ActionListener
  {
    private static final long serialVersionUID = 490827003671508931L;

    private final ProBowlSlot slot;

    private MenuItem(ProBowlSlot slot)
    {
      // TODO mnemonic?
      super(ProBowlLapel.this.getText(slot));

      setEnabled(!isPlayerInSlot(slot));

      this.slot = slot;

      addActionListener(this);
    }

    public void actionPerformed(ActionEvent e)
    {
      performAndPublish(new ProBowlSlotChangeEvent(getConference(), slot,
          getPlayer()));
    }
  }
}
