/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.twofoos.gmtsb.core.League;

// TODO consistent capitalization of Tsb/TSB
public class TsbFile extends NesFile
{
  private static final int HEADER_LENGTH = 16;
  public final TsbLocation TEAM_POINTERS_LOCATION =
      newLocationFromJava(HEADER_LENGTH);
  public final TsbLocation FIRST_TEAM_PLAYER_POINTER_LOCATION =
      newLocationFromJava(56 + HEADER_LENGTH);
  public final TsbLocation FIRST_PLAYER_NAME_LOCATION =
      newLocationFromJava(1738 + HEADER_LENGTH);
  public final TsbLocation PLAYER_ATTRIBUTES_LOCATION =
      newLocationFromJava(0x3000 + HEADER_LENGTH);
  public final TsbLocation FORMATION_POSITION_SECTIONS_LOCATION =
      newLocationFromJava(0x0021fe0);
  public final TsbLocation FORMATION_POSITION_LABELS_LOCATION =
      newLocationFromJava(0x0031e80);
  public final TsbLocation PLAY_NAMES_FORMATIONS_AND_POINTERS_LOCATION =
      newLocationFromJava(0x001d410);
  public final TsbLocation DEFENSE_REACTIONS_LOCATION =
      newLocationFromJava(0x001dc10);
  public final TsbLocation PLAY_GRAPHICS_LOCATION =
      newLocationFromJava(0x0027546);
  public final TsbLocation PLAY_BALLCARRIERS_LOCATION =
      newLocationFromJava(0x0027506);
  public final TsbLocation PLAYBOOKS_LOCATION = newLocationFromJava(0x001d310);
  public final TsbLocation FIRST_TEAM_NAME_POINTER_LOCATION =
      newLocationFromJava(0x001fc10);
  public final TsbLocation FIRST_TEAM_NAME_LOCATION =
      newLocationFromJava(0x001fd00);
  public final TsbLocation SPRITE_COLORS_LOCATION =
      newLocationFromJava(0x2c2e4);
  public final TsbLocation CUTSCENE_COLORS_LOCATION =
      newLocationFromJava(0x342d8);
  public final TsbLocation PLAYER_DATA_COLORS_LOCATION =
      newLocationFromJava(0x31140);
  public final TsbLocation RETURNERS_LOCATION_1 =
      newLocationFromJava(0x00239d3);
  public final TsbLocation RETURNERS_LOCATION_2 =
      newLocationFromJava(0x00328d3);
  public final TsbLocation PRO_BOWL_PLAYERS_LOCATION =
      newLocationFromJava(0x0032853);
  public final TsbLocation SIMULATION_CODE_LOCATION =
      newLocationFromJava(0x0018163);
  public final TsbLocation RUN_PASS_RATIO_LOCATION =
      newLocationFromJava(0x0027526);

  public final int MAX_TOTAL_NAMES_LENGTH =
      PLAYER_ATTRIBUTES_LOCATION.subtract(FIRST_PLAYER_NAME_LOCATION);

  public static final int TEAM_SIMULATION_CODE_SIZE_BYTES = 48;
  public static final int TEAM_SIMULATION_CODE_SIZE_NYBBLES =
      TEAM_SIMULATION_CODE_SIZE_BYTES * 2;
  public static final int TOTAL_SIMULATION_CODE_SIZE_NYBBLES =
      TEAM_SIMULATION_CODE_SIZE_NYBBLES * League.NES_TEAMS_COUNT;

  // http://www.knobbe.org/phpBB2/viewtopic.php?t=1820
  public final TsbLocation FORMATION_POSITION_SECTIONS_CODE_LOCATION =
      newLocationFromJava(0x0021642);
  public final TsbLocation FORMATION_POSITION_LABELS_CODE_LOCATION =
      newLocationFromJava(0x0030ff8);

  public final int[] FORMATION_POSITION_SECTIONS_CODE_PATCH =
      new int[] { 0x8a, 0xa6, 0x6e, 0xbc, 0xd0, 0x9f, 0xaa, 0x4c, 0x50, 0x96,
          0xf0, 0x12, 0xc9, 0x11 };
  public final int[] FORMATION_POSITION_LABELS_CODE_PATCH =
      new int[] { 0x8a, 0xa6, 0x6e, 0xbc, 0x70, 0x9e, 0xaa, 0xc0, 0x01, 0xf0,
          0x11, 0xc0, 0x02, 0xf0, 0x13, 0x4c, 0xfe, 0x8f, 0xc9, 0x11, 0xf0,
          0x0c, 0xbd, 0x39 };

  // public final TsbLocation
  // TODO TSB_ prefix?
  private static final int TSB_PLAYER_LOCATION_OFFSET = 0x00008000;
  private static final int TSB_TEAM_LOCATION_OFFSET = 0xfffec000;

  @Override
  public TsbLocation newLocationFromJava(int location)
  {
    return new TsbLocation(location);
  }

  public TsbLocation newLocationFromNESPlayerRelated(int location)
  {
    return new TsbLocation(playerRelatedToJava(location));
  }

  public TsbLocation newLocationFromNESTeamRelated(int location)
  {
    return new TsbLocation(teamRelatedToJava(location));
  }

  public class TsbLocation extends NesLocation
  {
    private TsbLocation(int javaLocation)
    {
      super(javaLocation);
    }

    public int getTSBPlayerRelatedLocation()
    {
      return javaToPlayerRelated(getJavaLocation());
    }

    public int getTSBTeamRelatedLocation()
    {
      return javaToTeamRelated(getJavaLocation());
    }

    @Override
    public TsbLocation add(int addend)
    {
      return newLocationFromJava(getJavaLocation() + addend);
    }
  }

  private static int swapUpperAndLowerBits(int i)
  {
    int upperBits = i & 0x0000FF00;
    int lowerBits = i & 0x000000FF;
    int swapped = (upperBits >> 8) | (lowerBits << 8);
    return swapped;
  }

  private static int nesToJava(int location, int offset)
  {
    int swapped = swapUpperAndLowerBits(location);
    int subtracted = swapped - offset;
    int movedPastHeader = subtracted + HEADER_LENGTH;

    return movedPastHeader;
  }

  private static int javaToNES(int location, int offset)
  {
    int movedPastHeader = location - HEADER_LENGTH;
    int added = movedPastHeader + offset;
    int swapped = swapUpperAndLowerBits(added);

    return swapped;
  }

  private static int playerRelatedToJava(int location)
  {
    return nesToJava(location, TSB_PLAYER_LOCATION_OFFSET);
  }

  private static int javaToPlayerRelated(int location)
  {
    return javaToNES(location, TSB_PLAYER_LOCATION_OFFSET);
  }

  private static int teamRelatedToJava(int location)
  {
    return nesToJava(location, TSB_TEAM_LOCATION_OFFSET);
  }

  private static int javaToTeamRelated(int location)
  {
    return javaToNES(location, TSB_TEAM_LOCATION_OFFSET);
  }

  public TsbFile(File file, String mode) throws FileNotFoundException
  {
    super(file, mode);
  }

  public TsbLocation readPlayerRelatedLocation() throws IOException
  {
    return newLocationFromNESPlayerRelated(raf.readUnsignedShort());
  }

  public void writePlayerRelatedLocation(TsbLocation location)
    throws IOException
  {
    raf.writeShort(location.getTSBPlayerRelatedLocation());
  }

  public TsbLocation readTeamRelatedLocation() throws IOException
  {
    return newLocationFromNESTeamRelated(raf.readUnsignedShort());
  }

  public void writeTeamRelatedLocation(TsbLocation location) throws IOException
  {
    raf.writeShort(location.getTSBTeamRelatedLocation());
  }

  @Override
  public TsbLocation getFileLocation() throws IOException
  {
    return newLocationFromJava((int) raf.getFilePointer());
  }
}
