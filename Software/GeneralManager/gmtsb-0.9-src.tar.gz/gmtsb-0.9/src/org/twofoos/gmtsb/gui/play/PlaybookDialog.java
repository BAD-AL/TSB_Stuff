/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.play;

import static org.twofoos.gmtsb.gui.util.GUIUtils.surroundWithTitleBorder;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.core.play.Page;
import org.twofoos.gmtsb.core.play.Play;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.UserEventAggregator;
import org.twofoos.gmtsb.userevent.UserEventListener;
import org.twofoos.gmtsb.userevent.intrinsic.team.PlayChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.RunPassRatioChangeEvent;

// TODO not modal -- internalframe instead
public class PlaybookDialog extends JDialog implements ActionListener,
    UserEventListener
{
  private static final long serialVersionUID = 452738158314001905L;

  private final MainFrame mainFrame;
  private final Team team;
  private final List<PlayButton> playButtons;
  private final RunPassRatioSlider runPassRatioSlider;

  public PlaybookDialog(MainFrame mainFrame, Team team)
  {
    super(mainFrame, "Playbook for " + team.getFullName(), true);

    this.mainFrame = mainFrame;
    this.team = team;

    setLayout(new BorderLayout());

    JPanel centerPanel = new JPanel();
    centerPanel.setLayout(new BorderLayout());

    JPanel playsPanel = new JPanel();
    playsPanel.setLayout(new GridLayout(2, Play.PAGES / 2));

    playButtons = new ArrayList<PlayButton>();

    for(Page page : Page.values())
    {
      PlayButton playButton = new PlayButton(this, page);
      playButtons.add(playButton);
      playsPanel.add(playButton);
    }

    centerPanel.add(playsPanel, BorderLayout.CENTER);

    runPassRatioSlider = new RunPassRatioSlider(mainFrame, team);
    JPanel runPassRatioPanel =
        surroundWithTitleBorder(runPassRatioSlider, "Play-calling ratio");

    centerPanel.add(runPassRatioPanel, BorderLayout.SOUTH);

    add(centerPanel, BorderLayout.CENTER);

    // TODO make smaller and center
    JButton doneButton = new JButton("Done");
    doneButton.addActionListener(this);
    add(doneButton, BorderLayout.SOUTH);

    getUserEventAggregator().subscribe(this);

    pack();

    setLocationRelativeTo(mainFrame);

    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
  }

  // TODO won't be necessary if converted to InternalFrame
  @Override
  public void dispose()
  {
    getUserEventAggregator().unsubscribe(PlaybookDialog.this);
    super.dispose();
  }

  public Team getTeam()
  {
    return team;
  }

  public MainFrame getMainFrame()
  {
    return mainFrame;
  }

  public UserEventAggregator getUserEventAggregator()
  {
    return getMainFrame().getUserEventAggregator();
  }

  public League getLeague()
  {
    return getMainFrame().getLeague();
  }

  public void actionPerformed(ActionEvent e)
  {
    dispose();
  }

  public void userEventPerformed(UserEvent e, boolean isUndoRedoEvent)
  {
    if(e instanceof PlayChangeEvent)
    {
      PlayChangeEvent playChangeEvent = (PlayChangeEvent) e;

      if(playChangeEvent.getSubject() != team)
      {
        return;
      }

      Page page = playChangeEvent.getPage();

      for(PlayButton button : playButtons)
      {
        button.playInPageUpdated(page);
      }
    }
    else if(e instanceof RunPassRatioChangeEvent)
    {
      RunPassRatioChangeEvent runPassRatioChangeEvent =
          (RunPassRatioChangeEvent) e;

      if(runPassRatioChangeEvent.getSubject() != team)
      {
        return;
      }

      runPassRatioSlider.setEnumValue(team.getRunPassRatio());
    }
  }
}
