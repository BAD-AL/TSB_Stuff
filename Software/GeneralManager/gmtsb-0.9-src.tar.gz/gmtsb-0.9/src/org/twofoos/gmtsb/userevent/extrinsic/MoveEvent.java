/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.extrinsic;

import java.util.List;

import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.IncompatiblePositionsException;
import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.userevent.UserEvent;

public class MoveEvent<D extends TSBTransferableData<D>> extends ExtrinsicEvent
{
  private final List<D> fromList;
  private final List<D> toList;
  private final int fromIndex;
  private final int toIndex;
  private final String name;

  private MoveEvent(List<D> fromList, List<D> toList, int fromIndex, int toIndex)
  {
    this.fromList = fromList;
    this.toList = toList;
    this.fromIndex = fromIndex;
    this.toIndex = toIndex;
    this.name = fromList.get(fromIndex).toString();
  }

  public static <D extends TSBTransferableData<D>> MoveEvent<D> createMoveEvent(
      List<D> fromList, List<D> toList, int fromIndex, int toIndex)
  {
    return new MoveEvent<D>(fromList, toList, fromIndex, toIndex);
  }

  public boolean doEvent() throws IncompatiblePositionsException
  {
    // See note at testPositionCompatibility() method.
    possiblyTestDepthPositionCompatibility(fromList, toList);

    D data = fromList.get(fromIndex);

    // We must deal with the specific case of moving a player within a single
    // position of a single team. Basically, the indexes (calculated beforehand
    // in movePlayerAfter(), etc.) are changed when someone is added or removed.
    if(fromList == toList)
    {
      if(toIndex == fromIndex || toIndex == fromIndex + 1)
      {
        // Not a move at all.
        return false;
      }
      else if(toIndex > fromIndex)
      {
        toList.add(toIndex, data);
        fromList.remove(data);
      }
      else
      {
        fromList.remove(data);
        toList.add(toIndex, data);
      }
    }
    else
    {
      fromList.remove(data);
      toList.add(toIndex, data);
    }

    return true;
  }

  public void undoEvent()
  {
    // Sadly, it is not always as simple as reversing the to and from locations.
    // Consider the case of moving the backup QB (index 1) to before the
    // starting QB (index 0).
    // If we move from 0 to 1 to try to reverse it, this is recognized as not a
    // move at all -- but we're undoing something, so clearly there should be a
    // move.
    // In short, the problem is that, when moving within a Depth, players other
    // than the one "officially" being moved are also moved.
    // At least, I *think* that's the problem.
    if(fromList == toList)
    {
      if(fromIndex < toIndex)
      {
        new MoveEvent<D>(fromList, fromList, toIndex - 1, fromIndex).doEvent();
      }
      else
      {
        new MoveEvent<D>(fromList, fromList, toIndex, fromIndex + 1).doEvent();
      }
    }
    else
    {
      new MoveEvent<D>(toList, fromList, toIndex, fromIndex).doEvent();
    }
  }

  public static <D extends TSBTransferableData<D>> MoveEvent<D> createMoveToBeforeEvent(
      List<D> fromList, List<D> toList, D data, D before)
  {
    return new MoveEvent<D>(fromList, toList, fromList.indexOf(data), toList
        .indexOf(before));
  }

  public static <D extends TSBTransferableData<D>> MoveEvent<D> createMoveToAfterEvent(
      List<D> fromList, List<D> toList, D data, D after)
  {
    return new MoveEvent<D>(fromList, toList, fromList.indexOf(data), toList
        .indexOf(after) + 1);
  }

  public static <D extends TSBTransferableData<D>> MoveEvent<D> createMoveToEndEvent(
      List<D> fromList, List<D> toList, D data)
  {
    return new MoveEvent<D>(fromList, toList, fromList.indexOf(data), toList
        .size());
  }

  public String getDescription()
  {
    return "Move " + name;
  }

  @Override
  public boolean isListAffected(List<?> list)
  {
    return list == fromList || list == toList;
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }

  // javac rejects without the cast
  @SuppressWarnings("cast")
  @Override
  public boolean isTeamEvent()
  {
    return (Object) fromList instanceof Division;
  }
}
