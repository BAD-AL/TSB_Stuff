/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui;

import org.twofoos.gmtsb.gui.util.SilentSetter;
import org.twofoos.gmtsb.gui.util.TextComponentChangeHandler;
import org.twofoos.gmtsb.gui.util.UpperCaseTextField;
import org.twofoos.gmtsb.userevent.UserEvent;

public abstract class EventReadyUCTextField extends UpperCaseTextField
{
  private static final long serialVersionUID = 5055491108884695744L;
  private final TextComponentChangeHandler handler;

  protected EventReadyUCTextField(String text, int columns)
  {
    super(text, columns);
    handler = new EventReadyUCTextFieldChangeHandler();
    getDocument().addDocumentListener(handler);
  }

  private class EventReadyUCTextFieldChangeHandler extends
      TextComponentChangeHandler
  {
    @Override
    protected void textChanged()
    {
      performAndPublish(createUserEvent());
    }
  }

  public void setTextSilent(String value)
  {
    SilentSetter.setTextSilent(this, value, handler);
  }

  protected abstract void performAndPublish(UserEvent e);

  protected abstract UserEvent createUserEvent();
}
