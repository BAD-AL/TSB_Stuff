/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.extrinsic;

import java.util.List;

import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.userevent.UserEvent;

public class DeleteEvent<D extends TSBTransferableData<D>> extends
    ExtrinsicEvent
{
  private final D data;
  private final List<D> list;
  private final int index;

  private DeleteEvent(List<D> list, D data)
  {
    this.data = data;
    this.list = list;
    this.index = list.indexOf(data);
  }

  // Not using a public constructor only to be consistent with PlayerMoveEvent.
  public static <D extends TSBTransferableData<D>> DeleteEvent<D> createDeleteEvent(
      List<D> list, D data)
  {
    return new DeleteEvent<D>(list, data);
  }

  public boolean doEvent()
  {
    list.remove(index);
    return true;
  }

  public void undoEvent()
  {
    list.add(index, data);
  }

  public String getDescription()
  {
    return "Delete " + data;
  }

  @Override
  public boolean isListAffected(List<?> list)
  {
    return list == this.list;
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }

  public D getData()
  {
    return data;
  }

  // javac rejects without the cast
  @SuppressWarnings("cast")
  @Override
  public boolean isTeamEvent()
  {
    return (Object) data instanceof Team;
  }
}
