/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player;

import static org.twofoos.gmtsb.gui.util.ListModelList.asList;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.InternalFrame;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.util.ComponentSizeIncrementScrollPane;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.extrinsic.ExtrinsicEvent;
import org.twofoos.gmtsb.userevent.extrinsic.CreateEvent.CreatePlayerEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

// TODO set max and min width on JScrollPane?
public class TeamFrame extends InternalFrame implements ActionListener
{
  private static final long serialVersionUID = -1817335944874348132L;

  private final JComboBox teamBox;
  private final JComboBox positionBox;
  private final JButton createPlayerButton;
  private final DefaultComboBoxModel teamBoxModel;

  private final DepthPanel depthPanel;

  private static Dimension DEPTH_SCROLL_PANE_SIZE;
  static Dimension PLAYER_PANEL_SIZE;

  private void calculateSizes()
  {
    // Position in the next line is QB because QB has the most attributes.
    // We want to make sure they all fit on the screen.
    DepthPanel depthPanel =
        new DepthPanel(getMainFrame(), new Team().getDepth(Position.QB));
    JScrollPane depthScrollPane =
        new ComponentSizeIncrementScrollPane(depthPanel,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    Player emptyPlayer = new Player(Position.QB, "", "", 99);
    for(Attribute currentAttribute : Position.QB.getAttributeList())
    {
      // Max value so that spinners are as large as necessary.
      emptyPlayer.setComputerAttribute(currentAttribute, 15);
    }
    for(int j = 0; j < 6; j++)
    {
      PlayerPanel playerPanel = new PlayerPanel(depthPanel, emptyPlayer);
      depthPanel.add(playerPanel);
      if(j == 0)
      {
        PLAYER_PANEL_SIZE = playerPanel.getPreferredSize();
      }
    }

    DEPTH_SCROLL_PANE_SIZE = depthScrollPane.getPreferredSize();
  }

  private Dimension getDepthScrollPanePreferredSize()
  {
    if(DEPTH_SCROLL_PANE_SIZE == null)
    {
      calculateSizes();
    }

    return DEPTH_SCROLL_PANE_SIZE;
  }

  public TeamFrame(MainFrame mainFrame, Team team)
  {
    this(mainFrame, team, Position.QB);
  }

  public TeamFrame(MainFrame mainFrame, Team team, Position position)
  {
    super(mainFrame);

    Container contentPane = getContentPane();
    contentPane.setLayout(new BorderLayout());

    depthPanel = new DepthPanel(mainFrame, team.getDepth(position));
    JScrollPane depthScrollPane =
        new ComponentSizeIncrementScrollPane(depthPanel,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    JPanel teamAndPositionSelectorPanel = new JPanel();

    teamAndPositionSelectorPanel.setLayout(new BoxLayout(
        teamAndPositionSelectorPanel, BoxLayout.X_AXIS));

    JLabel teamLabel = new JLabel("Team: ");
    teamBoxModel = new DefaultComboBoxModel(getLeague().teamsVector());
    teamBox = new JComboBox(teamBoxModel);
    teamBox.setSelectedItem(team);
    teamBox.addActionListener(this);
    JLabel positionLabel = new JLabel("Position: ");
    positionBox = new JComboBox(Position.allPositionsVector());
    positionBox.setSelectedItem(position);
    positionBox.addActionListener(this);

    teamAndPositionSelectorPanel.add(teamLabel);
    teamAndPositionSelectorPanel.add(teamBox);
    teamAndPositionSelectorPanel.add(positionLabel);
    teamAndPositionSelectorPanel.add(positionBox);

    depthScrollPane.setPreferredSize(getDepthScrollPanePreferredSize());

    createPlayerButton = new JButton("Create Player");
    createPlayerButton.addActionListener(this);

    contentPane.add(teamAndPositionSelectorPanel, BorderLayout.NORTH);
    contentPane.add(depthScrollPane, BorderLayout.CENTER);
    contentPane.add(createPlayerButton, BorderLayout.SOUTH);

    setTitle();

    pack();
  }

  @Override
  public void dispose()
  {
    getMainFrame().getTeamFrames().remove(this);
    super.dispose();
  }

  @Override
  public void addToMainFrame()
  {
    super.addToMainFrame();
    getMainFrame().getTeamFrames().add(this);
  }

  public void changeTeamAndPosition(Team team, Position position)
  {
    depthPanel.changeDepth(team.getDepth(position));
    setTitle();
    revalidate();
    repaint();
  }

  public String getDescription()
  {
    return getPosition() + " - " + getTeam();
  }

  private void setTitle()
  {
    setTitle(getDescription());
  }

  public void changePosition(Position position)
  {
    changeTeamAndPosition(getTeam(), position);
  }

  public Team getTeam()
  {
    return depthPanel.getTeam();
  }

  public Position getPosition()
  {
    return depthPanel.getPosition();
  }

  public void actionPerformed(ActionEvent e)
  {
    Object source = e.getSource();
    if(source == teamBox || source == positionBox)
    {
      /*
       * Make sure we're not in the middle of removing all the teams and
       * re-adding them (which triggers an action).
       */
      if(teamBoxModel.getSize() > 0)
      {
        changeTeamAndPosition((Team) teamBox.getSelectedItem(),
            (Position) positionBox.getSelectedItem());
      }
    }
    else if(source == createPlayerButton)
    {
      // TODO this ends up being somewhat slow, so I may want to work on
      // threaded UserEvent handling
      CreatePlayerEvent playerCreateEvent =
          CreatePlayerEvent.createCreatePlayerEvent(depthPanel.getDepth());
      performAndPublish(playerCreateEvent);
    }
  }

  @Override
  protected void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    // Team renames can change the ordering.
    possibleRowStructureChange(getLeague().teamsVector());

    depthPanel.intrinsicTeamEventPerformed(event, isUndoRedoEvent);
  }

  @Override
  protected void intrinsicPlayerEventPerformed(IntrinsicEvent<Player, ?> event,
      boolean isUndoRedoEvent)
  {
    depthPanel.intrinsicPlayerEventPerformed(event, isUndoRedoEvent);
  }

  @Override
  protected void extrinsicEventPerformed(ExtrinsicEvent event,
      boolean isUndoRedoEvent)
  {
    if(event.isTeamEvent())
    {
      List<Team> newTeams = getLeague().teamsVector();

      if(newTeams.isEmpty())
      {
        dispose();
        return;
      }

      possibleRowStructureChange(newTeams);
    }

    /*
     * Do this after the other changes so that the removal of the last team
     * disposes of this frame and exits before we try to update it.
     */
    depthPanel.extrinsicEventPerformed(event, isUndoRedoEvent);
  }

  private void possibleRowStructureChange(List<Team> newTeams)
  {
    Object selected = teamBoxModel.getSelectedItem();

    teamBoxModel.removeAllElements();
    asList(teamBoxModel).addAll(newTeams);

    if(newTeams.contains(selected))
    {
      teamBoxModel.setSelectedItem(selected);
    }
    else
    {
      teamBox.setSelectedIndex(0);
    }
  }

  @Override
  public void paint(Graphics g)
  {
    super.paint(g);
  }

  @Override
  protected void otherEventPerformed(UserEvent event, boolean isUndoRedoEvent)
  {
    depthPanel.otherEventPerformed(event, isUndoRedoEvent);
  }
}
