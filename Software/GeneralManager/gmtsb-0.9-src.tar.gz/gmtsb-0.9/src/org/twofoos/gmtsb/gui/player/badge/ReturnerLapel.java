/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player.badge;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import org.twofoos.gmtsb.core.ReturnJob;
import org.twofoos.gmtsb.gui.player.PlayerPanel;
import org.twofoos.gmtsb.userevent.intrinsic.team.ReturnerChangeEvent;

public class ReturnerLapel extends Lapel
{
  private static final long serialVersionUID = -3707615854508462996L;

  private final ReturnJob returnJob;

  public ReturnerLapel(PlayerPanel playerPanel, ReturnJob returnJob)
  {
    // TODO have isEnabled decided by whether the player is a ROM player, too
    super(playerPanel, returnJob.getAbbreviation(), returnJob.getDescription());

    setEnabled(playerPanel.getPlayer().isValidReturnerPosition());

    this.returnJob = returnJob;
  }

  private static final JLabel FOOTBALL_LABEL =
      createTransparentImageLabel("football.png");
  private static final JLabel KR_LABEL =
      new OverlayTextLabel(ReturnJob.KR.getAbbreviation());
  private static final JLabel PR_LABEL =
      new OverlayTextLabel(ReturnJob.PR.getAbbreviation());

  private static JLabel getReturnJobLabel(ReturnJob returnJob)
  {
    switch(returnJob)
    {
      case KR:
        return KR_LABEL;

      case PR:
        return PR_LABEL;

      default:
        return null;
    }
  }

  @Override
  public void paint(Graphics g)
  {
    super.paint(g);

    if(getTeam().getReturner(returnJob) == getPlayer())
    {
      paintSemiTransparentComponent(g, FOOTBALL_LABEL);
      paintFullyTransparentComponent(g, getReturnJobLabel(returnJob));
    }
  }

  private boolean isReturner(ReturnJob returnJob)
  {
    return getTeam().getReturner(returnJob) == getPlayer();
  }

  private String text(ReturnJob returnJob)
  {
    if(isReturner(returnJob))
    {
      return "Currently assigned " + returnJob;
    }

    return "Assign as " + returnJob.getAbbreviation();
  }

  @Override
  protected void menuActivated(JMenu menu)
  {
    menu.removeAll();

    if(getPlayer().isValidReturnerPosition())
    {
      menu.add(new MenuItem());
    }
    else
    {
      JMenuItem notValidReturnerPositionItem =
          new JMenuItem(getPosition()
              + " is not a valid position for a returner");
      notValidReturnerPositionItem.setEnabled(false);
      menu.add(notValidReturnerPositionItem);
    }
  }

  private class MenuItem extends JMenuItem implements ActionListener
  {
    private static final long serialVersionUID = -2817889176482206478L;

    private MenuItem()
    {
      super(text(returnJob), KeyEvent.VK_R);
      setEnabled(!isReturner(returnJob));
      addActionListener(this);
    }

    public void actionPerformed(ActionEvent e)
    {
      performAndPublish(new ReturnerChangeEvent(getTeam(), returnJob, getTeam()
          .getReturner(returnJob), getPlayer()));
    }
  }
}
