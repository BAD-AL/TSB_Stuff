/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import static org.twofoos.gmtsb.gui.team.LeagueFrame.scaleComponent;
import static org.twofoos.gmtsb.gui.util.GUIUtils.BUTTON_VERTICAL_INSETS;
import static org.twofoos.gmtsb.gui.util.GUIUtils.gridBagAdd;
import static org.twofoos.gmtsb.gui.util.GUIUtils.resetCursor;
import static org.twofoos.gmtsb.util.iterators.Pair.pairIterable;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.TransferablePanel;
import org.twofoos.gmtsb.gui.play.PlaybookButton;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.UserEventAggregator;
import org.twofoos.gmtsb.userevent.extrinsic.DeleteEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.AbbreviationChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.CityChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.NameChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.OffensiveFormationChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.SpriteColorsChangeEvent;
import org.twofoos.gmtsb.util.iterators.Pair;

public class TeamPanel extends TransferablePanel<Team> implements
    ActionListener
{
  private static final long serialVersionUID = 9052353697670104042L;

  private final DivisionPanel divisionPanel;

  private final Team team;

  @SuppressWarnings("unused")
  private final LogoButton logoButton;
  private final CityField cityField;
  private final NameField nameField;
  private final AbbreviationField abbreviationField;
  private final JButton deleteButton;
  private final JButton rosterButton;
  private final JButton notesButton;
  private final SpriteColorsButton spriteColorsButton;
  private final OffensiveFormationComboBox offensiveFormationComboBox;

  TeamPanel(DivisionPanel divisionPanel, Team team)
  {
    super(divisionPanel.getMainFrame().getTeamTransferHandler());

    this.divisionPanel = divisionPanel;
    this.team = team;

    GridBagLayout layout = new GridBagLayout();
    setLayout(layout);

    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = GUIUtils.EMPTY_INSETS;

    // Logo button.

    constraints.gridheight = 3;
    constraints.gridwidth = 1;
    constraints.weightx = 4.0 / 17;
    constraints.weighty = 1.0;
    constraints.anchor = GridBagConstraints.CENTER;
    constraints.gridx = 0;
    constraints.gridy = 0;

    // TODO implement
    // logoButton = new LogoButton(this);
    // gridBagAdd(this, layout, constraints, logoButton);
    logoButton = null;

    gridBagAdd(this, layout, constraints, new JPanel());

    // Name fields.

    // TODO size
    cityField = new CityField(this, team.getCity(), 12);
    nameField = new NameField(this, team.getName(), 12);
    abbreviationField = new AbbreviationField(this, team.getAbbreviation(), 3);

    List<JLabel> labels =
        Arrays.asList(new JLabel("City: "), new JLabel("Name: "), new JLabel(
            "Abbr: "));
    List<? extends JTextField> textFields =
        Arrays.asList(cityField, nameField, abbreviationField);

    int y = 0;

    spriteColorsButton = new SpriteColorsButton(this);

    for(Pair<JLabel, ? extends JTextField> labelAndTextField : pairIterable(
        labels, textFields))
    {
      JLabel label = labelAndTextField.getFirst();
      JTextField textField = labelAndTextField.getSecond();

      label.setLabelFor(textField);

      constraints.gridheight = 1;
      constraints.gridwidth = 1;
      // constraints.gridwidth = GridBagConstraints.RELATIVE;
      constraints.weightx = 0; // 3.0 / 17;
      constraints.weighty = .25;
      constraints.anchor = GridBagConstraints.EAST;
      constraints.gridx = 1;
      constraints.gridy = y;

      gridBagAddScaled(this, layout, constraints, label);

      constraints.gridheight = 1;
      constraints.gridwidth = 1;
      constraints.gridwidth = GridBagConstraints.RELATIVE;
      constraints.weightx = 0; // 7.0 / 17;
      constraints.weighty = .25;
      constraints.anchor = GridBagConstraints.WEST;
      constraints.gridx = 2;
      constraints.gridy = y;

      gridBagAddScaled(this, layout, constraints, textField);

      y++;
    }

    constraints.gridheight = 3;
    constraints.gridwidth = GridBagConstraints.REMAINDER;
    constraints.weightx = 3.0 / 17;
    constraints.weighty = .75;
    constraints.anchor = GridBagConstraints.CENTER;
    constraints.gridx = 3;
    constraints.gridy = 0;

    gridBagAddScaled(this, layout, constraints, spriteColorsButton);

    constraints.gridheight = 1;
    constraints.gridwidth = GridBagConstraints.REMAINDER;
    constraints.weightx = 1;
    constraints.weighty = 1;
    constraints.anchor = GridBagConstraints.CENTER;
    constraints.gridx = 0;
    constraints.gridy = y;

    JPanel bottomPanel = new JPanel();

    gridBagAdd(this, layout, constraints, bottomPanel);

    deleteButton = createAndAddButton(bottomPanel, "Delete");

    offensiveFormationComboBox = new OffensiveFormationComboBox(this);
    scaleComponent(offensiveFormationComboBox);
    bottomPanel.add(offensiveFormationComboBox);

    bottomPanel.add(new PlaybookButton(this));

    rosterButton = createAndAddButton(bottomPanel, "Roster");

    notesButton = createAndAddButton(bottomPanel, "Notes");
  }

  private JButton createAndAddButton(JPanel container, String label)
  {
    JButton newButton = new JButton(label);
    scaleComponent(newButton);
    resetCursor(newButton);
    newButton.setMargin(BUTTON_VERTICAL_INSETS);
    container.add(newButton);
    newButton.addActionListener(this);

    return newButton;
  }

  private void gridBagAddScaled(Container contentPane, GridBagLayout layout,
      GridBagConstraints constraints, Component component)
  {
    gridBagAdd(contentPane, layout, constraints, scaleComponent(component));
  }

  @Override
  public Dimension getMaximumSize()
  {
    return getPreferredSize();
  }

  @Override
  public Dimension getMinimumSize()
  {
    return getPreferredSize();
  }

  public Division getDivision()
  {
    return divisionPanel.getDivision();
  }

  public MainFrame getMainFrame()
  {
    return divisionPanel.getMainFrame();
  }

  public UserEventAggregator getUserEventAggregator()
  {
    return getMainFrame().getUserEventAggregator();
  }

  public void performAndPublish(UserEvent e)
  {
    getUserEventAggregator().performAndPublish(e);
  }

  public Team getTeam()
  {
    return team;
  }

  @Override
  public Team getData()
  {
    return getTeam();
  }

  @Override
  public List<Team> getList()
  {
    return getDivision();
  }

  // Events are delegated from LeagueFrame; TeamPanel isn't actually a
  // listener.
  public void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    if(event instanceof SpriteColorsChangeEvent)
    {
      spriteColorsButton.updateIcon();
    }

    // Note that there is one and only one TeamPanel for each Team, so we know
    // this is always the TeamPanel that the user made the change in. Thus, the
    // only time that we need to do anything is in the case of undo/redo.

    if(!isUndoRedoEvent)
    {
      return;
    }

    if(event instanceof AbbreviationChangeEvent)
    {
      abbreviationField.setTextSilent(getTeam().getAbbreviation());
    }
    else if(event instanceof CityChangeEvent)
    {
      cityField.setTextSilent(getTeam().getCity());
    }
    else if(event instanceof NameChangeEvent)
    {
      nameField.setTextSilent(getTeam().getName());
    }
    else if(event instanceof OffensiveFormationChangeEvent)
    {
      offensiveFormationComboBox.setSelectedItem(getTeam()
          .getOffensiveFormation());
    }
  }

  public void actionPerformed(ActionEvent e)
  {
    Object source = e.getSource();
    if(source == deleteButton)
    {
      DeleteEvent<Team> deleteEvent =
          DeleteEvent.createDeleteEvent(getDivision(), getTeam());
      performAndPublish(deleteEvent);
    }
    else if(source == rosterButton)
    {
      getMainFrame().showTeamFrame(getTeam());
    }
    else if(source == notesButton)
    {
      getMainFrame().showNotesFrame(getTeam());
    }
  }
}
