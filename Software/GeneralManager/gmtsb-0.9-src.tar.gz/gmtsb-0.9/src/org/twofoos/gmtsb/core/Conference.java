/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Iterables.concat;

import java.util.List;

import com.google.common.collect.ImmutableList;

public class Conference
{
  private final League league;
  private final AFC_NFC_Other afcNFCOther;
  private final List<Division> divisions;
  private final ProBowlTeam proBowlTeam;
  private String name;

  Conference(League league, AFC_NFC_Other afcNFCOther, String name)
  {
    this.league = league;
    this.afcNFCOther = afcNFCOther;
    this.name = name;

    proBowlTeam = new ProBowlTeam(this);

    // TODO any reason to actually include the names?

    switch(afcNFCOther)
    {
      case AFC:
      {
        Division east = new Division(this, 5, "EAST");
        Division central = new Division(this, 4, "CENTRAL");
        Division west = new Division(this, 5, "WEST");
        divisions = ImmutableList.of(east, central, west);
        break;
      }

      case NFC:
      {
        Division east = new Division(this, 5, "EAST");
        Division central = new Division(this, 5, "CENTRAL");
        Division west = new Division(this, 4, "WEST");
        divisions = ImmutableList.of(east, central, west);
        break;
      }

      case OTHER:
      default:
      {
        Division other = new Division(this, 0, "OTHER");
        divisions = ImmutableList.of(other);
        break;
      }
    }
  }

  public Iterable<Division> getDivisions()
  {
    return divisions;
  }

  public ProBowlTeam getProBowlTeam()
  {
    return proBowlTeam;
  }

  public String getName()
  {
    return name;
  }

  // TODO use where appropriate
  public Iterable<Team> getTeams()
  {
    return concat(getDivisions());
  }

  public boolean containsTeam(Team team)
  {
    for(Division division : getDivisions())
    {
      if(division.contains(team))
      {
        return true;
      }
    }

    return false;
  }

  public AFC_NFC_Other getAFCNFCOther()
  {
    return afcNFCOther;
  }

  @Override
  public String toString()
  {
    return afcNFCOther.toString();
  }

  public League getLeague()
  {
    return league;
  }
}
