/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.chooser;

import java.util.ArrayList;
import java.util.List;

import org.twofoos.gmtsb.gui.util.PromptDialog;

public class Chooser<T> extends PromptDialog<T>
{
  private static final long serialVersionUID = 3539733787199022667L;

  private final List<SelectionListener> selectionListeners =
      new ArrayList<SelectionListener>();

  private final ChooserPanel<T> choicePanel;

  public Chooser(ChooserPanel<T> choicePanel)
  {
    super(choicePanel.getChooserOwner(), choicePanel.getTitle(), choicePanel);

    this.choicePanel = choicePanel;

    choicePanel.setChooser(this);
  }

  @Override
  protected T getSelectedData()
  {
    return choicePanel.getSelectedData();
  }

  // TODO Observer/Observable?
  public void addSelectionListener(SelectionListener selectionListener)
  {
    selectionListeners.add(selectionListener);
  }

  public void notifySelectionListeners()
  {
    for(SelectionListener selectionListener : selectionListeners)
    {
      selectionListener.selectionChanged();
    }
  }
}
