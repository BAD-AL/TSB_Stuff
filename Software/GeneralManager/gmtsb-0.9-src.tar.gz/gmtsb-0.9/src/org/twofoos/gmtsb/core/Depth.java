/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import java.util.ArrayList;

public class Depth extends ArrayList<Player>
{
  private static final long serialVersionUID = -2338173322717624068L;

  private final Team team;
  private final Position position;

  public Depth(Team team, Position position)
  {
    // TODO might want to size this based on the position and maybe even
    // formation
    super(4);
    this.team = team;
    this.position = position;
  }

  public Team getTeam()
  {
    return team;
  }

  public Position getPosition()
  {
    return position;
  }

  // TODO should still probably check position compatibility in places like this
  // public void add(Player player)

  public boolean isCompatibleWith(Depth other)
  {
    return this.getPosition().isCompatibleWith(other.getPosition());
  }

  @Override
  public String toString()
  {
    return team + " " + position + "'s";
  }
}