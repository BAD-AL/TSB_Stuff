/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import static com.google.common.collect.Sets.newHashSet;
import static org.twofoos.gmtsb.gui.team.SpritePreviewImageIconUtil.newSpriteImageIconWithPaletteSmall;
import static org.twofoos.gmtsb.gui.util.GUIUtils.gridSize;
import static org.twofoos.gmtsb.util.iterators.Pair.pair;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.Set;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.util.PromptDialog;
import org.twofoos.gmtsb.util.iterators.Pair;

public class AlternateUniformCodeDialog extends
    PromptDialog<Pair<Set<Team>, Set<Team>>>
{
  private final PromptPanel promptPanel;

  protected AlternateUniformCodeDialog(TeamPanel teamPanel)
  {
    this(teamPanel, new PromptPanel(teamPanel));
  }

  protected AlternateUniformCodeDialog(TeamPanel teamPanel,
      PromptPanel promptPanel)
  {
    super(teamPanel.getMainFrame(), teamPanel.getTeam().getFullName()
        + " and Opponents Alternate Uniform Cases", promptPanel);
    this.promptPanel = promptPanel;
  }

  private static final class PromptPanel extends JPanel
  {
    private final Set<TeamCheckBox> thisTeamCheckBoxes;
    private final Set<TeamCheckBox> otherTeamCheckBoxes;

    private PromptPanel(TeamPanel teamPanel)
    {
      thisTeamCheckBoxes = newHashSet();
      otherTeamCheckBoxes = newHashSet();

      setLayout(new BorderLayout());

      add(new JLabel("Click a uniform to switch between primary and secondary"
          + " uniforms for that matchup.", SwingConstants.CENTER),
          BorderLayout.NORTH);

      JPanel mainPanel =
          createMainPanel(teamPanel.getMainFrame().getLeague(), teamPanel
              .getTeam(), thisTeamCheckBoxes, otherTeamCheckBoxes);
      add(mainPanel, BorderLayout.CENTER);
    }

    private static final long serialVersionUID = -1714031502791188266L;
  }

  private static JPanel createMainPanel(League league, Team thisTeam,
      Set<TeamCheckBox> thisTeamCheckBoxes,
      Set<TeamCheckBox> otherTeamCheckBoxes)
  {
    UniformGridBagPanel panel = new UniformGridBagPanel();

    int i = 0;
    for(Team otherTeam : league.teams())
    {
      if(thisTeam == otherTeam)
      {
        continue;
      }

      JLabel label =
          new JLabel("vs. " + otherTeam.getFullName(), SwingConstants.LEFT);
      panel.add(label, false, GridBagConstraints.WEST);

      TeamCheckBox thisTeamCheckBox = new TeamCheckBox(thisTeam, otherTeam);
      panel.add(thisTeamCheckBox, false, GridBagConstraints.CENTER);
      thisTeamCheckBoxes.add(thisTeamCheckBox);

      TeamCheckBox otherTeamCheckBox = new TeamCheckBox(otherTeam, thisTeam);
      panel.add(otherTeamCheckBox, i % 3 == 2, GridBagConstraints.CENTER);
      otherTeamCheckBoxes.add(otherTeamCheckBox);

      // We don't want this to happen if thisTeam == otherTeam.
      i++;
    }
    return panel;
  }

  private static final class UniformGridBagPanel extends JPanel
  {
    private final GridBagLayout layout = new GridBagLayout();
    private final GridBagConstraints constraints = gridSize(1, 1);

    private UniformGridBagPanel()
    {
      setLayout(layout);
    }

    public Component add(Component comp, boolean isEndOfLine, int anchor)
    {
      constraints.anchor = anchor;

      if(isEndOfLine)
      {
        constraints.gridwidth = GridBagConstraints.REMAINDER;
      }
      else
      {
        constraints.gridwidth = 1;
      }

      layout.setConstraints(comp, constraints);
      return add(comp);
    }

    private static final long serialVersionUID = -1518240072562842056L;
  }

  private static class TeamCheckBox extends JCheckBox
  {
    private final Team teamUnderEdit;
    private final Team opponent;

    private TeamCheckBox(Team teamUnderEdit, Team opponent)
    {
      super(newSpriteImageIconWithPaletteSmall(teamUnderEdit, 1));
      setSelectedIcon(newSpriteImageIconWithPaletteSmall(teamUnderEdit, 2));

      if(teamUnderEdit.getWearsAlternateUniformWhenPlayingTeam(opponent))
      {
        setSelected(true);
      }

      this.teamUnderEdit = teamUnderEdit;
      this.opponent = opponent;
    }

    private static final long serialVersionUID = 3298630144752423222L;
  }

  @Override
  protected Pair<Set<Team>, Set<Team>> getSelectedData()
  {
    Set<Team> thisTeamsWearsAlternateUniformVs = newHashSet();
    Set<Team> otherTeamsThatWearAlternateUniformVsThis = newHashSet();

    for(TeamCheckBox checkBox : promptPanel.thisTeamCheckBoxes)
    {
      if(checkBox.isSelected())
      {
        thisTeamsWearsAlternateUniformVs.add(checkBox.opponent);
      }
    }

    for(TeamCheckBox checkBox : promptPanel.otherTeamCheckBoxes)
    {
      if(checkBox.isSelected())
      {
        otherTeamsThatWearAlternateUniformVsThis.add(checkBox.teamUnderEdit);
      }
    }

    return pair(thisTeamsWearsAlternateUniformVs,
        otherTeamsThatWearAlternateUniformVsThis);
  }

  private static final long serialVersionUID = -2128306298803744895L;
}
