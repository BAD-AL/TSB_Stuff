/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui;

import static org.twofoos.gmtsb.gui.util.SilentSetter.setTextSilent;
import static org.twofoos.gmtsb.userevent.intrinsic.NotesChangeEvent.createNotesChangeEvent;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.twofoos.gmtsb.core.Notable;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.util.TextComponentChangeHandler;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.extrinsic.DeleteEvent;
import org.twofoos.gmtsb.userevent.extrinsic.ExtrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.NotesChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.FirstNameChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.LastNameChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.CityChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.NameChangeEvent;

public class NotesFrame<D extends TSBTransferableData<D> & Notable> extends
    InternalFrame
{
  private static final long serialVersionUID = 3944036070141701701L;
  private final D notable;
  private final JTextArea textArea;
  private final TextComponentChangeHandler handler;

  public NotesFrame(MainFrame mainFrame, D notable)
  {
    super(mainFrame);
    this.notable = notable;

    updateTitle();

    textArea = new JTextArea(notable.getNotes(), 18, 40);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    JScrollPane scollPane = new JScrollPane(textArea);
    getContentPane().add(scollPane);

    handler = new NotesFrameTextAreaChangeHandler();
    textArea.getDocument().addDocumentListener(handler);

    pack();
  }

  private void updateTitle()
  {
    setTitle("Notes for " + notable);
  }

  @Override
  public void dispose()
  {
    getMainFrame().removeNotesFrame(notable);
    super.dispose();
  }

  private class NotesFrameTextAreaChangeHandler extends
      TextComponentChangeHandler
  {
    @Override
    protected void textChanged()
    {
      performAndPublish(createUserEvent());
    }
  }

  private UserEvent createUserEvent()
  {
    String from = notable.getNotes();
    String to = textArea.getText();
    return createNotesChangeEvent(notable, from, to, textArea);
  }

  @Override
  protected void extrinsicEventPerformed(ExtrinsicEvent event,
      boolean isUndoRedoEvent)
  {
    if(event instanceof DeleteEvent)
    {
      if(notable == ((DeleteEvent<?>) event).getData())
      {
        dispose();
      }
    }
  }

  @Override
  protected void intrinsicPlayerEventPerformed(IntrinsicEvent<Player, ?> event,
      boolean isUndoRedoEvent)
  {
    anyIntrinsicEventPerformed(event, isUndoRedoEvent);
  }

  @Override
  protected void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    anyIntrinsicEventPerformed(event, isUndoRedoEvent);
  }

  private void anyIntrinsicEventPerformed(IntrinsicEvent<?, ?> event,
      boolean isUndoRedoEvent)
  {
    if(event.getSubject() != notable)
    {
      return;
    }

    if(event instanceof NotesChangeEvent<?>)
    {
      NotesChangeEvent<?> notesChangeEvent = (NotesChangeEvent<?>) event;

      // Don't modify the text of the field where the user made the change.
      // Doing so moves the caret, which is annoying.
      if(notesChangeEvent.getSource() == textArea && !isUndoRedoEvent)
      {
        return;
      }

      setTextSilent(textArea, notesChangeEvent.getSubject().getNotes(), handler);
    }
    // javac bug? It will not compile these as "event instanceof FooEvent"
    else if(CityChangeEvent.class.isInstance(event)
        || NameChangeEvent.class.isInstance(event)
        || FirstNameChangeEvent.class.isInstance(event)
        || LastNameChangeEvent.class.isInstance(event))
    {
      updateTitle();
    }
  }

  @Override
  protected void otherEventPerformed(UserEvent event, boolean isUndoRedoEvent)
  {
  }
}
