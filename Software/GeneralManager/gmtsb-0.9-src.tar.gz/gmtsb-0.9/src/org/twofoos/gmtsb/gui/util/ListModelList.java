/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import java.util.AbstractList;
import java.util.List;

import javax.swing.ListModel;
import javax.swing.MutableComboBoxModel;

public class ListModelList extends AbstractList<Object>
{
  private final ListModel listModel;

  private ListModelList(ListModel listModel)
  {
    this.listModel = listModel;
  }

  @Override
  public Object get(int index)
  {
    return listModel.getElementAt(index);
  }

  @Override
  public int size()
  {
    return listModel.getSize();
  }

  @Override
  public void add(int index, Object element)
  {
    if(listModel instanceof MutableComboBoxModel)
    {
      MutableComboBoxModel mutableModel = (MutableComboBoxModel) listModel;
      mutableModel.insertElementAt(element, index);
    }
    else
    {
      throw new UnsupportedOperationException();
    }
  }

  public static List<Object> asList(ListModel listModel)
  {
    return new ListModelList(listModel);
  }
}
