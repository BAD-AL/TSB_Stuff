/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.twofoos.gmtsb.core.Conference;
import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.util.ComponentSizeIncrementScrollPane;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.extrinsic.ExtrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

public class ConferencePanel extends JPanel
{
  private static final long serialVersionUID = 8610487495296040869L;

  // private final JTextField nameField;
  private final List<DivisionPanel> divisionPanels;
  private final LeagueFrame leagueFrame;

  ConferencePanel(LeagueFrame leagueFrame, Conference conference)
  {
    // nameField = new ConferenceField(this, conference.getName());
    this.leagueFrame = leagueFrame;

    setBorder(BorderFactory.createEtchedBorder());

    JPanel headerPanel = new JPanel();
    // headerPanel
    // .add(LeagueFrame.scaleComponent(new JLabel("Conference Name: ")));
    // headerPanel.add(LeagueFrame.scaleComponent(nameField));
    headerPanel.add(new JLabel(conference.getName()));

    divisionPanels = new ArrayList<DivisionPanel>(3);
    List<JScrollPane> divisionScrollPanes = new ArrayList<JScrollPane>(3);

    JPanel allDivisionsPanel = new JPanel();
    allDivisionsPanel.setLayout(new BoxLayout(allDivisionsPanel,
        BoxLayout.X_AXIS));

    for(Division division : conference.getDivisions())
    {
      DivisionPanel divisionPanel = new DivisionPanel(getMainFrame(), division);
      divisionPanels.add(divisionPanel);

      JScrollPane divisionScrollPane =
          new ComponentSizeIncrementScrollPane(divisionPanel,
              JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
              JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      divisionScrollPanes.add(divisionScrollPane);

      divisionScrollPane.setPreferredSize(leagueFrame
          .getDivisionScrollPaneSize());

      allDivisionsPanel.add(divisionScrollPane);
    }

    setLayout(new BorderLayout());
    add(headerPanel, BorderLayout.NORTH);
    add(allDivisionsPanel, BorderLayout.CENTER);
  }

  private LeagueFrame getLeagueFrame()
  {
    return leagueFrame;
  }

  private MainFrame getMainFrame()
  {
    return getLeagueFrame().getMainFrame();
  }

  public void performAndPublish(UserEvent e)
  {
    getLeagueFrame().performAndPublish(e);
  }

  // Events are delegated from LeagueFrame; DivisionPanel isn't actually a
  // listener.
  void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    for(DivisionPanel divisionPanel : divisionPanels)
    {
      divisionPanel.intrinsicTeamEventPerformed(event, isUndoRedoEvent);
    }
  }

  void extrinsicEventPerformed(ExtrinsicEvent event, boolean isUndoRedoEvent)
  {
    for(DivisionPanel divisionPanel : divisionPanels)
    {
      divisionPanel.extrinsicEventPerformed(event, isUndoRedoEvent);
    }
  }
}
