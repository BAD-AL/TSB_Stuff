/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import static org.twofoos.gmtsb.gui.util.GUIUtils.resetCursor;
import static org.twofoos.gmtsb.gui.util.MacApplication.isMac;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;

import com.google.common.base.Supplier;

public abstract class MenuButton extends JMenuBar
{
  private final JButton enabledAppearance;
  private final JButton disabledAppearance;
  private final JButton armedAppearance;
  private final JButton rolloverAppearance;

  private boolean enabled = true;
  private boolean armed = false;
  private boolean rollover = false;

  private final MenuButtonMenu menu;

  protected MenuButton(Supplier<JButton> appearanceSupplier, String tooltipText)
  {
    resetCursor(this);

    enabledAppearance = appearanceSupplier.get();

    disabledAppearance = appearanceSupplier.get();
    disabledAppearance.setEnabled(false);

    armedAppearance = appearanceSupplier.get();
    armedAppearance.getModel().setArmed(true);
    armedAppearance.getModel().setPressed(true);

    rolloverAppearance = appearanceSupplier.get();
    rolloverAppearance.getModel().setRollover(true);

    menu = new MenuButtonMenu();
    menu.setMaximumSize(new Dimension(9999, 9999));
    menu.setToolTipText(tooltipText);
    add(menu);

    /*
     * As far as I can tell, setRollover() is never called on the JMenu's
     * ButtonModel, so we handle rollover manually.
     */
    menu.addMouseListener(new MouseAdapter()
    {
      @Override
      public void mouseEntered(MouseEvent e)
      {
        rollover = true;
        repaint();
      }

      @Override
      public void mouseExited(MouseEvent e)
      {
        rollover = false;
        repaint();
      }
    });
  }

  /*
   * We don't want the grab cursor when we're "disabled," since a click still
   * has an effect, so we keep our own enabled state and tell Swing it's always
   * set to true.
   */

  @Override
  public void setEnabled(boolean enabled)
  {
    this.enabled = enabled;
    /*
     * Do NOT call repaint() here; the repaint will call setEnabled(), and we
     * end up with the multithreaded equivalent of an infinite loop.
     */
  }

  @Override
  public boolean isEnabled()
  {
    return true;
  }

  private JButton getAppearance()
  {
    if(armed)
    {
      return armedAppearance;
    }
    if(!enabled)
    {
      return disabledAppearance;
    }
    if(rollover)
    {
      return rolloverAppearance;
    }
    return enabledAppearance;
  }

  protected abstract void menuActivated(JMenu menu);

  private class MenuButtonMenu extends JMenu
  {
    private static final long serialVersionUID = 3009012053940381825L;

    private MenuButtonMenu()
    {
    }

    @Override
    public void setSelected(boolean selected)
    {
      armed = selected;

      menuActivated(this);

      // As far as I know, the call to super is unnecessary but harmless.
      super.setSelected(selected);

      // We need the MenuButton to repaint(), not the menu.
      MenuButton.this.repaint();
    }

    /*
     * MenuButton previously called menu.paintChildren() instead of
     * paintChildren(), but the blue menu highlight still showed up on the Mac.
     * Overriding the other methods here seems to work.
     */

    @Override
    protected void paintBorder(Graphics g)
    {
    }

    @Override
    protected void paintComponent(Graphics g)
    {
    }

    /* Make visible. */
    @Override
    protected void paintChildren(Graphics g)
    {
      super.paintChildren(g);
    }
  }

  @Override
  public Dimension getMaximumSize()
  {
    return getAppearance().getMaximumSize();
  }

  @Override
  public Dimension getMinimumSize()
  {
    return getAppearance().getMinimumSize();
  }

  @Override
  public Dimension getPreferredSize()
  {
    return getAppearance().getPreferredSize();
  }

  @Override
  public void paint(Graphics g)
  {
    /*
     * On a Mac, the JButton doesn't take up the full area claimed by the
     * MenuButton. This convinces the Mac to repaint the full area.
     * Unfortunately, this causes the Metal Look and Feel to paint a blank panel
     * up in the menu bar. Metal doesn't have that problem if I switch to an
     * empty JLabel or transparent JPanel, but in neither case does Mac actually
     * repaint the necessary area.
     */
    // TODO figure out a non-hack solution
    if(isMac())
    {
      JPanel panel = new JPanel();
      panel.setBounds(getBounds());
      panel.paint(g);
    }

    getAppearance().setBounds(getBounds());
    getAppearance().paint(g);

    paintChildren(g);
  }
}
