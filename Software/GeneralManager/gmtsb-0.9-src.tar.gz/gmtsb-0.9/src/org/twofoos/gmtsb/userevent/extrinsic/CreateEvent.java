/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.extrinsic;

import static org.twofoos.gmtsb.util.CollectionUtilities.removeLast;

import java.util.List;

import org.twofoos.gmtsb.core.Depth;
import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.userevent.UserEvent;

public abstract class CreateEvent<D extends TSBTransferableData<D>, L extends List<D>>
    extends ExtrinsicEvent
{
  public static class CreatePlayerEvent extends CreateEvent<Player, Depth>
  {
    private CreatePlayerEvent(Depth list)
    {
      super(list);
    }

    // Not using a public constructor only to be consistent with
    // PlayerMoveEvent.
    public static CreatePlayerEvent createCreatePlayerEvent(Depth list)
    {
      return new CreatePlayerEvent(list);
    }

    @Override
    protected Player newDataObject()
    {
      Depth depth = getList();
      return depth.getPosition().newPlayer();
    }

    public String getDescription()
    {
      return "Create new player";
    }

    @Override
    public boolean isTeamEvent()
    {
      return false;
    }
  }

  public static class CreateTeamEvent extends CreateEvent<Team, Division>
  {
    private CreateTeamEvent(Division list)
    {
      super(list);
    }

    // Not using a public constructor only to be consistent with
    // PlayerMoveEvent.
    public static CreateTeamEvent createCreateTeamEvent(Division list)
    {
      return new CreateTeamEvent(list);
    }

    @Override
    protected Team newDataObject()
    {
      Team team = new Team();
      Division division = getList();
      League league = division.getConference().getLeague();
      /*
       * TODO move to Team constructor? Is the only new requirement that I read
       * plays before teams?
       */
      team.fillPlaybookWithDefaultPlays(league);
      return team;
    }

    public String getDescription()
    {
      return "Create new team";
    }

    @Override
    public boolean isTeamEvent()
    {
      return true;
    }
  }

  private final L list;
  private final D dataObject;

  protected CreateEvent(L list)
  {
    this.list = list;
    // We must create the object only once.
    // The user may create a player, make changes to him, and then undo and redo
    // the two actions. Undo and redo only work if the player that we put back
    // is the same player that was initially created and changed.
    this.dataObject = newDataObject();
  }

  protected abstract D newDataObject();

  public boolean doEvent()
  {
    list.add(dataObject);
    return true;
  }

  public void undoEvent()
  {
    removeLast(list);
  }

  protected L getList()
  {
    return list;
  }

  @Override
  public boolean isListAffected(List<?> list)
  {
    return list == this.list;
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }
}
