/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core.play;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Team;

public enum Ballcarrier
{
  QB(0, 0), RB1(2, 2), RB2(4, 3), WR1(6, 6), WR2(8, 7), DUMMY(-1, -1);

  private static final Map<Integer, Ballcarrier> FROM_ROM_ID;

  private final int romID;
  private final int playerIndex;

  private Ballcarrier(int romID, int playerIndex)
  {
    this.romID = romID;
    this.playerIndex = playerIndex;
  }

  public int getRomID()
  {
    return romID;
  }

  public static Ballcarrier getBallcarrier(int romID)
  {
    Ballcarrier returnValue = FROM_ROM_ID.get(romID);

    if(returnValue == null)
    {
      return DUMMY;
    }

    return returnValue;
  }

  private Player getPlayer(Team team)
  {
    if(this == DUMMY)
    {
      return null;
    }

    return team.getNthPlayer(playerIndex);
  }

  public String getPlayerName(Team team)
  {
    if(this == DUMMY)
    {
      return "(UNSPECIFIED)";
    }

    Player player = getPlayer(team);
    return player == null ? "(NO PLAYER)" : player.getFullName();
  }

  static
  {
    Map<Integer, Ballcarrier> fromRomID = new HashMap<Integer, Ballcarrier>();

    for(Ballcarrier ballCarrier : values())
    {
      fromRomID.put(ballCarrier.getRomID(), ballCarrier);
    }

    FROM_ROM_ID = Collections.unmodifiableMap(fromRomID);
  }
}
