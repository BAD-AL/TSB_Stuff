/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.file;

import static com.google.common.collect.Iterables.concat;
import static com.google.common.collect.Maps.newEnumHashBiMap;
import static com.google.common.collect.Maps.newHashMapWithExpectedSize;
import static com.google.common.collect.Multimaps.newHashMultimap;
import static com.google.common.collect.Sets.newHashSet;
import static java.lang.Byte.parseByte;
import static java.util.Collections.nCopies;
import static org.twofoos.gmtsb.core.AFC_NFC_Other.AFC;
import static org.twofoos.gmtsb.core.AFC_NFC_Other.NFC;
import static org.twofoos.gmtsb.core.League.CONFERENCE_TEAM_COUNT;
import static org.twofoos.gmtsb.core.League.NES_TEAMS_COUNT;
import static org.twofoos.gmtsb.core.PaletteColor.getColor;
import static org.twofoos.gmtsb.core.RunPassRatio.forComputerValue;
import static org.twofoos.gmtsb.util.CollectionUtilities.drain;
import static org.twofoos.gmtsb.util.CollectionUtilities.list;
import static org.twofoos.gmtsb.util.iterators.Pair.pairIterable;
import static org.twofoos.gmtsb.util.iterators.Peek.peekIterable;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;

import org.apache.xerces.parsers.DOMParser;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.twofoos.gmtsb.core.AFC_NFC_Other;
import org.twofoos.gmtsb.core.Appearance;
import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.AttributeList;
import org.twofoos.gmtsb.core.Conference;
import org.twofoos.gmtsb.core.Depth;
import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Notable;
import org.twofoos.gmtsb.core.OffensiveFormation;
import org.twofoos.gmtsb.core.PaletteColor;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.ProBowlSlot;
import org.twofoos.gmtsb.core.ProBowlTeam;
import org.twofoos.gmtsb.core.ReturnJob;
import org.twofoos.gmtsb.core.RunPassRatio;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.core.Team.PlayersByPositionIterator;
import org.twofoos.gmtsb.core.play.Ballcarrier;
import org.twofoos.gmtsb.core.play.Page;
import org.twofoos.gmtsb.core.play.Play;
import org.twofoos.gmtsb.file.TsbFile.TsbLocation;
import org.twofoos.gmtsb.util.iterators.AbstractMapper;
import org.twofoos.gmtsb.util.iterators.ByteArrayIterable;
import org.twofoos.gmtsb.util.iterators.Mapper;
import org.twofoos.gmtsb.util.iterators.Pair;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.DefaultHandler;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Ordering;
import com.google.common.collect.SetMultimap;

// TODO switch to new XML serialization method
@SuppressWarnings("deprecation")
public class SupplementedNesFile
{
  // TODO presumably could derive this from formations
  public static final int PLAYERS_PER_TEAM_COUNT = 30;

  private static final int MAX_NAME_LENGTH = 16;

  private static final int RACE_FACE_CODE_BYTE_COUNT = 2;
  private static final int RACE_FACE_CODE_BYTE_1 = 4;
  private static final int RACE_FACE_CODE_BYTE_2 = 5;

  private static final String LEAGUE_TAG = "league";
  private static final String DIVISION_TAG = "division";
  private static final String TEAM_TAG = "team";
  private static final String PLAYER_TAG = "player";
  private static final String NOTES_TAG = "notes";
  private static final String ATTRIBUTE_TAG = "attribute";
  private static final String POSITION_ATTRIBUTE = "position";
  private static final String NAME_ATTRIBUTE = "name";
  private static final String UNIFORM_NUMBER_ATTRIBUTE = "uniformnumber";
  private static final String APPEARANCE_ATTRIBUTE = "appearance";
  private static final String VALUE_ATTRIBUTE = "value";
  private static final String OFFENSIVE_FORMATION_ATTRIBUTE =
      "offensiveformation";
  private static final String CITY_ATTRIBUTE = "city";
  private static final String ABBREVIATION_ATTRIBUTE = "abbreviation";
  private static final String RUN_PASS_RATIO_ATTRIBUTE = "runpassratio";
  private static final String SPRITE_COLORS_TAG = "spritecolors";
  private static final String COLOR_TAG = "colors";
  private static final String INDEX_ATTRIBUTE = "index";
  private static final String PLAYER_DATA_COLOR_ATTRIBUTE = "playerdatacolor";
  private static final String ID_ATTRIBUTE = "id";
  private static final String ALTERNATE_UNIFORM_CODE_TAG =
      "alternateuniformtriggers";
  private static final String VERSUS_TAG = "versus";
  private static final String TEAM_ATTRIBUTE = "team";
  private static final String TEAM_ID_PREFIX = "team";
  private static final String RETURNERS_TAG = "returners";
  private static final String PLAYER_ATTRIBUTE = "player";
  private static final String RETURNER_TAG = "returner";
  private static final String RETURN_JOB_ATTRIBUTE = "job";
  private static final String PLAYER_ID_PREFIX = "player";
  private static final String NO_PLAYER_ATTRIBUTE = "noplayer";
  private static final String NO_PLAYER_VALUE = "noplayer";
  private static final String PLAYBOOK_TAG = "playbook";
  private static final String PLAY_TAG = "play";
  private static final String REPLACED_PRO_BOWLER_TAG = "replacedprobowler";
  private static final String CONFERENCE_ATTRIBUTE = "conference";
  private static final String PRO_BOWL_SLOT_ATTRIBUTE = "probowlslot";

  // First backup running back is probably not a terrible choice.
  private static final byte DEFAULT_RETURNER_INDEX = (byte) 4;

  private static final OutputFormat prettyXML =
      new OutputFormat("xml", null, true);

  private final File rom;
  private File supplementFile;

  public SupplementedNesFile(File nesFile, File supplementFile)
  {
    this.rom = nesFile;
    this.supplementFile = supplementFile;
  }

  private static final Pattern lowerUpperSplit =
      Pattern.compile("^([^A-Z]*)(.*)$");

  public static Pair<String, String> splitName(String name)
    throws NameFormatException
  {
    Matcher firstLastMatcher = lowerUpperSplit.matcher(name);
    String first;
    String last;

    if(firstLastMatcher.matches())
    {
      first = firstLastMatcher.group(1).toUpperCase();
      last = firstLastMatcher.group(2).toUpperCase();
    }
    else
    {
      throw new NameFormatException(name);
    }

    return new Pair<String, String>(first, last);
  }

  private static int stripPrefix(String idText, String prefix)
  {
    if(!idText.startsWith(prefix))
    {
      throw new IllegalArgumentException(prefix + ": not a prefix of " + idText);
    }
    return Integer.parseInt(idText.substring(prefix.length()));
  }

  private static boolean isNameTooLong(Player player)
  {
    String first = player.getFirst();
    String last = player.getLast();

    int length = first.length();

    if(!first.contains("."))
    {
      // Will include a space.
      length++;
    }

    length += last.length();

    return length > MAX_NAME_LENGTH;
  }

  // TODO might be nice to handle long last names like Roethlisberger and
  // Houshmandzadeh, too
  private static void abbreviateFirst(Player player)
  {
    if(player.getFirst().length() < 3)
    {
      return;
    }

    // TODO notify the user that the name was abbreviated (make method
    // non-static and accumulate a list somewhere?)
    // System.err.println("abbreviating name of " + player);

    String abbreviated = player.getFirst().charAt(0) + ".";

    player.setFirst(abbreviated);
  }

  private static boolean isAbbreviationOf(String abbreviation, String original)
  {
    return (abbreviation.length() == 2 && abbreviation.charAt(1) == '.'
        && original.length() > 0 && original.charAt(0) == abbreviation
        .charAt(0));
  }

  public static class NameFormatException extends Exception
  {
    private static final long serialVersionUID = 2120500090244471142L;

    public NameFormatException(String nameString)
    {
      super("player name " + nameString + " does not match expected pattern");
    }
  }

  private static final Map<Position, Player> DEFAULT_PLAYERS =
      new EnumMap<Position, Player>(Position.class);

  static
  {
    for(Position position : Position.allPositions())
    {
      DEFAULT_PLAYERS.put(position, position.newPlayer());
    }
  }

  private static boolean isDefaultPlayer(Player player, Position position)
  {
    return player.isIdentical(DEFAULT_PLAYERS.get(position));
  }

  private static boolean isDefaultTeam(Team team, League league)
  {
    return team.isDefaultTeam(league);
  }

  private static int getAttributeValue(Attributes attributes,
      String attributeName)
  {
    String text = attributes.getValue(attributeName);
    return Integer.parseInt(text);
  }

  private static class PlayersOrDummiesByPositionIterator extends
      Team.PlayersByPositionIterator
  {
    private PlayersOrDummiesByPositionIterator(Team team)
    {
      super(team);
    }

    @Override
    public boolean hasNextPlayerAtPosition(Position position)
    {
      return true;
    }

    public boolean hasRealNextPlayerAtPosition(Position position)
    {
      return super.hasNextPlayerAtPosition(position);
    }

    @Override
    public Player nextPlayerAtPosition(Position position)
    {
      if(super.hasNextPlayerAtPosition(position))
      {
        return super.nextPlayerAtPosition(position);
      }
      else
      {
        return position.newPlayer();
      }
    }
  }

  private abstract class SupplementedNesFilePhase
  {
    protected final League league;
    protected final TsbFile tsbFile;

    protected final int MYSTERY_LOCATION_COUNT = 4;
    protected final int POST_MYSTERY_LOCATION_COUNT = 28 - 1;
    protected final int TEAM_RELATED_STRING_COUNT =
        3 * League.NES_TEAMS_COUNT + 2 * MYSTERY_LOCATION_COUNT
            + POST_MYSTERY_LOCATION_COUNT;
    protected final List<TsbLocation> teamRelatedStringLocations =
        new ArrayList<TsbLocation>();

    protected final List<TsbLocation> teamLocations =
        new ArrayList<TsbLocation>(NES_TEAMS_COUNT);
    protected final List<List<TsbLocation>> playerNameLocations =
        new ArrayList<List<TsbLocation>>(NES_TEAMS_COUNT);
    protected TsbLocation endOfPlayerNamesLocation;

    private SupplementedNesFilePhase(String fileMode, League league)
      throws IOException
    {
      this.league = league;

      tsbFile = new TsbFile(rom, fileMode);
    }

    protected void setUpTeamAndPlayerPointers()
    {
      for(int teamIndex = 0; teamIndex < NES_TEAMS_COUNT; teamIndex++)
      {
        playerNameLocations.add(new ArrayList<TsbLocation>(
            PLAYERS_PER_TEAM_COUNT));
      }
    }

    protected void close() throws IOException
    {
      tsbFile.close();
    }
  }

  private class SupplementedNesFileReader extends SupplementedNesFilePhase
  {
    private Document supplementFileDocument;

    private Map<Integer, Team> teamByID = new HashMap<Integer, Team>();
    private Map<Integer, Player> playerByID = new HashMap<Integer, Player>();

    private SupplementedNesFileReader() throws IOException
    {
      super("r", new League());
    }

    private Iterable<Team> decodeAlternateSpriteColorsCode(
        int alternateSpriteColorsCode)
    {
      List<Team> otherTeams = new ArrayList<Team>();

      for(int i = 0; i < NES_TEAMS_COUNT; i++)
      {
        int shift = 31 - i;
        int mask = 1 << shift;
        if((alternateSpriteColorsCode & mask) == mask)
        {
          otherTeams.add(teamByID.get(i));
        }
      }

      return otherTeams;
    }

    private void createNESTeams()
    {
      for(Division division : league.divisions())
      {
        for(int teamIndex = 0; teamIndex < division.getNESTeamCount(); teamIndex++)
        {
          // We will fill in formation and name info later.
          division.add(new Team());
        }
      }
    }

    private void putNESTeamsInIndexToTeamMap()
    {
      // Needed for readSpriteColors().

      for(Pair<Team, Integer> teamAndIndex : league
          .nesTeamsOrDummiesWithIndexes())
      {
        Team team = teamAndIndex.getFirst();
        int teamIndex = teamAndIndex.getSecond();

        teamByID.put(teamIndex, team);
      }
    }

    private void readNESTeamFormations() throws IOException
    {
      tsbFile.seek(tsbFile.FORMATION_POSITION_SECTIONS_CODE_LOCATION);
      if(tsbFile.readUnsignedByte() == tsbFile.FORMATION_POSITION_SECTIONS_CODE_PATCH[0])
      {
        // This ROM has already been modified to make changing formations easy.
        // Read the team formations from the ROM.
        tsbFile.seek(tsbFile.FORMATION_POSITION_SECTIONS_LOCATION);
        for(Team currentTeam : league.nesTeamsOrDummies())
        {
          currentTeam.setOffensiveFormation(OffensiveFormation
              .getFormationFromID(tsbFile.readByte()));
        }
      }
      else
      {
        // This ROM hasn't been modified to make changing formations easy.
        // Fall back to the hard-coded team formations.
        for(Pair<Team, Integer> teamAndIndex : league
            .nesTeamsOrDummiesWithIndexes())
        {
          Team team = teamAndIndex.getFirst();
          Integer index = teamAndIndex.getSecond();

          switch(index)
          {
            case 0x0c:
            case 0x0e:
            case 0x11:
              team.setOffensiveFormation(OffensiveFormation.OFF_1RB_3WR_1TE);
              break;

            case 0x07:
            case 0x14:
            case 0x1b:
              team.setOffensiveFormation(OffensiveFormation.OFF_1RB_4WR_0TE);
              break;
          }
        }
      }
    }

    private void readTeamPointers() throws IOException
    {
      tsbFile.seek(tsbFile.TEAM_POINTERS_LOCATION);
      for(int teamIndex = 0; teamIndex < NES_TEAMS_COUNT; teamIndex++)
      {
        teamLocations.add(tsbFile.readPlayerRelatedLocation());
      }
    }

    private void readPlayerNamePointers() throws IOException
    {
      for(Pair<TsbLocation, List<TsbLocation>> locations : pairIterable(
          teamLocations, playerNameLocations))
      {
        TsbLocation teamLocation = locations.getFirst();
        List<TsbLocation> playerNameLocations = locations.getSecond();

        tsbFile.seek(teamLocation);
        for(int playerIndex = 0; playerIndex < PLAYERS_PER_TEAM_COUNT; playerIndex++)
        {
          playerNameLocations.add(tsbFile.readPlayerRelatedLocation());
        }
      }
      endOfPlayerNamesLocation = tsbFile.readPlayerRelatedLocation();
    }

    private Player readPlayer(Position position,
        TsbLocation thisPlayerNamePointer, TsbLocation nextPlayerNamePointer)
      throws IOException, NesFileFormatException
    {
      int nameLength =
          nextPlayerNamePointer.subtract(thisPlayerNamePointer) - 1;

      tsbFile.seek(thisPlayerNamePointer);

      int uniformNumber = tsbFile.readIntThatLooksLikeByteValueInHex();

      String nameString = tsbFile.readString(nameLength);

      Pair<String, String> firstAndLast;
      try
      {
        firstAndLast = splitName(nameString);
      }
      catch(NameFormatException e)
      {
        throw new NesFileFormatException(e);
      }

      return new Player(position, firstAndLast.getFirst(), firstAndLast
          .getSecond(), uniformNumber);
    }

    private List<Player> readAndReturnPlayerNames() throws IOException,
      NesFileFormatException
    {
      List<Player> players = new ArrayList<Player>();

      Team dummyTeam = new Team();
      Iterable<Position> positionsOneTeam =
          dummyTeam.positionOfEachPlayerInAllFormations();
      Iterable<Position> positionsAllTeams =
          concat(nCopies(NES_TEAMS_COUNT, positionsOneTeam));

      for(Pair<Position, Pair<TsbLocation, TsbLocation>> positionAndLocations : pairIterable(
          positionsAllTeams, peekIterable(concat(playerNameLocations),
              endOfPlayerNamesLocation)))
      {
        Position position = positionAndLocations.getFirst();

        Pair<TsbLocation, TsbLocation> locations =
            positionAndLocations.getSecond();
        TsbLocation thisPlayerNamePointer = locations.getFirst();
        TsbLocation nextPlayerNamePointer = locations.getSecond();

        players.add(readPlayer(position, thisPlayerNamePointer,
            nextPlayerNamePointer));
      }

      return players;
    }

    private List<Player> readAndReturnPlayerNamesAndAttributes()
      throws IOException, NesFileFormatException
    {
      List<Player> players = readAndReturnPlayerNames();

      tsbFile.seek(tsbFile.PLAYER_ATTRIBUTES_LOCATION);

      for(Player currentPlayer : players)
      {
        int attributeCount = currentPlayer.getAttributeCount();

        byte[] nybbles =
            tsbFile.readNybbles(attributeCount + RACE_FACE_CODE_BYTE_COUNT);

        Iterator<Attribute> attributeIterator =
            currentPlayer.attributesIterator();

        int raceFaceCode = 0;
        for(int attributeIndex = 0; attributeIndex < attributeCount
            + RACE_FACE_CODE_BYTE_COUNT; attributeIndex++)
        {
          if(attributeIndex == RACE_FACE_CODE_BYTE_1)
          {
            raceFaceCode = (nybbles[attributeIndex] << 4);
          }
          else if(attributeIndex == RACE_FACE_CODE_BYTE_2)
          {
            raceFaceCode |= nybbles[attributeIndex];
          }
          else
          {
            Attribute currentAttribute = attributeIterator.next();
            currentPlayer.setComputerAttribute(currentAttribute,
                nybbles[attributeIndex]);
          }
        }
        currentPlayer.setAppearance(Appearance.getAppearance(raceFaceCode));
      }

      return players;
    }

    private Pair<List<Player>, List<Player>> readAndReturnStartersAndBackups()
      throws IOException, NesFileFormatException
    {
      List<Player> starters = new ArrayList<Player>();
      List<Player> backups = new ArrayList<Player>();

      Pair<List<Player>, List<Player>> startersAndBackups =
          new Pair<List<Player>, List<Player>>(starters, backups);

      List<Player> players = readAndReturnPlayerNamesAndAttributes();

      Team dummyTeam = new Team();

      Iterable<Boolean> isStarterListOneTeam =
          dummyTeam.getIsStarterListForAllFormations();
      Iterable<Boolean> isStarterListAllTeams =
          concat(nCopies(NES_TEAMS_COUNT, isStarterListOneTeam));

      for(Pair<Player, Boolean> playerAndIsStarter : pairIterable(players,
          isStarterListAllTeams))
      {
        Player player = playerAndIsStarter.getFirst();
        Boolean isStarter = playerAndIsStarter.getSecond();

        if(isStarter)
        {
          starters.add(player);
        }
        else
        {
          backups.add(player);
        }
      }

      return startersAndBackups;
    }

    private void putPlayersIntoTeams(List<Player> startersOrBackups,
        boolean isStarters)
    {
      Iterator<Player> players = startersOrBackups.iterator();

      for(Team currentTeam : league.nesTeamsOrDummies())
      {
        for(Position currentPosition : currentTeam
            .startersOrBackupsOfAllFormations(isStarters))
        {
          Depth currentDepth = currentTeam.getDepth(currentPosition);
          Player currentPlayer = players.next();

          currentDepth.add(currentPlayer);
        }
      }
    }

    private void readPlayerNamesAndAttributes() throws IOException,
      NesFileFormatException
    {
      Pair<List<Player>, List<Player>> startersAndBackups =
          readAndReturnStartersAndBackups();
      List<Player> starters = startersAndBackups.getFirst();
      List<Player> backups = startersAndBackups.getSecond();

      putPlayersIntoTeams(starters, true);
      putPlayersIntoTeams(backups, false);
    }

    private void readReturners() throws IOException
    {
      tsbFile.seek(tsbFile.RETURNERS_LOCATION_1);

      for(Team team : league.nesTeamsOrDummies())
      {
        byte[] returnerIndexes = tsbFile.readNybbles(2);
        team.setReturner(ReturnJob.KR, team.getNthPlayer(returnerIndexes[0]));
        team.setReturner(ReturnJob.PR, team.getNthPlayer(returnerIndexes[1]));
      }
    }

    private void readProBowlPlayers(Conference conference) throws IOException
    {
      ProBowlTeam proBowlTeam = conference.getProBowlTeam();

      List<Team> nesTeams = list(league.nesTeamsOrDummies());

      for(ProBowlSlot slot : ProBowlSlot.values())
      {
        byte teamIndex = tsbFile.readByte();
        byte playerIndex = tsbFile.readByte();

        Team team = nesTeams.get(teamIndex);
        Player player = team.getNthPlayer(playerIndex);

        proBowlTeam.putPlayer(slot, player);
      }
    }

    // TODO Pro Bowl return men
    private void readProBowlPlayers() throws IOException
    {
      tsbFile.seek(tsbFile.PRO_BOWL_PLAYERS_LOCATION);

      readProBowlPlayers(league.getAFC());
      readProBowlPlayers(league.getNFC());
    }

    private void readSpriteColors() throws IOException
    {
      tsbFile.seek(tsbFile.SPRITE_COLORS_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        int[] spriteBytes = tsbFile.readUnsignedBytes(6);
        List<PaletteColor> spriteColors1 =
            Arrays.asList(getColor(spriteBytes[0]), getColor(spriteBytes[2]),
                getColor(spriteBytes[1]));
        List<PaletteColor> spriteColors2 =
            Arrays.asList(getColor(spriteBytes[3]), getColor(spriteBytes[5]),
                getColor(spriteBytes[4]));
        int alternateSpriteColorsCode = tsbFile.readInt();

        team.setSpriteColors1(spriteColors1);
        team.setSpriteColors2(spriteColors2);

        for(Team otherTeam : decodeAlternateSpriteColorsCode(alternateSpriteColorsCode))
        {
          team.addAlternateUniformWhenPlaying(otherTeam);
        }
      }
    }

    private void readRunPassRatios() throws IOException
    {
      tsbFile.seek(tsbFile.RUN_PASS_RATIO_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        team.setRunPassRatio(forComputerValue(tsbFile.readByte()));
      }
    }

    // private void readAlternateCutsceneColorsCode() throws IOException
    // {
    // // TODO in theory might want to allow for different colors in the
    // // cutscenes than on the sprites -- should probably check whether this is
    // // done in the original ROM
    // tsbFile.seek(tsbFile.CUTSCENE_COLORS_LOCATION);
    //
    // for(Team team : league.nesTeamsOrDummies())
    // {
    // tsbFile.readUnsignedBytes(4);
    // int alternateCutsceneColorsCode = tsbFile.readInt();
    //
    // // TODO removed
    // team.setAlternateCutsceneColorsCode(alternateCutsceneColorsCode);
    // }
    // }

    private void readPlayerDataColors() throws IOException
    {
      tsbFile.seek(tsbFile.PLAYER_DATA_COLORS_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        team.setPlayerDataColor(tsbFile.readPaletteColor());
      }
    }

    private void readPlayNamesFormationsAndPointers() throws IOException
    {
      tsbFile.seek(tsbFile.PLAY_NAMES_FORMATIONS_AND_POINTERS_LOCATION);

      for(Play play : league.getBinder().getAllPlays())
      {
        String name = tsbFile.readPaddedString(Play.NAME_LENGTH);
        play.setName(name);

        @SuppressWarnings("unused")
        byte formationByte = tsbFile.readByte();

        @SuppressWarnings("unused")
        int[] playPointers = tsbFile.readUnsignedBytes(Play.PAGES);
      }
    }

    /*
     * javac 1.5 dies if I put this on the foreach variables:
     * http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6294589
     */
    @SuppressWarnings("unused")
    private void readPlayDefenseReactions() throws IOException
    {
      tsbFile.seek(tsbFile.DEFENSE_REACTIONS_LOCATION);

      for(Play play : league.getBinder().getAllPlays())
      {
        int[] defenseReactions = tsbFile.readUnsignedBytes(Play.PAGES);
      }
    }

    private void readPlayBallcarriers() throws IOException
    {
      tsbFile.seek(tsbFile.PLAY_BALLCARRIERS_LOCATION);

      for(Play play : league.getBinder().getAllPlays())
      {
        byte ballcarrierID = tsbFile.readByte();
        play.setBallcarrier(Ballcarrier.getBallcarrier(ballcarrierID));
      }
    }

    private void readPlayGraphics() throws IOException
    {
      tsbFile.seek(tsbFile.PLAY_GRAPHICS_LOCATION);

      for(Play play : league.getBinder().getAllPlays())
      {
        @SuppressWarnings("unused")
        int[] graphics = tsbFile.readUnsignedBytes(Play.TILES);
        play.setGraphics(graphics);
      }
    }

    private void readTeamPlaybooks() throws IOException
    {
      tsbFile.seek(tsbFile.PLAYBOOKS_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        byte[] playIndexes = tsbFile.readNybbles(Play.PAGES);

        for(Pair<Page, Byte> pageAndIndex : Pair.pairIterable(Page.values(),
            new ByteArrayIterable(playIndexes)))
        {
          Page page = pageAndIndex.getFirst();
          Byte index = pageAndIndex.getSecond();

          List<Play> plays = league.getBinder().getPlaysByPage(page);

          Play play = plays.get(index);

          team.getPlaybook().put(page, play);
        }
      }
    }

    private void readTeamRelatedStringPointers() throws IOException
    {
      tsbFile.seek(tsbFile.FIRST_TEAM_NAME_POINTER_LOCATION);

      for(int i = 0; i < TEAM_RELATED_STRING_COUNT + 1; i++)
      {
        teamRelatedStringLocations.add(tsbFile.readTeamRelatedLocation());
      }
    }

    private void readTeamRelatedStrings() throws IOException
    {
      List<String> otherTeamRelatedStrings = new ArrayList<String>();

      List<String> teamRelatedStrings = new ArrayList<String>();

      for(Pair<TsbLocation, TsbLocation> locations : peekIterable(teamRelatedStringLocations))
      {
        TsbLocation currentLocation = locations.getFirst();
        TsbLocation nextLocation = locations.getSecond();

        int length = nextLocation.subtract(currentLocation);

        tsbFile.seek(currentLocation);
        teamRelatedStrings.add(tsbFile.readString(length));
      }

      Iterator<String> strings = teamRelatedStrings.iterator();

      for(Team team : league.nesTeamsOrDummies())
      {
        team.setAbbreviation(strings.next());
      }

      drain(strings, otherTeamRelatedStrings, MYSTERY_LOCATION_COUNT);

      for(Team team : league.nesTeamsOrDummies())
      {
        team.setCity(strings.next());
      }

      drain(strings, otherTeamRelatedStrings, MYSTERY_LOCATION_COUNT);

      for(Team team : league.nesTeamsOrDummies())
      {
        team.setName(strings.next());
      }

      drain(strings, otherTeamRelatedStrings, POST_MYSTERY_LOCATION_COUNT);

      league.setOtherTeamRelatedStrings(otherTeamRelatedStrings);
    }

    private void removeTrailingDummyPlayers()
    {
      for(Team team : league.teams())
      {
        for(Position position : Position.allPositions())
        {
          Depth depth = team.getDepth(position);
          for(int i = depth.size() - 1; i >= 0; i--)
          {
            Player player = depth.get(i);
            if(isDefaultPlayer(player, position))
            {
              depth.remove(i);
            }
            else
            {
              break;
            }
          }
        }
      }
    }

    private void removeTrailingDummyTeams()
    {
      for(Division division : league.nesDivisions())
      {
        for(int i = division.size() - 1; i >= 0; i--)
        {
          Team team = division.get(i);
          if(isDefaultTeam(team, league))
          {
            division.remove(i);
          }
          else
          {
            break;
          }
        }
      }
    }

    private League readLeague() throws IOException, NesFileFormatException,
      SupplementFileFormatException
    {
      createNESTeams();
      putNESTeamsInIndexToTeamMap();
      readTeamRelatedStringPointers();
      readTeamRelatedStrings();
      loadSupplementFile();
      readNESTeamFormations();
      readSupplementFormations();
      setUpTeamAndPlayerPointers();
      readTeamPointers();
      readPlayerNamePointers();
      readPlayerNamesAndAttributes();
      readProBowlPlayers();
      readReturners();
      readSpriteColors();
      readRunPassRatios();
      // readAlternateCutsceneColorsCode();
      readPlayerDataColors();
      readPlayNamesFormationsAndPointers();
      readPlayDefenseReactions();
      readPlayGraphics();
      readPlayBallcarriers();
      readTeamPlaybooks();
      readSupplementTeamsAndPlayers();
      readSupplementAlternateUniformData();
      readSupplementReturners();
      readSupplementOverriddenProBowlers();
      // Check for dummy teams after dummy players so that the dummy players of
      // a dummy team are removed beforehand, making it identical to the empty
      // dummy team.
      removeTrailingDummyPlayers();
      removeTrailingDummyTeams();
      removeDummyTeamsFromAlternateUniformCode();

      close();

      return league;
    }

    private void removeDummyTeamsFromAlternateUniformCode()
    {
      /*
       * Dummy teams could not be mentioned in alternate uniform code unless
       * someone manually edited the file to make it so. Specifically, there
       * would be no way for a team to have a dummy in its alternate-uniform set
       * because the dummy would not have a Team object at all (until write
       * time). But I suppose I can ensure easily enough that there are no
       * problems even if the user manually edits the ROM, so I will.
       */
      Set<Team> allTeams = ImmutableSet.copyOf(league.teamsVector());
      for(Team team : league.teams())
      {
        Set<Team> alternateUniformTeams =
            newHashSet(team.getAlternateUniformWhenPlayingTeams());
        alternateUniformTeams.retainAll(allTeams);
        team.setAlternateUniformWhenPlaying(alternateUniformTeams);
      }
    }

    private void loadSupplementFile() throws IOException,
      SupplementFileFormatException
    {
      if(supplementFile == null)
      {
        return;
      }

      DOMParser domParser = new DOMParser();

      try
      {
        InputSource supplementFileInputSource =
            new InputSource(new BufferedReader(new FileReader(supplementFile)));
        domParser.parse(supplementFileInputSource);
        supplementFileDocument = domParser.getDocument();
      }
      catch(IOException e)
      {
        throw e;
      }
      catch(Exception e)
      {
        throw new SupplementFileFormatException(e);
      }
    }

    private void saxParse(ContentHandler handler)
      throws SupplementFileFormatException
    {
      if(supplementFile == null)
      {
        return;
      }

      try
      {
        Source source =
            new DOMSource(supplementFileDocument.getDocumentElement());
        Transformer transformer =
            TransformerFactory.newInstance().newTransformer();
        SAXResult result = new SAXResult(handler);
        transformer.transform(source, result);
      }
      catch(Exception e)
      {
        throw new SupplementFileFormatException(e);
      }
    }

    private void readSupplementReturners() throws SupplementFileFormatException
    {
      saxParse(new SupplementFileReturnersSAXReader());
    }

    private void readSupplementOverriddenProBowlers()
      throws SupplementFileFormatException
    {
      saxParse(new SupplementFileOverriddenProBowlersSAXReader());
    }

    private void readSupplementFormations()
      throws SupplementFileFormatException
    {
      saxParse(new SupplementFileNESTeamFormationsSAXReader());
    }

    private void readSupplementTeamsAndPlayers()
      throws SupplementFileFormatException
    {
      saxParse(new SupplementFileMainSAXReader());
    }

    private void readSupplementAlternateUniformData()
      throws SupplementFileFormatException
    {
      saxParse(new SupplementFileNonNESAlternateUniformDataSAXReader());
    }

    private class SupplementFileSAXReader extends DefaultHandler
    {
      private Iterator<Division> divisionsIterator;
      private Division currentDivision;
      private ListIterator<Team> teamsIterator;

      protected SupplementFileSAXReader()
      {
      }

      protected Division getCurrentDivision()
      {
        return currentDivision;
      }

      protected ListIterator<Team> getTeamsIterator()
      {
        return teamsIterator;
      }

      // SAXException thrown by subclasses
      @SuppressWarnings("unused")
      @Override
      public void startElement(String uri, String localName, String rawName,
          Attributes attributes) throws SAXException
      {
        if(localName.equals(DIVISION_TAG))
        {
          currentDivision = divisionsIterator.next();
          teamsIterator = currentDivision.listIterator();
        }
        else if(localName.equals(LEAGUE_TAG))
        {
          divisionsIterator = league.divisions().iterator();
        }
      }

      @Override
      public void error(SAXParseException e)
      {
        // TODO do I need to do anything here?
      }

      @Override
      public void fatalError(SAXParseException e)
      {
        // TODO do I need to do anything here?
      }
    }

    private class SupplementFileMainSAXReader extends SupplementFileSAXReader
    {
      private Team currentTeam;
      private PlayersByPositionIterator playersByPositionIterator;
      private Player currentPlayer;
      private Iterator<Attribute> attributesIterator;
      private List<PaletteColor> colors;
      private Iterator<Page> pageIterator;
      private boolean inNotes = false;

      private SupplementFileMainSAXReader()
      {
      }

      @Override
      public void characters(char[] ch, int start, int length)
      {
        if(!inNotes)
        {
          return;
        }
        Notable notable = getCurrentNotable();
        StringBuilder builder = new StringBuilder(notable.getNotes());
        builder.append(ch, start, length);
        notable.setNotes(builder.toString());
      }

      private Notable getCurrentNotable()
      {
        if(currentPlayer != null)
        {
          return currentPlayer;
        }
        if(currentTeam != null)
        {
          return currentTeam;
        }
        throw new IllegalStateException("invalid location for notes element");
      }

      @Override
      public void endElement(String uri, String localName, String qName)
      {
        if(localName.equals(SPRITE_COLORS_TAG))
        {
          currentTeam.setSpriteColors1(colors.subList(0, 3));
          currentTeam.setSpriteColors2(colors.subList(3, 6));
        }
        else if(localName.equals(TEAM_TAG))
        {
          currentTeam = null;
        }
        else if(localName.equals(PLAYER_TAG))
        {
          currentPlayer = null;
        }
        else if(localName.equals(NOTES_TAG))
        {
          inNotes = false;
        }
      }

      @Override
      public void startElement(String uri, String localName, String rawName,
          Attributes attributes) throws SAXException
      {
        if(localName.equals(PLAYBOOK_TAG))
        {
          pageIterator = Page.values().iterator();
        }
        else if(localName.equals(PLAY_TAG))
        {
          Page page = pageIterator.next();
          int index = getAttributeValue(attributes, INDEX_ATTRIBUTE);
          Play play = league.getBinder().getPlaysByPage(page).get(index);
          currentTeam.getPlaybook().put(page, play);
        }
        else if(localName.equals(SPRITE_COLORS_TAG))
        {
          colors = new ArrayList<PaletteColor>();
        }
        else if(localName.equals(COLOR_TAG))
        {
          int index = getAttributeValue(attributes, INDEX_ATTRIBUTE);
          colors.add(PaletteColor.getColor(index));
        }
        // TODO should probably check whether people are trying to include
        // attributes for a player that exists, etc.
        else if(localName.equals(ATTRIBUTE_TAG))
        {
          Attribute attribute = attributesIterator.next();
          int computerAttributeValue =
              getAttributeValue(attributes, VALUE_ATTRIBUTE);
          currentPlayer.setComputerAttribute(attribute, computerAttributeValue);
        }
        else if(localName.equals(PLAYER_TAG))
        {
          String positionName = attributes.getValue(POSITION_ATTRIBUTE);
          Position position = Position.getPositionByName(positionName);

          String nameString = attributes.getValue(NAME_ATTRIBUTE);

          String first = null;
          String last = null;

          if(nameString != null)
          {
            try
            {
              Pair<String, String> firstAndLast = splitName(nameString);
              first = firstAndLast.getFirst();
              last = firstAndLast.getSecond();
            }
            catch(NameFormatException e)
            {
              throw new SAXException(new SupplementFileFormatException(e));
            }
          }

          if(playersByPositionIterator.hasNextPlayerAtPosition(position))
          {
            currentPlayer =
                playersByPositionIterator.nextPlayerAtPosition(position);

            if(first != null && last != null)
            {
              String nesFirst = currentPlayer.getFirst();
              String nesLast = currentPlayer.getLast();

              if(isAbbreviationOf(nesFirst, first) && last.equals(nesLast))
              {
                currentPlayer.setFirst(first);
              }
              // TODO else may want to note the mismatch here
            }
          }
          else
          {
            int uniformNumber =
                getAttributeValue(attributes, UNIFORM_NUMBER_ATTRIBUTE);
            int appearanceNumber =
                getAttributeValue(attributes, APPEARANCE_ATTRIBUTE);

            currentPlayer = new Player(position, first, last, uniformNumber);
            currentPlayer.setAppearance(Appearance
                .getAppearance(appearanceNumber));

            // Need to use the ListIterator to avoid a
            // ConcurrentModificationException.
            playersByPositionIterator.addPlayerAtPosition(position,
                currentPlayer);
          }

          String idText = attributes.getValue(ID_ATTRIBUTE);
          // Dummy players will not have ID's.
          // TODO change this?
          // TODO could I take advantage of this somewhere?
          if(idText != null)
          {
            int id = stripPrefix(idText, PLAYER_ID_PREFIX);
            playerByID.put(id, currentPlayer);
          }

          attributesIterator = currentPlayer.attributesIterator();
        }
        else if(localName.equals(TEAM_TAG))
        {
          if(getTeamsIterator().hasNext())
          {
            currentTeam = getTeamsIterator().next();
          }
          else
          {
            String formationAbbreviation =
                attributes.getValue(OFFENSIVE_FORMATION_ATTRIBUTE);
            OffensiveFormation offensiveFormation =
                OffensiveFormation
                    .getFormationFromAbbreviation(formationAbbreviation);

            String city = attributes.getValue(CITY_ATTRIBUTE);
            String name = attributes.getValue(NAME_ATTRIBUTE);
            String abbreviation = attributes.getValue(ABBREVIATION_ATTRIBUTE);
            PaletteColor playerDataColor =
                getColor(getAttributeValue(attributes,
                    PLAYER_DATA_COLOR_ATTRIBUTE));
            byte runPassRatioByte =
                parseByte(attributes.getValue(RUN_PASS_RATIO_ATTRIBUTE));
            RunPassRatio runPassRatio =
                RunPassRatio.forComputerValue(runPassRatioByte);

            // TODO do error-checking
            currentTeam =
                new Team(offensiveFormation, city, name, abbreviation);
            currentTeam.setPlayerDataColor(playerDataColor);
            currentTeam.setRunPassRatio(runPassRatio);

            String idText = attributes.getValue(ID_ATTRIBUTE);
            int id = stripPrefix(idText, TEAM_ID_PREFIX);
            teamByID.put(id, currentTeam);

            getTeamsIterator().add(currentTeam);
          }

          playersByPositionIterator = currentTeam.playersByPositionIterator();
        }
        else if(localName.equals(NOTES_TAG))
        {
          inNotes = true;
        }
        else
        {
          super.startElement(uri, localName, rawName, attributes);
        }
      }
    }

    private class SupplementFileNonNESAlternateUniformDataSAXReader extends
        SupplementFileSAXReader
    {
      private Team currentTeam;

      private SupplementFileNonNESAlternateUniformDataSAXReader()
      {
      }

      @Override
      public void startElement(String uri, String localName, String rawName,
          Attributes attributes) throws SAXException
      {
        if(localName.equals(TEAM_TAG))
        {
          currentTeam = getTeamsIterator().next();
        }
        else if(localName.equals(VERSUS_TAG))
        {
          int otherTeamID = getAttributeValue(attributes, TEAM_ATTRIBUTE);
          Team otherTeam = teamByID.get(otherTeamID);
          currentTeam.addAlternateUniformWhenPlaying(otherTeam);
        }
        else
        {
          super.startElement(uri, localName, rawName, attributes);
        }
      }
    }

    // TODO does this handle formations for non-NES teams, too?
    // If so, do I need to handle them in the other code, or at least could I
    // avoid doing so after some tweaking?
    private class SupplementFileNESTeamFormationsSAXReader extends
        SupplementFileSAXReader
    {
      private SupplementFileNESTeamFormationsSAXReader()
      {
      }

      @Override
      public void startElement(String uri, String localName, String rawName,
          Attributes attributes) throws SAXException
      {
        if(localName.equals(TEAM_TAG))
        {
          if(getTeamsIterator().hasNext())
          {
            Team team = getTeamsIterator().next();
            String formationAbbreviation =
                attributes.getValue(OFFENSIVE_FORMATION_ATTRIBUTE);
            team.setOffensiveFormation(OffensiveFormation
                .getFormationFromAbbreviation(formationAbbreviation));
          }
        }
        else
        {
          super.startElement(uri, localName, rawName, attributes);
        }
      }
    }

    private class SupplementFileOverriddenProBowlersSAXReader extends
        DefaultHandler
    {
      @Override
      public void startElement(String uri, String localName, String rawName,
          Attributes attributes)
      {
        if(localName.equals(REPLACED_PRO_BOWLER_TAG))
        {
          AFC_NFC_Other afcNfcOther =
              AFC_NFC_Other.values()[getAttributeValue(attributes,
                  CONFERENCE_ATTRIBUTE)];
          Conference conference = league.getConference(afcNfcOther);
          ProBowlTeam proBowlTeam = conference.getProBowlTeam();
          String playerIdWithPrefix = attributes.getValue(PLAYER_ATTRIBUTE);
          int id = stripPrefix(playerIdWithPrefix, PLAYER_ID_PREFIX);
          ProBowlSlot slot =
              ProBowlSlot.values()[getAttributeValue(attributes,
                  PRO_BOWL_SLOT_ATTRIBUTE)];
          Player player = playerByID.get(id);

          /*
           * There's no need to clear the player, too, since only ROM players
           * can be listed as Pro Bowlers in the ROM and only non-ROM players
           * can be listed as Pro Bowlers in the supplement file.
           * 
           * (Likewise with "proper-conference" substituted for "ROM.")
           */
          proBowlTeam.clearSlot(slot);
          proBowlTeam.putPlayer(slot, player);
        }
      }
    }

    private class SupplementFileReturnersSAXReader extends
        SupplementFileSAXReader
    {
      private Team currentTeam;

      private SupplementFileReturnersSAXReader()
      {
      }

      @Override
      public void startElement(String uri, String localName, String rawName,
          Attributes attributes) throws SAXException
      {
        if(localName.equals(TEAM_TAG))
        {
          currentTeam = getTeamsIterator().next();
        }
        else if(localName.equals(RETURNER_TAG))
        {
          String returnJobString = attributes.getValue(RETURN_JOB_ATTRIBUTE);
          ReturnJob returnJob = ReturnJob.valueOf(returnJobString);

          if(attributes.getValue(NO_PLAYER_ATTRIBUTE) != null)
          {
            // The returner listed in the NES file is a default that the user
            // never asked for. Further, the user never asked for *any* player
            // to be made returner.
            currentTeam.setReturner(returnJob, null);
          }
          else
          {
            int returnerID = getAttributeValue(attributes, PLAYER_ATTRIBUTE);
            Player returner = playerByID.get(returnerID);

            currentTeam.setReturner(returnJob, returner);
          }
        }
        else
        {
          super.startElement(uri, localName, rawName, attributes);
        }
      }
    }
  }

  public League readLeague() throws IOException, NesFileFormatException,
    SupplementFileFormatException
  {
    SupplementedNesFileReader reader = new SupplementedNesFileReader();
    return reader.readLeague();
  }

  private class SupplementedNesFileWriter extends SupplementedNesFilePhase
  {
    private SupplementedNesFileWriter(League league) throws IOException
    {
      super("rw", league);
    }

    private final PrintWriter supplementFileWriter =
        new PrintWriter(new BufferedWriter(new FileWriter(supplementFile)));
    private final XMLSerializer serializer =
        new XMLSerializer(supplementFileWriter, prettyXML);

    private final Map<Integer, Player> playerByID =
        new HashMap<Integer, Player>();
    private final Map<Player, Integer> idByPlayer =
        new HashMap<Player, Integer>();

    /**
     * Pro Bowl slots in each conference that were filled by non-NES or
     * wrong-conference players. These slots had replacement players written
     * instead of the selected ones. We must write the selected players to disk
     * so that when the league is loaded, the selected players are still flagged
     * as Pro Bowlers.
     * 
     * This Map is populated by {@link #writeProBowlPlayers(Conference)}.
     */
    private final SetMultimap<Conference, ProBowlSlot> overriddenProBowlSlots =
        newHashMultimap();

    private int encodeAlternateSpriteColorsCode(Team team)
    {
      int code = 0;

      for(Pair<Team, Integer> teamAndIndex : league
          .nesTeamsOrDummiesWithIndexes())
      {
        Team otherTeam = teamAndIndex.getFirst();
        int i = teamAndIndex.getSecond();

        if(team.getWearsAlternateUniformWhenPlayingTeam(otherTeam))
        {
          int shift = 31 - i;
          int mask = 1 << shift;
          code |= mask;
        }
      }

      return code;
    }

    // TODO clean this up now that there is only one
    private final Map<Team, PlayersOrDummiesByPositionIterator> theOnePlayersByPositionIterator =
        newHashMapWithExpectedSize(32);

    private void setUpPlayersByPositionIterators()
    {
      setUpPlayersByPositionIterators(theOnePlayersByPositionIterator);
    }

    private void setUpPlayersByPositionIterators(
        Map<Team, PlayersOrDummiesByPositionIterator> map)
    {
      for(Team currentTeam : league.teams())
      {
        map.put(currentTeam,
            new PlayersOrDummiesByPositionIterator(currentTeam));
      }
    }

    private void numberAllPlayers()
    {
      int nextID = 0;

      for(Team team : league.teams())
      {
        PlayersByPositionIterator viewOfCurrentTeam =
            team.playersByPositionIterator();

        for(Position position : Position.allPositions())
        {
          while(viewOfCurrentTeam.hasNextPlayerAtPosition(position))
          {
            Player player = viewOfCurrentTeam.nextPlayerAtPosition(position);

            // TODO BiMap!
            playerByID.put(nextID, player);
            idByPlayer.put(player, nextID);

            nextID++;
          }
        }
      }
    }

    private void fillInTeamPointers()
    {
      // Since we pack all the player pointers together in sequence, the teams
      // are located at regularly placed spots in the file.
      TsbLocation nextTeamLocation = tsbFile.FIRST_TEAM_PLAYER_POINTER_LOCATION;

      for(Division division : league.divisions())
      {
        int teamCount = division.getNESTeamCount();
        for(int teamIndex = 0; teamIndex < teamCount; teamIndex++)
        {
          teamLocations.add(nextTeamLocation);
          nextTeamLocation = nextTeamLocation.add(PLAYERS_PER_TEAM_COUNT * 2);
        }
      }
    }

    private void writeTSBMTeamFormationPatch() throws IOException
    {
      tsbFile.seek(tsbFile.FORMATION_POSITION_SECTIONS_CODE_LOCATION);
      tsbFile
          .writeUnsignedBytes(tsbFile.FORMATION_POSITION_SECTIONS_CODE_PATCH);

      tsbFile.seek(tsbFile.FORMATION_POSITION_LABELS_CODE_LOCATION);
      tsbFile.writeUnsignedBytes(tsbFile.FORMATION_POSITION_LABELS_CODE_PATCH);
    }

    private void writeTeamFormations() throws IOException
    {
      tsbFile.seek(tsbFile.FORMATION_POSITION_SECTIONS_LOCATION);
      for(Team currentTeam : league.nesTeamsOrDummies())
      {
        tsbFile.writeByte(currentTeam.getOffensiveFormation()
            .getPositionSectionsID());
      }

      tsbFile.seek(tsbFile.FORMATION_POSITION_LABELS_LOCATION);
      for(Team currentTeam : league.nesTeamsOrDummies())
      {
        tsbFile.writeByte(currentTeam.getOffensiveFormation()
            .getPositionLabelsID());
      }
    }

    private void writeTeamPointers() throws IOException
    {
      tsbFile.seek(tsbFile.TEAM_POINTERS_LOCATION);
      for(TsbLocation teamLocation : teamLocations)
      {
        tsbFile.writePlayerRelatedLocation(teamLocation);
      }
    }

    private void writePlayerNamePointers() throws IOException
    {
      for(Pair<TsbLocation, List<TsbLocation>> locations : pairIterable(
          teamLocations, playerNameLocations))
      {
        TsbLocation teamLocation = locations.getFirst();
        List<TsbLocation> playerNameLocations = locations.getSecond();
        tsbFile.seek(teamLocation);
        for(TsbLocation playerNameLocation : playerNameLocations)
        {
          tsbFile.writePlayerRelatedLocation(playerNameLocation);
        }
      }
      tsbFile.writePlayerRelatedLocation(endOfPlayerNamesLocation);
    }

    private PlayersByPositionIterator viewOfTeam(
        Map<Team, PlayersOrDummiesByPositionIterator> teamViews, Team team)
    {
      PlayersByPositionIterator view = teamViews.get(team);

      if(view != null)
      {
        return view;
      }

      return new PlayersOrDummiesByPositionIterator(new Team());
    }

    private void truncateNamesIfNecessary(List<Player> players)
      throws NesFileFormatException
    {
      TreeSet<Player> olsLongToShortNames =
          new TreeSet<Player>(FIRST_NAME_LENGTH_COMPARATOR_LONG_TO_SHORT);

      int totalLength = 0;

      for(Player currentPlayer : players)
      {
        if(isNameTooLong(currentPlayer))
        {
          abbreviateFirst(currentPlayer);
        }

        String name = nesPlayerName(currentPlayer);

        // Don't forget the uniform number.
        totalLength += name.length() + 1;

        if(currentPlayer.attributes() == AttributeList.OL_ATTRIBUTES)
        {
          olsLongToShortNames.add(currentPlayer);
        }
      }

      // Don't forget the ff we write at the end for some reason.
      int maxTotalLength =
          tsbFile.PLAYER_ATTRIBUTES_LOCATION
              .subtract(tsbFile.FIRST_PLAYER_NAME_LOCATION) - 1;

      if(totalLength > maxTotalLength)
      {
        for(Player currentPlayer : olsLongToShortNames)
        {
          String oldFirstName = currentPlayer.getFirst();
          abbreviateFirst(currentPlayer);

          int spaceSaved =
              oldFirstName.length() - currentPlayer.getFirst().length();
          totalLength -= spaceSaved;

          if(totalLength <= maxTotalLength)
          {
            return;
          }
        }

        throw new NesFileFormatException(
            "Player names are too long to fit in the ROM.  Max length: "
                + maxTotalLength
                + "; current length (after abbreviating offensive linemen's names): "
                + totalLength);
      }
    }

    // TODO enum for starters/backups distinction instead of boolean?
    private void addStartersOrBackupsToList(List<Player> list,
        boolean isStarters)
    {
      for(Team currentTeam : league.nesTeamsOrDummies())
      {
        PlayersByPositionIterator viewOfCurrentTeam =
            viewOfTeam(theOnePlayersByPositionIterator, currentTeam);

        for(Position currentPosition : currentTeam
            .startersOrBackupsOfAllFormations(isStarters))
        {
          Player currentPlayer =
              viewOfCurrentTeam.nextPlayerAtPosition(currentPosition);

          list.add(currentPlayer);
        }
      }
    }

    private Pair<List<Player>, List<Player>> nesStartersAndBackups()
    {
      List<Player> starters = new ArrayList<Player>();
      List<Player> backups = new ArrayList<Player>();
      Pair<List<Player>, List<Player>> startersAndBackups =
          new Pair<List<Player>, List<Player>>(starters, backups);

      addStartersOrBackupsToList(starters, true);
      addStartersOrBackupsToList(backups, false);

      return startersAndBackups;
    }

    private List<Player> nesPlayers()
    {
      Pair<List<Player>, List<Player>> startersAndBackups =
          nesStartersAndBackups();
      Iterator<Player> starters = startersAndBackups.getFirst().iterator();
      Iterator<Player> backups = startersAndBackups.getSecond().iterator();

      List<Player> nesPlayers = new ArrayList<Player>();

      for(Team currentTeam : league.nesTeamsOrDummies())
      {
        for(Boolean isStarter : currentTeam.getIsStarterListForAllFormations())
        {
          if(isStarter)
          {
            nesPlayers.add(starters.next());
          }
          else
          {
            nesPlayers.add(backups.next());
          }
        }
      }

      return nesPlayers;
    }

    private void writePlayerNames(List<Player> playersList) throws IOException
    {
      Iterator<Player> players = playersList.iterator();

      // We need to seek only once, since we pack the names together in
      // sequence.
      tsbFile.seek(tsbFile.FIRST_PLAYER_NAME_LOCATION);

      // TODO back to a flat list?
      for(List<TsbLocation> currentTeamPlayerNameLocations : playerNameLocations)
      {
        for(int i = 0; i < PLAYERS_PER_TEAM_COUNT; i++)
        {
          Player currentPlayer = players.next();

          String name = nesPlayerName(currentPlayer);

          currentTeamPlayerNameLocations.add(tsbFile.getFileLocation());

          tsbFile.writeByteValueThatLooksInHexLikeInt(currentPlayer
              .getUniformNumber());
          tsbFile.writeString(name);
        }
      }

      endOfPlayerNamesLocation = tsbFile.getFileLocation();

      // TODO TSBM does this -- is there any good reason for that?
      tsbFile.writeUnsignedByte(0xff);
    }

    private void writePlayerAttributes(List<Player> playersList)
      throws IOException
    {
      tsbFile.seek(tsbFile.PLAYER_ATTRIBUTES_LOCATION);
      for(Player currentPlayer : playersList)
      {
        int attributeCount = currentPlayer.getAttributeCount();

        byte[] nybbles = new byte[attributeCount + RACE_FACE_CODE_BYTE_COUNT];

        Iterator<Attribute> attributeIterator =
            currentPlayer.attributesIterator();
        int raceFaceCode = currentPlayer.getAppearance().getRaceFaceCode();
        for(int attributeIndex = 0; attributeIndex < attributeCount
            + RACE_FACE_CODE_BYTE_COUNT; attributeIndex++)
        {
          if(attributeIndex == RACE_FACE_CODE_BYTE_1)
          {
            nybbles[attributeIndex] = (byte) (raceFaceCode >> 4);
          }
          else if(attributeIndex == RACE_FACE_CODE_BYTE_2)
          {
            nybbles[attributeIndex] = (byte) (raceFaceCode & 0x0F);
          }
          else
          {
            Attribute currentAttribute = attributeIterator.next();
            nybbles[attributeIndex] =
                (byte) currentPlayer.getComputerAttribute(currentAttribute);
          }
        }

        tsbFile.writeNybbles(nybbles);
      }
    }

    private List<String> teamRelatedStrings()
    {
      List<String> teamRelatedStrings = new ArrayList<String>();
      Iterator<String> strings = league.getOtherTeamRelatedStrings().iterator();

      for(Team team : league.nesTeamsOrDummies())
      {
        teamRelatedStrings.add(team.getAbbreviation());
      }

      drain(strings, teamRelatedStrings, MYSTERY_LOCATION_COUNT);

      for(Team team : league.nesTeamsOrDummies())
      {
        teamRelatedStrings.add(team.getCity());
      }

      drain(strings, teamRelatedStrings, MYSTERY_LOCATION_COUNT);

      for(Team team : league.nesTeamsOrDummies())
      {
        teamRelatedStrings.add(team.getName());
      }

      drain(strings, teamRelatedStrings, POST_MYSTERY_LOCATION_COUNT);

      return teamRelatedStrings;
    }

    private void writeTeamRelatedStrings(List<String> teamRelatedStrings)
      throws IOException
    {
      tsbFile.seek(tsbFile.FIRST_TEAM_NAME_LOCATION);

      for(String string : teamRelatedStrings)
      {
        tsbFile.writeString(string);
      }
    }

    private void writeTeamRelatedStringPointers(List<String> teamRelatedStrings)
      throws IOException
    {
      tsbFile.seek(tsbFile.FIRST_TEAM_NAME_POINTER_LOCATION);

      TsbLocation location = tsbFile.FIRST_TEAM_NAME_LOCATION;
      for(String string : teamRelatedStrings)
      {
        tsbFile.writeTeamRelatedLocation(location);
        location = location.add(string.length());
      }
      tsbFile.writeTeamRelatedLocation(location);
    }

    private void writeReturners() throws IOException
    {
      for(TsbLocation location : Arrays.asList(tsbFile.RETURNERS_LOCATION_1,
          tsbFile.RETURNERS_LOCATION_2))
      {
        writeReturners(location);
      }
    }

    private void writeReturners(TsbLocation location) throws IOException
    {
      tsbFile.seek(location);

      for(Team team : league.nesTeamsOrDummies())
      {
        byte[] returnerIndexes = new byte[2];

        returnerIndexes[0] = findReturnerIndexOrDummy(team, ReturnJob.KR);
        returnerIndexes[1] = findReturnerIndexOrDummy(team, ReturnJob.PR);

        tsbFile.writeNybbles(returnerIndexes);
      }
    }

    private byte findReturnerIndexOrDummy(Team team, ReturnJob returnJob)
    {
      byte index = indexOfReturner(team, returnJob);

      if(index == -1)
      {
        return DEFAULT_RETURNER_INDEX;
      }

      return index;
    }

    private byte indexOfReturner(Team team, ReturnJob returnJob)
    {
      Player returner = team.getReturner(returnJob);
      int index = team.getIndexOfPlayer(returner);
      return (byte) index;
    }

    private void writeProBowlPlayers(Conference conference) throws IOException
    {
      class PlayerLocation extends Pair<Byte, Byte>
      {
        PlayerLocation(int team, int player)
        {
          super((byte) team, (byte) player);
        }

        byte getTeam()
        {
          return getFirst();
        }

        byte getPlayer()
        {
          return getSecond();
        }
      }

      /*
       * We need to build a map before writing to the ROM because, if a player
       * is missing, we need to pick a replacement from the players that do not
       * already appear on the team. We cannot go by ProBowlTeam.getSlot(Player)
       * because we may be dealing with default players -- even whole default
       * teams, as in an empty league.
       */
      BiMap<ProBowlSlot, PlayerLocation> slotToLocation =
          newEnumHashBiMap(ProBowlSlot.class);

      ProBowlTeam proBowlTeam = conference.getProBowlTeam();

      // TODO FIXME ONLY TEAMS IN THIS CONFERENCE
      // TODO handle case where the player isn't an NES player (or in the wrong
      // conference)
      Map<Team, Integer> indexByTeam = league.nesTeamsOrDummiesToIndexes();
      Map<Team, Map<Player, Integer>> indexByPlayerByTeam =
          new HashMap<Team, Map<Player, Integer>>();

      for(Team team : indexByTeam.keySet())
      {
        indexByPlayerByTeam.put(team, team.getIndexesOfNesPlayers());
      }

      for(ProBowlSlot slot : ProBowlSlot.values())
      {
        Player player = proBowlTeam.getPlayer(slot);

        for(Map.Entry<Team, Map<Player, Integer>> teamToPlayerIndexes : indexByPlayerByTeam
            .entrySet())
        {
          Team team = teamToPlayerIndexes.getKey();
          Map<Player, Integer> playerIndexes = teamToPlayerIndexes.getValue();

          Integer playerIndex = playerIndexes.get(player);

          if(playerIndex == null)
          {
            continue;
          }
          else if(conference.containsTeam(team))
          {
            Integer teamIndex = indexByTeam.get(team);

            slotToLocation
                .put(slot, new PlayerLocation(teamIndex, playerIndex));

            break;
          }
        }
      }

      for(ProBowlSlot slot : ProBowlSlot.values())
      {
        PlayerLocation location = slotToLocation.get(slot);
        if(location == null)
        {
          overriddenProBowlSlots.put(conference, slot);

          // We didn't find him. Non-NES player or wrong conference.
          /*
           * TODO notify user -- remember that one way this can happen is if
           * there was a trimmed default player previously filling this slot
           */
          /*
           * Loop over the teams in the conference to find an unused player with
           * the appropriate AttributeList. Ideally we'd pick a RB for a RB
           * slot, a WR for a WR slot, etc., but this requires knowledge of the
           * existing teams' formations, and that's a lot of trouble to go
           * through for an edge case.
           */
          final int startIndex =
              conference.getAFCNFCOther() == AFC ? 0 : CONFERENCE_TEAM_COUNT;
          /*
           * The positions won't be right for non-Pro-Set teams, but the
           * AttributeLists still match up, so it's okay.
           */
          List<Position> positionsForIndexes =
              ImmutableList.copyOf(new Team()
                  .positionOfEachPlayerInAllFormations());
          fillInLoop: for(int teamIndex = startIndex; teamIndex < startIndex
              + CONFERENCE_TEAM_COUNT; teamIndex++)
          {
            for(int playerIndex = 0; playerIndex < PLAYERS_PER_TEAM_COUNT; playerIndex++)
            {
              Position position = positionsForIndexes.get(playerIndex);
              if(position.getAttributeList() == slot.getAttributeList())
              {
                location = new PlayerLocation(teamIndex, playerIndex);
                if(!slotToLocation.containsValue(location))
                {
                  /*
                   * We need to put him in the map to ensure that we don't reuse
                   * him if there are multiple missing players.
                   */
                  slotToLocation.put(slot, location);
                  break fillInLoop;
                }
              }
            }
          }
        }

        tsbFile.writeByte(location.getTeam());
        tsbFile.writeByte(location.getPlayer());
      }
    }

    // TODO Pro Bowl return men
    private void writeProBowlPlayers() throws IOException
    {
      tsbFile.seek(tsbFile.PRO_BOWL_PLAYERS_LOCATION);

      writeProBowlPlayers(league.getAFC());
      writeProBowlPlayers(league.getNFC());
    }

    private void writeSpriteColors() throws IOException
    {
      tsbFile.seek(tsbFile.SPRITE_COLORS_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        List<PaletteColor> spriteColors1 = team.getSpriteColors1();
        List<PaletteColor> spriteColors2 = team.getSpriteColors2();

        for(PaletteColor color : Arrays.asList(spriteColors1.get(0),
            spriteColors1.get(2), spriteColors1.get(1), spriteColors2.get(0),
            spriteColors2.get(2), spriteColors2.get(1)))
        {
          tsbFile.writeUnsignedByte(color.getIndex());
        }

        tsbFile.writeInt(encodeAlternateSpriteColorsCode(team));
      }
    }

    private void writeCutsceneColors() throws IOException
    {
      tsbFile.seek(tsbFile.CUTSCENE_COLORS_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        List<PaletteColor> spriteColors1 = team.getSpriteColors1();
        List<PaletteColor> spriteColors2 = team.getSpriteColors2();

        for(PaletteColor color : Arrays.asList(spriteColors1.get(0),
            spriteColors1.get(1), spriteColors2.get(0), spriteColors2.get(1)))
        {
          tsbFile.writeUnsignedByte(color.getIndex());
        }

        // TODO I just use the sprite-colors code instead of the cutscene-color
        // code
        tsbFile.writeInt(encodeAlternateSpriteColorsCode(team));
      }
    }

    private void writeTeamPlaybooks() throws IOException
    {
      tsbFile.seek(tsbFile.PLAYBOOKS_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        byte[] playIndexes = new byte[Play.PAGES];

        for(Page page : Page.values())
        {
          Play play = team.getPlaybook().get(page);
          int index = league.getBinder().indexOfPlayInPage(page, play);

          playIndexes[page.getIndex()] = (byte) index;
        }

        tsbFile.writeNybbles(playIndexes);
      }
    }

    private void writePlayerDataColors() throws IOException
    {
      tsbFile.seek(tsbFile.PLAYER_DATA_COLORS_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        tsbFile.writePaletteColor(team.getPlayerDataColor());
      }
    }

    private void writeRunPassRatios() throws IOException
    {
      tsbFile.seek(tsbFile.RUN_PASS_RATIO_LOCATION);

      for(Team team : league.nesTeamsOrDummies())
      {
        tsbFile.writeByte(team.getRunPassRatio().getComputerValue());
      }
    }

    private void writeSimulationCodes(List<Player> nesPlayers)
      throws IOException
    {
      new SimulationCodes(nesPlayers).writeSimulationBytes(tsbFile);
    }

    private List<Player> cloneAllPlayers(List<Player> originalPlayers)
    {
      return list(CLONE_PLAYER_MAPPER.applyAll(originalPlayers));
    }

    private void writeLeague() throws IOException, NesFileFormatException
    {
      setUpPlayersByPositionIterators();

      numberAllPlayers();

      List<Player> nesPlayers = nesPlayers();
      // TODO document the reason for this
      nesPlayers = cloneAllPlayers(nesPlayers);

      // TODO presumably team names could be too long, as well
      truncateNamesIfNecessary(nesPlayers);
      setUpTeamAndPlayerPointers();
      fillInTeamPointers();
      writeTSBMTeamFormationPatch();
      writeTeamFormations();
      writePlayerAttributes(nesPlayers);
      writePlayerNames(nesPlayers);
      writePlayerNamePointers();
      writeTeamPointers();
      // TODO make a field?
      List<String> teamRelatedStrings = teamRelatedStrings();
      writeTeamRelatedStrings(teamRelatedStrings);
      writeTeamRelatedStringPointers(teamRelatedStrings);
      writeReturners();
      writeProBowlPlayers();
      writeSpriteColors();
      writeCutsceneColors();
      writePlayerDataColors();
      writeRunPassRatios();
      writeTeamPlaybooks();
      writeSimulationCodes(nesPlayers);
      writeSupplementFile();

      close();
    }

    private void emptyElement(String name, Attributes attributes)
      throws SAXException
    {
      startElement(name, attributes);
      endElement(name);
    }

    private void startElement(String name, Attributes attributes)
      throws SAXException
    {
      serializer.startElement(null, null, name, attributes);
    }

    private void startElement(String name) throws SAXException
    {
      serializer.startElement(null, null, name, null);
    }

    private void endElement(String name) throws SAXException
    {
      serializer.endElement(null, null, name);
    }

    private void addAttribute(AttributesImpl attributes, String name,
        String value)
    {
      attributes.addAttribute(null, null, name, null, value);
    }

    private void addAttribute(AttributesImpl attributes, String name, int value)
    {
      addAttribute(attributes, name, Integer.toString(value));
    }

    private void writeAlternateUniformTeam(int index) throws SAXException
    {
      AttributesImpl attributes = new AttributesImpl();
      addAttribute(attributes, TEAM_ATTRIBUTE, index);

      emptyElement(VERSUS_TAG, attributes);
    }

    private void writeAlternateUniformDataForTeams(Team currentTeam,
        Iterable<Pair<Team, Integer>> teamsAndIndexes) throws SAXException
    {
      for(Pair<Team, Integer> teamAndIndex : teamsAndIndexes)
      {
        Team nesTeam = teamAndIndex.getFirst();
        Integer index = teamAndIndex.getSecond();

        if(currentTeam.getWearsAlternateUniformWhenPlayingTeam(nesTeam))
        {
          writeAlternateUniformTeam(index);
        }
      }
    }

    private void writeSupplementAlternateUniformData(Team currentTeam,
        boolean isNESTeam) throws SAXException
    {
      startElement(ALTERNATE_UNIFORM_CODE_TAG);

      if(!isNESTeam)
      {
        writeAlternateUniformDataForTeams(currentTeam, league
            .nesTeamsOrDummiesWithIndexes());
      }

      writeAlternateUniformDataForTeams(currentTeam, league
          .nonNESTeamsWithIndexes());

      endElement(ALTERNATE_UNIFORM_CODE_TAG);
    }

    private void writeReturners(Team currentTeam, boolean isNESTeam)
      throws SAXException
    {
      startElement(RETURNERS_TAG);

      for(ReturnJob returnJob : ReturnJob.values())
      {
        writeReturner(currentTeam, returnJob, isNESTeam);
      }

      endElement(RETURNERS_TAG);
    }

    private void writeReturner(Team currentTeam, ReturnJob returnJob,
        boolean isNESTeam) throws SAXException
    {
      AttributesImpl attributes = new AttributesImpl();
      addAttribute(attributes, RETURN_JOB_ATTRIBUTE, returnJob.name());

      Player returner = currentTeam.getReturner(returnJob);

      // No returner set; the case for newly created teams.
      if(returner == null)
      {
        if(isNESTeam)
        {
          addAttribute(attributes, NO_PLAYER_ATTRIBUTE, NO_PLAYER_VALUE);
          emptyElement(RETURNER_TAG, attributes);
        }
        return;
      }

      byte index = indexOfReturner(currentTeam, returnJob);

      // Only if the player is not an NES player or not on this team or if this
      // is not an NES team.
      if(index == -1 || !isNESTeam)
      {
        Integer id = idByPlayer.get(returner);

        if(id == null)
        {
          // Player has been deleted by user.
          /*
           * TODO notify user -- remember that one way this can happen is if
           * there was a trimmed default player previously filling this job
           */
          return;
        }

        addAttribute(attributes, PLAYER_ATTRIBUTE, id);

        emptyElement(RETURNER_TAG, attributes);
      }
    }

    private void writeTeamToSupplementFile(Team currentTeam, boolean isNESTeam,
        int id) throws SAXException
    {
      AttributesImpl attributes = new AttributesImpl();
      addAttribute(attributes, OFFENSIVE_FORMATION_ATTRIBUTE, currentTeam
          .getOffensiveFormation().getSupplementID());
      addAttribute(attributes, ID_ATTRIBUTE, TEAM_ID_PREFIX + id);

      if(isNESTeam)
      {
        startElement(TEAM_TAG, attributes);

        Team.PlayersByPositionIterator viewOfCurrentTeam =
            currentTeam.playersByPositionIterator();
        writeKnownPlayers(currentTeam, viewOfCurrentTeam);
        writeUnknownPlayers(currentTeam, viewOfCurrentTeam);
      }
      else
      {
        addAttribute(attributes, CITY_ATTRIBUTE, currentTeam.getCity());
        addAttribute(attributes, NAME_ATTRIBUTE, currentTeam.getName());
        addAttribute(attributes, ABBREVIATION_ATTRIBUTE, currentTeam
            .getAbbreviation());
        addAttribute(attributes, PLAYER_DATA_COLOR_ATTRIBUTE, currentTeam
            .getPlayerDataColor().getIndex());
        addAttribute(attributes, RUN_PASS_RATIO_ATTRIBUTE, currentTeam
            .getRunPassRatio().getComputerValue());

        startElement(TEAM_TAG, attributes);

        Team.PlayersByPositionIterator viewOfCurrentTeam =
            currentTeam.playersByPositionIterator();
        writeUnknownPlayers(currentTeam, viewOfCurrentTeam);

        AttributesImpl spriteColorsAttributes = new AttributesImpl();

        startElement(SPRITE_COLORS_TAG, spriteColorsAttributes);

        for(PaletteColor color : concat(currentTeam.getSpriteColors1(),
            currentTeam.getSpriteColors2()))
        {
          // TODO here and elsewhere, try creating my own implementations of
          // Attributes that handle some of this stuff themselves when given a
          // team or whatever
          AttributesImpl colorAttributes = new AttributesImpl();
          addAttribute(colorAttributes, INDEX_ATTRIBUTE, color.getIndex());
          emptyElement(COLOR_TAG, colorAttributes);
        }

        endElement(SPRITE_COLORS_TAG);

        startElement(PLAYBOOK_TAG);

        for(Page page : Page.values())
        {
          Play play = currentTeam.getPlaybook().get(page);
          int index = league.getBinder().indexOfPlayInPage(page, play);

          // TODO perhaps a new method for empty elements with single attributes
          AttributesImpl playAttributes = new AttributesImpl();
          addAttribute(playAttributes, INDEX_ATTRIBUTE, index);
          emptyElement(PLAY_TAG, playAttributes);
        }

        endElement(PLAYBOOK_TAG);
      }

      writeSupplementAlternateUniformData(currentTeam, isNESTeam);

      writeReturners(currentTeam, isNESTeam);

      writeNotes(currentTeam);

      endElement(TEAM_TAG);
    }

    private void writeSupplementFile() throws IOException
    {
      try
      {
        serializer.startDocument();
        startElement(LEAGUE_TAG);

        int nextNESTeamID = 0;
        int nextNonNESTeamID = NES_TEAMS_COUNT;

        for(Division division : league.divisions())
        {
          startElement(DIVISION_TAG);

          for(Team team : division.nesTeams(false))
          {
            writeTeamToSupplementFile(team, true, nextNESTeamID++);
          }
          for(Team team : division.nonNESTeams())
          {
            writeTeamToSupplementFile(team, false, nextNonNESTeamID++);
          }

          endElement(DIVISION_TAG);
        }

        writeProBowlOverridesToSupplementFile();

        endElement(LEAGUE_TAG);
        serializer.endDocument();
      }
      catch(SAXException e)
      {
        // TODO should never happen, right?
        throw new RuntimeException();
      }
      if(supplementFileWriter.checkError())
      {
        throw new IOException("I/O error writing supplement file");
      }
    }

    private void writeProBowlOverridesToSupplementFile() throws SAXException
    {
      writeProBowlOverridesToSupplementFile(AFC);
      writeProBowlOverridesToSupplementFile(NFC);
    }

    private void writeProBowlOverridesToSupplementFile(AFC_NFC_Other afcNfcOther)
      throws SAXException
    {
      Conference conference = league.getConference(afcNfcOther);
      ProBowlTeam proBowlTeam = conference.getProBowlTeam();

      for(ProBowlSlot slot : overriddenProBowlSlots.get(conference))
      {
        Player player = proBowlTeam.getPlayer(slot);
        Integer id = idByPlayer.get(player);

        if(id == null)
        {
          // Player has been deleted by user.
          continue;
        }

        AttributesImpl attributes = new AttributesImpl();
        addAttribute(attributes, CONFERENCE_ATTRIBUTE, conference
            .getAFCNFCOther().ordinal());
        addAttribute(attributes, PLAYER_ATTRIBUTE, PLAYER_ID_PREFIX + id);
        addAttribute(attributes, PRO_BOWL_SLOT_ATTRIBUTE, slot.ordinal());

        emptyElement(REPLACED_PRO_BOWLER_TAG, attributes);
      }
    }

    private void writeKnownPlayers(Team team,
        Team.PlayersByPositionIterator viewOfCurrentTeam) throws SAXException
    {
      for(Position currentPosition : team.positionOfEachPlayerInAllFormations())
      {
        Player currentPlayer = null;
        String nesPlayerName = null;
        Integer playerID = null;

        // Need to call this so that we know we have handled this player.
        // Note that the player might not exist, in which case we're writing a
        // dummy record.
        // And now we need to call it to handle abbreviation of first names.
        if(viewOfCurrentTeam.hasNextPlayerAtPosition(currentPosition))
        {
          currentPlayer =
              viewOfCurrentTeam.nextPlayerAtPosition(currentPosition);
          nesPlayerName = nesPlayerName(currentPlayer);
          playerID = idByPlayer.get(currentPlayer);
        }

        AttributesImpl attributes = new AttributesImpl();
        addAttribute(attributes, POSITION_ATTRIBUTE, currentPosition
            .getAbbreviation());

        if(currentPlayer != null)
        {
          // TODO might be nice to include this only when the name is actually
          // abbreviated in the NES file, but storage is cheap, so...
          addAttribute(attributes, NAME_ATTRIBUTE, nesPlayerName);
          addAttribute(attributes, ID_ATTRIBUTE, PLAYER_ID_PREFIX + playerID);
        }

        startElement(PLAYER_TAG, attributes);

        writeNotes(currentPlayer);

        endElement(PLAYER_TAG);
      }
    }

    private void writeNotes(Notable notable) throws SAXException
    {
      String notes = notable == null ? "" : notable.getNotes();
      startElement(NOTES_TAG);
      serializer.characters(notes.toCharArray(), 0, notes.length());
      endElement(NOTES_TAG);
    }

    private void writeUnknownPlayers(Team team,
        Team.PlayersByPositionIterator viewOfCurrentTeam) throws SAXException
    {
      for(Position currentPosition : Position.allPositions())
      {
        while(viewOfCurrentTeam.hasNextPlayerAtPosition(currentPosition))
        {
          Player currentPlayer =
              viewOfCurrentTeam.nextPlayerAtPosition(currentPosition);

          AttributesImpl attributes = new AttributesImpl();

          addAttribute(attributes, POSITION_ATTRIBUTE, currentPosition
              .getAbbreviation());
          addAttribute(attributes, UNIFORM_NUMBER_ATTRIBUTE, currentPlayer
              .getUniformNumber());
          addAttribute(attributes, APPEARANCE_ATTRIBUTE, currentPlayer
              .getAppearance().getRaceFaceCode());
          addAttribute(attributes, NAME_ATTRIBUTE, nesPlayerName(currentPlayer));
          addAttribute(attributes, ID_ATTRIBUTE, PLAYER_ID_PREFIX
              + idByPlayer.get(currentPlayer));

          startElement(PLAYER_TAG, attributes);

          writeNotes(currentPlayer);

          writeUnknownPlayerAttributes(currentPlayer);

          endElement(PLAYER_TAG);
        }
      }
    }

    private void writeUnknownPlayerAttributes(Player player)
      throws SAXException
    {
      for(Attribute currentAttribute : player.attributes())
      {
        AttributesImpl attributes = new AttributesImpl();

        addAttribute(attributes, VALUE_ATTRIBUTE, player
            .getComputerAttribute(currentAttribute));
        emptyElement(ATTRIBUTE_TAG, attributes);
      }
    }

    @Override
    protected void close() throws IOException
    {
      super.close();
      supplementFileWriter.close();
    }
  }

  public void writeLeague(League league) throws IOException,
    NesFileFormatException
  {
    SupplementedNesFileWriter writer = new SupplementedNesFileWriter(league);
    writer.writeLeague();
  }

  public static String nesPlayerName(Player player)
  {
    return player.getFirst().toLowerCase() + player.getLast().toUpperCase();
  }

  private static class ClonePlayerMapper extends AbstractMapper<Player, Player>
  {
    @Override
    public Player apply(Player input)
    {
      return new Player(input);
    }
  }

  private static final Mapper<Player, Player> CLONE_PLAYER_MAPPER =
      new ClonePlayerMapper();

  private static class FirstNameLengthComparator extends Ordering<Player>
  {
    private static final long serialVersionUID = -5545038178752545270L;

    public int compare(Player o1, Player o2)
    {
      Integer l1 = o1.getFirst().length();
      Integer l2 = o2.getFirst().length();

      int cmp = l1.compareTo(l2);
      if(cmp != 0)
      {
        return cmp;
      }

      return o1.getFirst().compareTo(o2.getFirst());
    }
  }

  private static final Comparator<Player> FIRST_NAME_LENGTH_COMPARATOR_LONG_TO_SHORT =
      new FirstNameLengthComparator().reverseOrder();

  public boolean hasNoSupplementFile()
  {
    return supplementFile == null;
  }

  public void setSupplementFile(File supplementFile)
  {
    this.supplementFile = supplementFile;
  }

  public File getNESFile()
  {
    return rom;
  }
}
