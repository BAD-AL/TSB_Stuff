/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team.chooser;

import static org.twofoos.gmtsb.gui.util.SolidColorIcon.getIconForColor;

import java.awt.Frame;
import java.awt.GridLayout;

import org.twofoos.gmtsb.core.PaletteColor;
import org.twofoos.gmtsb.gui.chooser.SingleChooserPanel;

// TODO move out of gui.chooser
public class ColorChooserPanel extends SingleChooserPanel<PaletteColor>
{
  private static final long serialVersionUID = -5127785451783323527L;

  private static final int COLORS_PER_ROW = 16;

  public ColorChooserPanel(Frame chooserOwner, String title,
      PaletteColor initialColor, Iterable<PaletteColor> colorChoices)
  {
    super(chooserOwner, title);

    setLayout(new GridLayout(0, COLORS_PER_ROW, 2, 2));

    for(PaletteColor paletteColor : colorChoices)
    {
      ColorRadioButton currentButton = new ColorRadioButton(paletteColor);

      // setSelected() must happen after ChoooserButtonGroup.add() and
      // currentButton.addItemListener() so that ChooserButtonGroup and this
      // receive the ItemEvent.
      if(paletteColor == initialColor)
      {
        currentButton.setSelected(true);
      }

      add(currentButton.getBorderedContainer());
    }
  }

  private class ColorRadioButton extends ChooserRadioButton
  {
    private static final long serialVersionUID = -101968879611260180L;

    private ColorRadioButton(PaletteColor paletteColor)
    {
      super(paletteColor);
      setIcon(getIconForColor(paletteColor.getColor()));
      setToolTipText(paletteColor.getName());
    }
  }
}
