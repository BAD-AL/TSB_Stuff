/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.util.iterators;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Peek
{
  private Peek()
  {
  }

  private static abstract class AbstractPeekIterator<T> implements
      Iterator<Pair<T, T>>
  {
    protected final Iterator<T> iterator;
    protected T next;
    protected boolean hasNext;

    protected AbstractPeekIterator(Iterator<T> iterator)
    {
      this.iterator = iterator;
    }

    public boolean hasNext()
    {
      return hasNext;
    }

    public Pair<T, T> next()
    {
      if(!hasNext())
      {
        throw new NoSuchElementException();
      }

      T first = next;
      updateNext();
      T second = next;

      return new Pair<T, T>(first, second);
    }

    public void remove()
    {
      throw new UnsupportedOperationException("remove() not supported");
    }

    protected abstract void updateNext();
  }

  private static class PeekIterator<T> extends AbstractPeekIterator<T>
  {
    private final T peekPastEndValue;

    public PeekIterator(Iterator<T> iterator, T peekPastEndValue)
    {
      super(iterator);
      this.peekPastEndValue = peekPastEndValue;

      updateNext();
    }

    @Override
    protected void updateNext()
    {
      hasNext = iterator.hasNext();

      if(hasNext)
      {
        next = iterator.next();
      }
      else
      {
        next = peekPastEndValue;
      }
    }
  }

  private static class PeekIteratorNoLast<T> extends AbstractPeekIterator<T>
  {
    public PeekIteratorNoLast(Iterator<T> iterator)
    {
      super(iterator);

      updateNext();
    }

    @Override
    protected void updateNext()
    {
      hasNext = iterator.hasNext();

      if(hasNext)
      {
        next = iterator.next();

        hasNext = iterator.hasNext();
      }
    }
  }

  private static class PeekIterable<T> implements Iterable<Pair<T, T>>
  {
    private final Iterable<T> iterable;
    private final T peekPastEndValue;

    private PeekIterable(Iterable<T> iterable, T peekPastEndValue)
    {
      this.iterable = iterable;
      this.peekPastEndValue = peekPastEndValue;
    }

    public Iterator<Pair<T, T>> iterator()
    {
      return new PeekIterator<T>(iterable.iterator(), peekPastEndValue);
    }
  }

  private static class PeekIterableNoLast<T> implements Iterable<Pair<T, T>>
  {
    private final Iterable<T> iterable;

    private PeekIterableNoLast(Iterable<T> iterable)
    {
      this.iterable = iterable;
    }

    public Iterator<Pair<T, T>> iterator()
    {
      return new PeekIteratorNoLast<T>(iterable.iterator());
    }
  }

  /**
   * Given [0, 1, 2], returns <0, 1>, <1, 2>, <2, peekPastEndValue>.
   */
  public static <T> Iterable<Pair<T, T>> peekIterable(Iterable<T> iterable,
      T peekPastEndValue)
  {
    return new PeekIterable<T>(iterable, peekPastEndValue);
  }

  /**
   * Given [0, 1, 2], returns <0, 1>, <1, 2>.
   */
  public static <T> Iterable<Pair<T, T>> peekIterable(Iterable<T> iterable)
  {
    return new PeekIterableNoLast<T>(iterable);
  }
}
