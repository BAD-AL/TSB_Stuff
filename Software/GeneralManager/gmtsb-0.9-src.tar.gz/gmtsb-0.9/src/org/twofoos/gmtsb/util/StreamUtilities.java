/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.util;

import java.io.InputStream;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Pattern;

public class StreamUtilities
{
  // From Scanner.java.
  private static final Pattern LINE_SEPARATOR_PATTERN =
      Pattern.compile("\r\n|[\n\r\u2028\u2029\u0085]");

  private StreamUtilities()
  {
  }

  private static class ResourceLines implements Iterable<String>
  {
    private final String resourceName;

    private ResourceLines(String resourceName)
    {
      this.resourceName = resourceName;
    }

    public Iterator<String> iterator()
    {
      Scanner scanner = new Scanner(resourceStream(resourceName));
      scanner.useDelimiter(LINE_SEPARATOR_PATTERN);
      return scanner;
    }
  }

  public static InputStream resourceStream(String resourceName)
  {
    ClassLoader classLoader = StreamUtilities.class.getClassLoader();
    return classLoader.getResourceAsStream(resourceName);
  }

  public static Iterable<String> resourceLines(String resourceName)
  {
    return new ResourceLines(resourceName);
  }
}
