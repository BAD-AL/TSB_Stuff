/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;

import org.twofoos.gmtsb.core.Appearance;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.UserEventAggregator;
import org.twofoos.gmtsb.userevent.intrinsic.player.AppearanceChangeEvent;

// TODO combine some of this with LogoButton (or, more likely, the "real"
// uniform-color button)
public class FaceButton extends JButton implements ActionListener
{
  private static final long serialVersionUID = 1832248570106819258L;

  private final PlayerPanel playerPanel;

  public FaceButton(PlayerPanel playerPanel)
  {
    // We need to call super() first, of course. Unfortunately, we haven't
    // initialized playerPanel at that point, so we can't call
    // getPlayerAppearance(). As a result, we must setIcon() afterward instead
    // of passing the icon to the constructor as we might expect.
    super();
    this.playerPanel = playerPanel;

    updateIcon();

    setMargin(GUIUtils.EMPTY_INSETS);
    addActionListener(this);
  }

  private static final JLabel DROP_TO_SWAP_LABEL;

  static
  {
    DROP_TO_SWAP_LABEL =
        new JLabel("<html><center>Drop to<br>trade/<br>swap</center></html>");

    Font oldFont = DROP_TO_SWAP_LABEL.getFont();
    Font newFont = oldFont.deriveFont(0.75f * oldFont.getSize());
    DROP_TO_SWAP_LABEL.setForeground(Color.RED);

    DROP_TO_SWAP_LABEL.setFont(newFont);
    DROP_TO_SWAP_LABEL.setOpaque(false);
  }

  private static final Color TRANSPARENT_GRAY = new Color(192, 192, 192, 192);

  // TODO move to superclass once it exists
  @Override
  public void paint(Graphics g)
  {
    super.paint(g);

    Graphics2D g2d = (Graphics2D) g;

    if(playerPanel.isSwapTarget())
    {
      // TODO do not show the "copy" (+) cursor for swaps, even when control is
      // held
      g2d.setColor(TRANSPARENT_GRAY);
      g2d.fillRect(0, 0, getWidth(), getHeight());

      DROP_TO_SWAP_LABEL.setBounds(getBounds());
      DROP_TO_SWAP_LABEL.paint(g2d);
    }
  }

  private Player getPlayer()
  {
    return playerPanel.getPlayer();
  }

  private Appearance getPlayerAppearance()
  {
    return getPlayer().getAppearance();
  }

  private String getPlayerName()
  {
    return getPlayer().getFullName();
  }

  public void actionPerformed(ActionEvent e)
  {
    Appearance oldAppearance = getPlayerAppearance();
    Appearance newAppearance =
        FaceChooserPanel.showDialog(getMainFrame(), getPlayerAppearance(),
            getPlayerName());
    if(newAppearance != null)
    {
      AppearanceChangeEvent appearanceChangeEvent =
          new AppearanceChangeEvent(getPlayer(), oldAppearance, newAppearance);
      performAndPublish(appearanceChangeEvent);
    }
  }

  public void updateIcon()
  {
    setIcon(Faces.getImageIcon(getPlayerAppearance()));
  }

  public MainFrame getMainFrame()
  {
    return playerPanel.getMainFrame();
  }

  public UserEventAggregator getUserEventAggregator()
  {
    return getMainFrame().getUserEventAggregator();
  }

  public void performAndPublish(UserEvent e)
  {
    getUserEventAggregator().performAndPublish(e);
  }
}
