/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Multimaps.newArrayListMultimap;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import com.google.common.collect.ListMultimap;

public enum ProBowlSlot
{
  QB1(Position.QB), QB2(Position.QB),

  RB1(Position.RB), RB2(Position.RB), RB3(Position.RB), RB4(Position.RB),

  WR1(Position.WR), WR2(Position.WR), WR3(Position.WR), WR4(Position.WR),

  TE1(Position.TE), TE2(Position.TE),

  C1(Position.OL), G1(Position.OL), G2(Position.OL), T1(Position.OL), T2(
      Position.OL),

  DE1(Position.DL), NT1(Position.DL), DE2(Position.DL),

  OLB1(Position.LB), ILB1(Position.LB), ILB2(Position.LB), OLB2(Position.LB),

  CB1(Position.DB), CB2(Position.DB), S1(Position.DB), S2(Position.DB),

  K1(Position.K), P1(Position.P);

  private static final ListMultimap<AttributeList, ProBowlSlot> ATTRIBUTE_LIST_TO_SLOTS =
      newArrayListMultimap();
  private static final ListMultimap<Position, ProBowlSlot> POSITION_TO_SLOTS =
      newArrayListMultimap();

  static
  {
    for(ProBowlSlot slot : values())
    {
      ATTRIBUTE_LIST_TO_SLOTS.put(slot.getAttributeList(), slot);
      POSITION_TO_SLOTS.put(slot.getPosition(), slot);
    }
  }

  public static Collection<ProBowlSlot> getSlotsForPosition(Position position)
  {
    return Collections.unmodifiableList(POSITION_TO_SLOTS.get(position));
  }

  public static Collection<ProBowlSlot> getSlotsForAllCompatiblePositions(
      Position position)
  {
    return Collections.unmodifiableList(ATTRIBUTE_LIST_TO_SLOTS.get(position
        .getAttributeList()));
  }

  public static Collection<ProBowlSlot> getSlotsForOtherCompatiblePositions(
      Position position)
  {
    Collection<ProBowlSlot> mainSlots = getSlotsForPosition(position);
    Collection<ProBowlSlot> allSlots =
        getSlotsForAllCompatiblePositions(position);

    Collection<ProBowlSlot> otherSlots = new ArrayList<ProBowlSlot>(allSlots);

    otherSlots.removeAll(mainSlots);

    return Collections.unmodifiableCollection(otherSlots);
  }

  private final Position position;
  private final String number;

  private ProBowlSlot(Position position)
  {
    this.position = position;
    number = name().replaceAll("\\D+", "");
  }

  public Position getPosition()
  {
    return position;
  }

  public AttributeList getAttributeList()
  {
    return getPosition().getAttributeList();
  }

  public String getNumber()
  {
    return number;
  }
}
