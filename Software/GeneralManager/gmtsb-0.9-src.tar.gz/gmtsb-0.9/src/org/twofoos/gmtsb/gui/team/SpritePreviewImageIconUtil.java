/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import static java.awt.Color.BLACK;
import static java.awt.Color.BLUE;
import static java.awt.Color.GREEN;
import static java.awt.Color.RED;

import java.awt.Color;
import java.awt.Image;
import java.util.List;

import org.twofoos.gmtsb.core.PaletteColor;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.gui.util.ImageIconWithPalette;
import org.twofoos.gmtsb.util.CollectionUtilities;

public class SpritePreviewImageIconUtil
{
  private SpritePreviewImageIconUtil()
  {
  }

  public static final Image SPRITE_PREVIEW_IMAGE_SMALL =
      GUIUtils.createImage("spritesmall.png");
  public static final Image SPRITE_PREVIEW_IMAGE_LARGE =
      GUIUtils.createImage("spritelarge.png");

  public static final Color GRASS_COLOR = new Color(0, 168, 0);

  public static ImageIconWithPalette newSpriteImageIconWithPaletteSmall(
      Team team, int oneOrTwo)
  {
    ImageIconWithPalette image =
        new ImageIconWithPalette(SPRITE_PREVIEW_IMAGE_SMALL);
    updateImagePalette(team, image, oneOrTwo);
    return image;
  }

  public static ImageIconWithPalette newSpriteImageIconWithPaletteLarge(
      Team team, int oneOrTwo)
  {
    ImageIconWithPalette image =
        new ImageIconWithPalette(SPRITE_PREVIEW_IMAGE_LARGE);
    updateImagePalette(team, image, oneOrTwo);
    return image;
  }

  public static void updateImagePalette(Team team, ImageIconWithPalette image,
      int oneOrTwo)
  {
    updateImagePalette(team.getSpriteColors(oneOrTwo), image);
  }

  public static void updateImagePalette(Iterable<PaletteColor> colors,
      ImageIconWithPalette image)
  {
    updateImagePalette(CollectionUtilities.list(colors), image);
  }

  public static void updateImagePalette(List<PaletteColor> colors,
      ImageIconWithPalette image)
  {
    image.putPaletteColor(GREEN, GRASS_COLOR);
    image.putPaletteColor(RED, colors.get(0).getColor());
    image.putPaletteColor(BLUE, colors.get(1).getColor());
    image.putPaletteColor(BLACK, colors.get(2).getColor());
  }
}
