/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent;

public interface UserEvent
{
  /**
   * Returns true if the event had an effect; false otherwise.
   * 
   * @see UserEventAggregator#performAndPublish(UserEvent)
   */
  public boolean doEvent();

  public void undoEvent();

  public String getDescription();

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent);

  // If I set up a system to see if this UserEvent affects a given window (so
  // that I know whether to repaint it), I think that Depth, Division, Player,
  // and Team are the classes whose objects could be classified as being
  // affected.

  // TODO toString() for all UserEvents
}