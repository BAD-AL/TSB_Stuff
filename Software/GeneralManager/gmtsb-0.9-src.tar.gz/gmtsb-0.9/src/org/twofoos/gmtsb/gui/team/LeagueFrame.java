/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import static org.twofoos.gmtsb.core.AFC_NFC_Other.AFC;
import static org.twofoos.gmtsb.core.AFC_NFC_Other.NFC;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.InternalFrame;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.util.ComponentScalar;
import org.twofoos.gmtsb.gui.util.ComponentSizeIncrementScrollPane;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.extrinsic.ExtrinsicEvent;
import org.twofoos.gmtsb.userevent.extrinsic.CreateEvent.CreateTeamEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

// Team delete and view roster buttons
public class LeagueFrame extends InternalFrame implements ActionListener
{
  private static final long serialVersionUID = 1065380953274442839L;

  private static final ComponentScalar scalar = new ComponentScalar(0.8f);

  private final List<ConferencePanel> conferencePanels;
  private final DivisionPanel otherTeamsPanel;
  private final JButton createTeamButton;

  public LeagueFrame(MainFrame mainFrame)
  {
    super(mainFrame, "League Editor");

    conferencePanels = new ArrayList<ConferencePanel>(2);
    conferencePanels.add(new ConferencePanel(this, getLeague().getConference(
        AFC)));
    conferencePanels.add(new ConferencePanel(this, getLeague().getConference(
        NFC)));

    Container contentPane = getContentPane();

    contentPane.setLayout(new BorderLayout());

    JPanel nesPanel = new JPanel();
    nesPanel.setLayout(new BoxLayout(nesPanel, BoxLayout.Y_AXIS));

    for(ConferencePanel conferencePanel : conferencePanels)
    {
      nesPanel.add(conferencePanel);
    }

    contentPane.add(nesPanel, BorderLayout.CENTER);

    otherTeamsPanel =
        new DivisionPanel(mainFrame, getLeague().getExtraDivision());
    ComponentSizeIncrementScrollPane otherTeamsScrollPane =
        new ComponentSizeIncrementScrollPane(otherTeamsPanel,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    otherTeamsScrollPane
        .setPreferredSize(getOtherTeamsDivisionScrollPaneSize());

    // We need another panel so that the border doesn't make the scroll pane
    // wider than the space we allocate for it.
    JPanel otherTeamsScrollPanePlusBorderPanel = new JPanel();
    otherTeamsScrollPanePlusBorderPanel.setLayout(new BorderLayout());
    createTeamButton = new JButton("Create Team");
    createTeamButton.addActionListener(this);
    otherTeamsScrollPanePlusBorderPanel.add(createTeamButton,
        BorderLayout.SOUTH);
    otherTeamsScrollPanePlusBorderPanel.add(otherTeamsScrollPane,
        BorderLayout.CENTER);
    otherTeamsScrollPanePlusBorderPanel.setBorder(BorderFactory
        .createTitledBorder(BorderFactory.createEtchedBorder(), "Other Teams"));

    contentPane.add(otherTeamsScrollPanePlusBorderPanel, BorderLayout.EAST);

    setDefaultCloseOperation(HIDE_ON_CLOSE);

    pack();
  }

  // TODO should probably merge the method that first calculates these
  // This are calculated the first time they are needed.
  private static Dimension DIVISION_SCROLL_PANE_SIZE = null;
  private static Dimension OTHER_TEAMS_DIVISION_SCROLL_PANE_SIZE = null;
  private static Dimension TEAM_PANEL_SIZE = null;

  // This is not a static method because I need an instance in order to create
  // instances of the non-static DivisionPanel and TeamPanel classes.
  // The JScrollPane parameter is included so as to account for any Insets it
  // may have.
  Dimension getDivisionScrollPaneSize()
  {
    if(DIVISION_SCROLL_PANE_SIZE == null)
    {
      DIVISION_SCROLL_PANE_SIZE = calculateDivisionScrollPaneSize(5);
    }

    return DIVISION_SCROLL_PANE_SIZE;
  }

  private Dimension getOtherTeamsDivisionScrollPaneSize()
  {
    if(OTHER_TEAMS_DIVISION_SCROLL_PANE_SIZE == null)
    {
      OTHER_TEAMS_DIVISION_SCROLL_PANE_SIZE =
          calculateDivisionScrollPaneSize(10);
    }

    return OTHER_TEAMS_DIVISION_SCROLL_PANE_SIZE;
  }

  private Dimension calculateDivisionScrollPaneSize(int teams)
  {
    DivisionPanel divisionPanel =
        new DivisionPanel(getMainFrame(), new League().getExtraDivision());
    JScrollPane divisionScrollPane =
        new ComponentSizeIncrementScrollPane(divisionPanel,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    for(int j = 0; j < teams; j++)
    {
      divisionPanel.add(new TeamPanel(divisionPanel, new Team()));
    }

    return divisionScrollPane.getPreferredSize();
  }

  Dimension getTeamPanelSize()
  {
    if(TEAM_PANEL_SIZE == null)
    {
      TEAM_PANEL_SIZE = calculateTeamPanelSize();
    }

    return TEAM_PANEL_SIZE;
  }

  private Dimension calculateTeamPanelSize()
  {
    DivisionPanel divisionPanel =
        new DivisionPanel(getMainFrame(), new League().getExtraDivision());

    TeamPanel teamPanel = new TeamPanel(divisionPanel, new Team());
    divisionPanel.add(teamPanel);

    return teamPanel.getPreferredSize();
  }

  public static <C extends Component> C scaleComponent(C component)
  {
    return scalar.scaleComponent(component);
  }

  @Override
  protected void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    for(ConferencePanel conferencePanel : conferencePanels)
    {
      conferencePanel.intrinsicTeamEventPerformed(event, isUndoRedoEvent);
    }
    otherTeamsPanel.intrinsicTeamEventPerformed(event, isUndoRedoEvent);
  }

  @Override
  protected void intrinsicPlayerEventPerformed(IntrinsicEvent<Player, ?> event,
      boolean isUndoRedoEvent)
  {
    // We don't care.
  }

  @Override
  protected void extrinsicEventPerformed(ExtrinsicEvent event,
      boolean isUndoRedoEvent)
  {
    for(ConferencePanel conferencePanel : conferencePanels)
    {
      conferencePanel.extrinsicEventPerformed(event, isUndoRedoEvent);
    }
    otherTeamsPanel.extrinsicEventPerformed(event, isUndoRedoEvent);
  }

  @Override
  protected void otherEventPerformed(UserEvent event, boolean isUndoRedoEvent)
  {
    // We don't care.
  }

  public void actionPerformed(ActionEvent e)
  {
    CreateTeamEvent createTeamEvent =
        CreateTeamEvent.createCreateTeamEvent(otherTeamsPanel.getDivision());
    performAndPublish(createTeamEvent);
  }
}
