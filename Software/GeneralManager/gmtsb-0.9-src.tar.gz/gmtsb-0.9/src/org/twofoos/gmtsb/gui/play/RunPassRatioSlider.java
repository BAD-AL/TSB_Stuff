/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.play;

import static org.twofoos.gmtsb.userevent.intrinsic.team.RunPassRatioChangeEvent.createRunPassRatioChangeEvent;

import java.awt.Dimension;
import java.util.Hashtable;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.twofoos.gmtsb.core.RunPassRatio;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.userevent.UserEventAggregator;
import org.twofoos.gmtsb.userevent.intrinsic.team.RunPassRatioChangeEvent;

class EnumSlider<E extends Enum<E>> extends JSlider
{
  private static final long serialVersionUID = -7779764257812754158L;

  private final Class<E> enumClass;

  public EnumSlider(E value)
  {
    super(HORIZONTAL, 0, getAllValues(value).length - 1, value.ordinal());

    enumClass = value.getDeclaringClass();

    Hashtable<Integer, JComponent> labelTable = createLabelTable();

    setLabelTable(labelTable);
    setPaintLabels(true);
    setPaintTicks(true);
    setMajorTickSpacing(1);
    setSnapToTicks(true);

    initSizes(labelTable);
  }

  public E getEnumValue()
  {
    return enumClass.getEnumConstants()[getValue()];
  }

  public void setEnumValue(E value)
  {
    setValue(value.ordinal());
  }

  private static final int MARGIN = 5;

  private void initSizes(Hashtable<Integer, JComponent> labelTable)
  {
    int minWidth = 0;
    int preferredWidth = 0;

    for(JComponent component : labelTable.values())
    {
      minWidth += component.getMinimumSize().width + MARGIN;
      preferredWidth += component.getPreferredSize().width + MARGIN;
    }

    Dimension minSize = getMinimumSize();
    Dimension preferredSize = getPreferredSize();

    if(minSize != null && minSize.width < minWidth)
    {
      setMinimumSize(new Dimension(minWidth, minSize.height));
    }
    if(preferredSize != null && preferredSize.width < preferredWidth)
    {
      setPreferredSize(new Dimension(preferredWidth, preferredSize.height));
    }
  }

  private Hashtable<Integer, JComponent> createLabelTable()
  {
    Hashtable<Integer, JComponent> labelTable =
        new Hashtable<Integer, JComponent>();

    for(E value : enumClass.getEnumConstants())
    {
      labelTable.put(value.ordinal(), new JLabel(value.toString()));
    }

    return labelTable;
  }

  private static <E extends Enum<E>> E[] getAllValues(E value)
  {
    return value.getDeclaringClass().getEnumConstants();
  }
}

public class RunPassRatioSlider extends EnumSlider<RunPassRatio> implements
    ChangeListener
{
  private static final long serialVersionUID = -6474885121121263355L;

  private final MainFrame mainFrame;
  private final Team team;

  public RunPassRatioSlider(MainFrame mainFrame, Team team)
  {
    super(team.getRunPassRatio());

    this.mainFrame = mainFrame;
    this.team = team;

    addChangeListener(this);
  }

  public void stateChanged(ChangeEvent e)
  {
    RunPassRatioChangeEvent runPassRatioChangeEvent =
        createRunPassRatioChangeEvent(team, team.getRunPassRatio(),
            getEnumValue(), this);
    getUserEventAggregator().performAndPublish(runPassRatioChangeEvent);
  }

  private UserEventAggregator getUserEventAggregator()
  {
    return mainFrame.getUserEventAggregator();
  }
}
