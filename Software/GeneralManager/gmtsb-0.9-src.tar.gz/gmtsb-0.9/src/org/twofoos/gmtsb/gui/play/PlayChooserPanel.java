/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.play;

import java.awt.Frame;
import java.awt.GridLayout;
import java.util.List;

import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.core.play.Play;
import org.twofoos.gmtsb.gui.chooser.SingleChooserPanel;

public class PlayChooserPanel extends SingleChooserPanel<Play>
{
  private static final long serialVersionUID = 2466732334836964626L;

  // TODO other ChooserPanels should probably also take a "real" class, rather
  // than a String, for use in the title
  public PlayChooserPanel(Frame chooserOwner, List<Play> page,
      Play initialPlay, Team team)
  {
    this(chooserOwner, page, initialPlay, team, team.getFullName());
  }

  private PlayChooserPanel(Frame chooserOwner, List<Play> page,
      Play initialPlay, Team team, String teamName)
  {
    super(chooserOwner, "Play Chooser - " + team.getFullName());

    // Keep all buttons the same size by using GridLayout.
    setLayout(new GridLayout(1, Play.PAGES));

    for(Play play : page)
    {
      PlayRadioButton currentButton = new PlayRadioButton(team, play);
      add(currentButton.getBorderedContainer());

      if(play == initialPlay)
      {
        currentButton.setSelected(true);
      }
    }
  }

  public static Play showDialog(Frame chooserOwner, List<Play> page,
      Play initialPlay, Team team)
  {
    PlayChooserPanel chooserPanel =
        new PlayChooserPanel(chooserOwner, page, initialPlay, team);
    return showDialog(chooserPanel);
  }

  private final class PlayRadioButton extends ChooserRadioButton
  {
    private static final long serialVersionUID = -5544378277916392195L;

    private PlayRadioButton(Team team, Play play)
    {
      super(play);
      add(new PlayGraphics(team, play));
    }
  }
}
