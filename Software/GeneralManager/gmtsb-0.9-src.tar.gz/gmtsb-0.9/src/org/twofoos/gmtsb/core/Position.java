/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Maps.newHashMapWithExpectedSize;
import static org.twofoos.gmtsb.core.Attribute.AB;
import static org.twofoos.gmtsb.core.Attribute.AR;
import static org.twofoos.gmtsb.core.Attribute.BC;
import static org.twofoos.gmtsb.core.Attribute.HP;
import static org.twofoos.gmtsb.core.Attribute.Int;
import static org.twofoos.gmtsb.core.Attribute.KA;
import static org.twofoos.gmtsb.core.Attribute.MS;
import static org.twofoos.gmtsb.core.Attribute.PA;
import static org.twofoos.gmtsb.core.Attribute.PC;
import static org.twofoos.gmtsb.core.Attribute.PS;
import static org.twofoos.gmtsb.core.Attribute.Qui;
import static org.twofoos.gmtsb.core.Attribute.RP;
import static org.twofoos.gmtsb.core.Attribute.RS;
import static org.twofoos.gmtsb.core.Attribute.Rec;
import static org.twofoos.gmtsb.core.AttributeValue._13;
import static org.twofoos.gmtsb.core.AttributeValue._19;
import static org.twofoos.gmtsb.core.AttributeValue._25;
import static org.twofoos.gmtsb.core.AttributeValue._31;
import static org.twofoos.gmtsb.core.AttributeValue._38;
import static org.twofoos.gmtsb.core.AttributeValue._44;
import static org.twofoos.gmtsb.core.AttributeValue._50;
import static org.twofoos.gmtsb.core.AttributeValue._56;
import static org.twofoos.gmtsb.core.AttributeValue._69;
import static org.twofoos.gmtsb.core.AttributeValue._81;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.google.common.collect.ImmutableList;

public enum Position
{
  QB("QB", AttributeList.QB_ATTRIBUTES),

  RB("RB", AttributeList.OFF_ATTRIBUTES), //
  WR("WR", AttributeList.OFF_ATTRIBUTES), //
  TE("TE", AttributeList.OFF_ATTRIBUTES),

  OL("OL", AttributeList.OL_ATTRIBUTES),

  DL("DL", AttributeList.DEF_ATTRIBUTES), //
  LB("LB", AttributeList.DEF_ATTRIBUTES), //
  DB("DB", AttributeList.DEF_ATTRIBUTES),

  K("K", AttributeList.KP_ATTRIBUTES), P("P", AttributeList.KP_ATTRIBUTES);

  private final String abbreviation;
  private final AttributeList attributeList;

  private Position(final String abbreviation, final AttributeList attributeList)
  {
    this.abbreviation = abbreviation;
    this.attributeList = attributeList;
  }

  private static final List<Position> ALL_POSITIONS;
  private static final Map<String, Position> POSITIONS_BY_NAME;

  private static final Map<String, Position> createPositionsByName()
  {
    Map<String, Position> positionsByName =
        newHashMapWithExpectedSize(ALL_POSITIONS.size());
    for(Position currentPosition : ALL_POSITIONS)
    {
      positionsByName.put(currentPosition.abbreviation, currentPosition);
    }
    return positionsByName;
  }

  static
  {
    ALL_POSITIONS = ImmutableList.of(values());

    POSITIONS_BY_NAME = Collections.unmodifiableMap(createPositionsByName());
  }

  public static Position getPositionByName(String positionName)
  {
    return POSITIONS_BY_NAME.get(positionName);
  }

  // TODO probably don't need a vector and a List
  private static final Vector<Position> ALL_POSITIONS_VECTOR =
      new Vector<Position>(ALL_POSITIONS);

  // Use == instead of equals() because I don't think equals() will
  // short-circuit with == with all the indirection (Arrays.asList(),
  // Collections.unmodifiableList()) involved.
  public boolean isCompatibleWith(Position other)
  {
    return this.attributeList == other.attributeList;
  }

  public boolean isCompatibleWith(Player player)
  {
    return this.attributeList == player.attributes();
  }

  public static Iterator<Position> positionsIterator()
  {
    return ALL_POSITIONS.iterator();
  }

  public String getAbbreviation()
  {
    return abbreviation;
  }

  @Override
  public String toString()
  {
    return getAbbreviation();
  }

  public AttributeList getAttributeList()
  {
    return attributeList;
  }

  public int getAttributeCount()
  {
    return attributeList.size();
  }

  public Iterator<Attribute> attributeIterator()
  {
    return attributeList.iterator();
  }

  public static List<Position> allPositions()
  {
    return ALL_POSITIONS;
  }

  /**
   * Don't modify the Vector returned.
   */
  // TODO subclass Vector to make it unmodifiable?
  public static Vector<Position> allPositionsVector()
  {
    return ALL_POSITIONS_VECTOR;
  }

  public Player newPlayer()
  {
    Player player = new Player(this, "FIRST", "LAST", 0);
    switch(this)
    {
      case QB:
        player.setAttribute(RS, _25);
        player.setAttribute(RP, _69);
        player.setAttribute(MS, _13);
        player.setAttribute(HP, _13);
        player.setAttribute(PS, _44);
        player.setAttribute(PC, _38);
        player.setAttribute(PA, _31);
        player.setAttribute(AR, _38);
        break;

      case RB:
        player.setAttribute(RS, _38);
        player.setAttribute(RP, _69);
        player.setAttribute(MS, _38);
        player.setAttribute(HP, _19);
        player.setAttribute(BC, _50);
        player.setAttribute(Rec, _25);
        break;

      case WR:
        player.setAttribute(RS, _38);
        player.setAttribute(RP, _69);
        player.setAttribute(MS, _38);
        player.setAttribute(HP, _13);
        player.setAttribute(BC, _50);
        player.setAttribute(Rec, _44);
        break;

      case TE:
        player.setAttribute(RS, _25);
        player.setAttribute(RP, _69);
        player.setAttribute(MS, _25);
        player.setAttribute(HP, _50);
        player.setAttribute(BC, _50);
        player.setAttribute(Rec, _38);
        break;

      case OL:
        player.setAttribute(RS, _25);
        player.setAttribute(RP, _69);
        player.setAttribute(MS, _31);
        player.setAttribute(HP, _50);
        break;

      case K:
        player.setAttribute(RS, _56);
        player.setAttribute(RP, _81);
        player.setAttribute(MS, _81);
        player.setAttribute(HP, _31);
        player.setAttribute(KA, _50);
        player.setAttribute(AB, _50);
        break;

      case P:
        player.setAttribute(RS, _25);
        player.setAttribute(RP, _69);
        player.setAttribute(MS, _44);
        player.setAttribute(HP, _13);
        player.setAttribute(KA, _38);
        player.setAttribute(AB, _38);
        break;

      case DL:
        player.setAttribute(RS, _25);
        player.setAttribute(RP, _31);
        player.setAttribute(MS, _38);
        player.setAttribute(HP, _50);
        player.setAttribute(Int, _19);
        player.setAttribute(Qui, _56);
        break;

      case LB:
        player.setAttribute(RS, _25);
        player.setAttribute(RP, _31);
        player.setAttribute(MS, _38);
        player.setAttribute(HP, _44);
        player.setAttribute(Int, _19);
        player.setAttribute(Qui, _44);
        break;

      case DB:
        player.setAttribute(RS, _31);
        player.setAttribute(RP, _38);
        player.setAttribute(MS, _50);
        player.setAttribute(HP, _38);
        player.setAttribute(Int, _50);
        player.setAttribute(Qui, _50);
        break;
    }

    return player;
  }
}
