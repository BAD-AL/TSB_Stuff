/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static org.twofoos.gmtsb.util.StreamUtilities.resourceLines;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import com.google.common.collect.ImmutableList;

public class PaletteColor
{
  private static final List<PaletteColor> COLORS;

  static
  {
    Pattern comma = Pattern.compile(",");

    List<PaletteColor> colors = new ArrayList<PaletteColor>();

    for(String line : resourceLines("colors.txt"))
    {
      String[] tokens = comma.split(line);

      String name = tokens[0];
      int red = Integer.parseInt(tokens[1], 16);
      int green = Integer.parseInt(tokens[2], 16);
      int blue = Integer.parseInt(tokens[3], 16);

      colors.add(new PaletteColor(name, new Color(red, green, blue), colors
          .size()));
    }

    COLORS = Collections.unmodifiableList(colors);
  }

  private final String name;
  private final Color color;
  private final int index;

  private PaletteColor(String name, Color color, int index)
  {
    this.name = name;
    this.color = color;
    this.index = index;
  }

  public Color getColor()
  {
    return color;
  }

  public String getName()
  {
    return name;
  }

  public int getIndex()
  {
    return index;
  }

  @Override
  public String toString()
  {
    return getName();
  }

  public static List<PaletteColor> getAllColors()
  {
    return COLORS;
  }

  public static PaletteColor getColor(int index)
  {
    return getAllColors().get(index);
  }

  private static final List<PaletteColor> SKIN_COLORS =
      ImmutableList.of(getColor(0x16), getColor(0x06), getColor(0x0f));

  public static List<PaletteColor> getSkinColors()
  {
    return SKIN_COLORS;
  }

  @Override
  public int hashCode()
  {
    return index;
  }

  @Override
  public boolean equals(Object obj)
  {
    if(!(obj instanceof PaletteColor))
    {
      return false;
    }
    PaletteColor that = (PaletteColor) obj;
    return this.index == that.index;
  }
}
