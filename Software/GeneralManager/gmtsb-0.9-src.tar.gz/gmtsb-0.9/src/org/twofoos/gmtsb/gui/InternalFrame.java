/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui;

import static java.awt.Event.CTRL_MASK;
import static java.awt.Toolkit.getDefaultToolkit;
import static java.awt.event.KeyEvent.VK_TAB;
import static java.awt.event.KeyEvent.VK_W;
import static javax.swing.KeyStroke.getKeyStroke;

import java.awt.event.ActionEvent;
import java.beans.PropertyVetoException;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JInternalFrame;
import javax.swing.KeyStroke;

import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.UserEventAggregator;
import org.twofoos.gmtsb.userevent.UserEventListener;
import org.twofoos.gmtsb.userevent.extrinsic.ExtrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

public abstract class InternalFrame extends JInternalFrame implements
    UserEventListener
{
  private static final KeyStroke CLOSE_FRAME_KEY_STROKE =
      getKeyStroke(VK_W, getDefaultToolkit().getMenuShortcutKeyMask());
  // CTRL no matter what, since Command-Tab is taken.
  private static final KeyStroke SELECT_NEXT_FRAME_KEY_STROKE =
      getKeyStroke(VK_TAB, CTRL_MASK);

  private final MainFrame mainFrame;

  protected InternalFrame(MainFrame mainFrame)
  {
    this(mainFrame, "");
  }

  protected InternalFrame(MainFrame mainFrame, String title)
  {
    // Let the user resize, close, maximize, and iconify to his heart's content.
    super(title, true, true, true, true);
    this.mainFrame = mainFrame;

    getUserEventAggregator().subscribe(this);

    setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    Action closeAction = new AbstractAction()
    {
      private static final long serialVersionUID = 3529512087171993043L;

      public void actionPerformed(ActionEvent e)
      {
        doDefaultCloseAction();
      }
    };

    Action selectNextFrameAction = new AbstractAction()
    {
      private static final long serialVersionUID = -225979489356933975L;

      public void actionPerformed(ActionEvent e)
      {
        InternalFrame.this.mainFrame.selectNextFrame();
      }
    };

    addFrameAction(CLOSE_FRAME_KEY_STROKE, closeAction);
    addFrameAction(SELECT_NEXT_FRAME_KEY_STROKE, selectNextFrameAction);
  }

  private void addFrameAction(KeyStroke keyStroke, Action action)
  {
    getInputMap(WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(keyStroke, action);
    getActionMap().put(action, action);
  }

  @Override
  public void dispose()
  {
    getUserEventAggregator().unsubscribe(this);
    /*
     * TODO make sure I don't need to do anything else here to avoid memory
     * leaks
     */
    super.dispose();
  }

  public void addToMainFrame()
  {
    mainFrame.getDesktopPane().add(this);
    setLocation(mainFrame.nextFrameLocation());

    tryToSelect();
  }

  public void tryToSelect()
  {
    setVisible(true);

    try
    {
      setSelected(true);
    }
    catch(PropertyVetoException e)
    {
    }
  }

  public MainFrame getMainFrame()
  {
    return mainFrame;
  }

  public League getLeague()
  {
    return getMainFrame().getLeague();
  }

  public UserEventAggregator getUserEventAggregator()
  {
    return mainFrame.getUserEventAggregator();
  }

  public void performAndPublish(UserEvent e)
  {
    getUserEventAggregator().performAndPublish(e);
  }

  public void userEventPerformed(UserEvent e, boolean isUndoRedoEvent)
  {
    if(e instanceof IntrinsicEvent)
    {
      intrinsicEventPerformed((IntrinsicEvent<?, ?>) e, isUndoRedoEvent);
    }
    else if(e instanceof ExtrinsicEvent)
    {
      extrinsicEventPerformed((ExtrinsicEvent) e, isUndoRedoEvent);
    }
    else
    {
      otherEventPerformed(e, isUndoRedoEvent);
    }
  }

  @SuppressWarnings("unchecked")
  private void intrinsicEventPerformed(IntrinsicEvent<?, ?> e,
      boolean isUndoRedoEvent)
  {
    TSBTransferableData<?> subject = e.getSubject();
    if(subject instanceof Player)
    {
      intrinsicPlayerEventPerformed((IntrinsicEvent) e, isUndoRedoEvent);
    }
    else if(subject instanceof Team)
    {
      intrinsicTeamEventPerformed((IntrinsicEvent) e, isUndoRedoEvent);
    }
  }

  // TODO now there are so many types that this may no longer be much help
  protected abstract void otherEventPerformed(UserEvent event,
      boolean isUndoRedoEvent);

  protected abstract void extrinsicEventPerformed(ExtrinsicEvent event,
      boolean isUndoRedoEvent);

  protected abstract void intrinsicPlayerEventPerformed(
      IntrinsicEvent<Player, ?> event, boolean isUndoRedoEvent);

  protected abstract void intrinsicTeamEventPerformed(
      IntrinsicEvent<Team, ?> event, boolean isUndoRedoEvent);
}
