/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.intrinsic.team;

import static org.twofoos.gmtsb.util.CollectionUtilities.list;

import java.util.List;

import org.twofoos.gmtsb.core.PaletteColor;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

public class SpriteColorsChangeEvent extends
    IntrinsicEvent<Team, List<PaletteColor>>
{
  private final int oneOrTwo;

  public SpriteColorsChangeEvent(Team subject, int oneOrTwo,
      Iterable<PaletteColor> from, Iterable<PaletteColor> to)
  {
    // Use list() in case the Iterable doesn't have an equals() implementation.
    // We need it to check whether a change was made in doEvent().
    super(subject, list(from), list(to));

    this.oneOrTwo = oneOrTwo;
  }

  @Override
  protected void changeSubjectAttribute(List<PaletteColor> value)
  {
    getSubject().setSpriteColors(oneOrTwo, value);
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }

  private String getPrimaryOrSecondary()
  {
    return oneOrTwo == 1 ? "primary" : "secondary";
  }

  public String getDescription()
  {
    return "Change " + getSubject() + " " + getPrimaryOrSecondary()
        + " sprite colors from " + getFrom() + " to " + getTo();
  }
}
