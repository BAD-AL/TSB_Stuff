/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.gui.dnd.SimpleDragMouseMotionListener;
import org.twofoos.gmtsb.gui.dnd.TSBTransferHandler;
import org.twofoos.gmtsb.gui.player.FaceButton;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.userevent.extrinsic.CopyEvent;
import org.twofoos.gmtsb.userevent.extrinsic.MoveEvent;
import org.twofoos.gmtsb.userevent.extrinsic.SwapEvent;
import org.twofoos.gmtsb.util.iterators.Pair;

// TODO standardize C, D type variables
public abstract class TransferablePanel<D extends TSBTransferableData<D>>
    extends JPanel implements TSBDropReceiver<D>
{
  private static final int DROP_PREVIEW_HALF_THICKNESS = 2;

  private final TSBTransferHandler<? extends TransferablePanel<D>, D> transferHandler;

  protected TransferablePanel(
      TSBTransferHandler<? extends TransferablePanel<D>, D> transferHandler)
  {
    super();

    this.transferHandler = transferHandler;

    setFocusable(true);

    SimpleDragMouseMotionListener mouseMotionListener =
        new SimpleDragMouseMotionListener();
    addMouseMotionListener(mouseMotionListener);
    addMouseListener(mouseMotionListener);
    setCursor(GUIUtils.GRAB_CURSOR);

    transferHandler.registerTransferHandler(this);

    setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
  }

  @SuppressWarnings("unchecked")
  private ListPanel<D> getParentAsListPanel()
  {
    return (ListPanel<D>) getParent();
  }

  private TransferablePanel<?> getPanelBefore()
  {
    return (TransferablePanel<?>) getParentAsListPanel().getComponentBefore(
        this);
  }

  private TransferablePanel<?> getPanelAfter()
  {
    return (TransferablePanel<?>) getParentAsListPanel()
        .getComponentAfter(this);
  }

  public TransferablePanel<?> getSwapTarget(Point point)
  {
    if(getComponentAt(point) instanceof FaceButton)
    {
      return this;
    }

    return null;
  }

  public Pair<TransferablePanel<?>, TransferablePanel<?>> getPanelsToDropBetween(
      Point point)
  {
    if(getComponentAt(point) instanceof FaceButton)
    {
      // A trade/swap, so don't hint that it will be inserted somewhere.
      return new Pair<TransferablePanel<?>, TransferablePanel<?>>(null, null);
    }

    double middle = getSize().getHeight() / 2;
    double y = point.getY();
    if(y > middle)
    {
      // Drop below.
      return new Pair<TransferablePanel<?>, TransferablePanel<?>>(this, this
          .getPanelAfter());
    }
    else
    {
      // Drop above.
      return new Pair<TransferablePanel<?>, TransferablePanel<?>>(this
          .getPanelBefore(), this);
    }
  }

  // TODO reduce visibility to package when FaceButton and LogoButton have a
  // common superclass?
  public boolean isSwapTarget()
  {
    return transferHandler.isSwapTarget(this);
  }

  @Override
  public void paint(Graphics g)
  {
    super.paint(g);

    Graphics2D g2d = (Graphics2D) g;
    // g2d.setPaint(SystemColor.textHighlight);
    // TODO find workable system-specific
    g2d.setPaint(new Color(163, 184, 204));

    if(transferHandler.isPanelToDropAbove(this))
    {
      g2d.fillRect(0, 0, getWidth(), DROP_PREVIEW_HALF_THICKNESS);
    }
    else if(transferHandler.isPanelToDropBelow(this))
    {
      g2d.fillRect(0, getHeight() - 1 - DROP_PREVIEW_HALF_THICKNESS,
          getWidth(), DROP_PREVIEW_HALF_THICKNESS);
    }
  }

  // TODO clean up
  public SwapEvent<D> createSwapEvent(List<D> fromList, D data)
  {
    return SwapEvent.createSwapEvent(fromList, data, getList(), getData());
  }

  public Pair<CopyEvent<D>, MoveEvent<D>> createCopyAndMoveEvents(
      List<D> fromList, D data)
  {
    CopyEvent<D> copyEvent;
    MoveEvent<D> moveEvent;

    List<D> toList = getList();
    D toData = getData();

    if(transferHandler.isSwapTarget(this))
    {
      return null;
    }
    else if(transferHandler.isPanelToDropAbove(this))
    {
      copyEvent =
          CopyEvent.createCopyToBeforeEvent(fromList, toList, data, toData);
      moveEvent =
          MoveEvent.createMoveToBeforeEvent(fromList, toList, data, toData);
    }
    else
    {
      copyEvent =
          CopyEvent.createCopyToAfterEvent(fromList, toList, data, toData);
      moveEvent =
          MoveEvent.createMoveToAfterEvent(fromList, toList, data, toData);
    }

    return new Pair<CopyEvent<D>, MoveEvent<D>>(copyEvent, moveEvent);
  }

  public abstract D getData();

  public abstract List<D> getList();
}
