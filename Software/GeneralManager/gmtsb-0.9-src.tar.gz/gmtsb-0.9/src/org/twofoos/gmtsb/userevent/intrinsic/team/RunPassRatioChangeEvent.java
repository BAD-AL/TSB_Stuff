/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.intrinsic.team;

import org.twofoos.gmtsb.core.RunPassRatio;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.MergeableIntrinsicEvent;

public class RunPassRatioChangeEvent extends
    MergeableIntrinsicEvent<RunPassRatioChangeEvent, Team, RunPassRatio>
{
  private RunPassRatioChangeEvent(Team subject, RunPassRatio from,
      RunPassRatio to, Object source)
  {
    super(subject, from, to, source);
  }

  @Override
  protected void changeSubjectAttribute(RunPassRatio value)
  {
    getSubject().setRunPassRatio(value);
  }

  @Override
  protected UserEvent newEventForMerge(RunPassRatio from, RunPassRatio to)
  {
    return new RunPassRatioChangeEvent(getSubject(), from, to, getSource());
  }

  public String getDescription()
  {
    return String.format("Change %s play-calling ratio from %s to %s",
        getSubject(), getFrom(), getTo());
  }

  /*
   * Not using a public constructor only to be consistent with PlayerMoveEvent.
   */
  public static RunPassRatioChangeEvent createRunPassRatioChangeEvent(
      Team subject, RunPassRatio from, RunPassRatio to, Object source)
  {
    return new RunPassRatioChangeEvent(subject, from, to, source);
  }
}
