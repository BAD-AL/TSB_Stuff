/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.play;

import javax.swing.ImageIcon;

import org.twofoos.gmtsb.gui.util.GUIUtils;

public class Tiles
{
  private static final ImageIcon[] TILES;
  public static final int TILE_COUNT = 256;

  static
  {
    TILES = new ImageIcon[TILE_COUNT];
    for(int i = 0; i < TILE_COUNT; i++)
    {
      TILES[i] = GUIUtils.createImageIcon("tiles/tile_" + i + ".png");
    }
  }

  private Tiles()
  {
  }

  public static ImageIcon getImageIcon(int tileIndex)
  {
    return TILES[tileIndex];
  }
}
