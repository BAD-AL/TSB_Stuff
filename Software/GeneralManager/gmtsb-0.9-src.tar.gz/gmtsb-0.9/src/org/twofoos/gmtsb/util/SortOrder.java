/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.util;

import static com.google.common.collect.Comparators.naturalOrder;
import static com.google.common.collect.Iterables.reverse;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Maps.newLinkedHashMap;
import static org.twofoos.gmtsb.util.CollectionUtilities.getLast;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Ordering;

/*
 * I don't expect to use anything other than <Integer, Integer>, but <R, C>
 * helps me to distinguish row and column indexes.
 */
public final class SortOrder<R, C>
{
  private final LinkedHashMap<C, Direction> sortKeys = newLinkedHashMap();

  public static <R, C> SortOrder<R, C> create()
  {
    return new SortOrder<R, C>();
  }

  public Direction sorted(C key)
  {
    if(sortKeys.isEmpty())
    {
      Direction direction = Direction.DEFAULT;
      sortKeys.put(key, direction);
      return direction;
    }

    if(getLast(sortKeys.keySet()).equals(key))
    {
      Direction direction = sortKeys.get(key).invert();
      sortKeys.put(key, direction);
      return direction;
    }

    /*
     * Re-inserting an existing key does not change its position in iteration,
     * so we remove it first.
     */
    sortKeys.remove(key);
    Direction direction = Direction.DEFAULT;
    sortKeys.put(key, direction);
    return direction;
  }

  public <V extends Comparable<? super V>> Ordering<R> getRowIdComparator(
      final Table<? super R, ? super C, V> table)
  {
    return new Ordering<R>()
    {
      private static final long serialVersionUID = -5115413761752125195L;

      public int compare(R r1, R r2)
      {
        /*
         * The map is ordered from least recently clicked to most recent; we
         * want the opposite.
         */
        Iterable<Map.Entry<C, Direction>> sortKeys =
            reverse(newArrayList(SortOrder.this.sortKeys.entrySet()));

        for(Map.Entry<C, Direction> keyAndDirection : sortKeys)
        {
          C key = keyAndDirection.getKey();
          Direction direction = keyAndDirection.getValue();

          V o1 = table.get(r1, key);
          V o2 = table.get(r2, key);

          int cmp = direction.getComparator().compare(o1, o2);
          if(cmp != 0)
          {
            return cmp;
          }
        }

        return 0;
      }
    };
  }

  public <V extends Comparable<? super V>, T extends R> void sort(
      List<T> rowIds, Table<? super R, ? super C, V> table)
  {
    getRowIdComparator(table).sort(rowIds);
  }

  public static interface Table<R, C, V>
  {
    public V get(R rowId, C columnId);
  }

  public static enum Direction
  {
    ASCENDING(naturalOrder()), DESCENDING(naturalOrder().reverseOrder());

    private static final Direction DEFAULT = ASCENDING;

    @SuppressWarnings("unchecked")
    private final Comparator<Comparable> comparator;

    @SuppressWarnings("unchecked")
    private Direction(Comparator<Comparable> comparator)
    {
      this.comparator = comparator;
    }

    @SuppressWarnings("unchecked")
    private Comparator<Comparable> getComparator()
    {
      return comparator;
    }

    private Direction invert()
    {
      return this == ASCENDING ? DESCENDING : ASCENDING;
    }
  };

  private SortOrder()
  {
  }
}
