/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.util;

import static java.lang.Math.min;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

public class CollectionUtilities
{
  private CollectionUtilities()
  {
  }

  public static void swap(Object[] a1, int i1, Object[] a2, int i2)
  {
    Object temp = a1[i1];
    a1[i1] = a2[i2];
    a2[i2] = temp;
  }

  public static void swap(Object[] a, int i1, int i2)
  {
    swap(a, i1, a, i2);
  }

  public static <T> void swap(List<T> a1, int i1, List<T> a2, int i2)
  {
    T temp = a1.get(i1);
    a1.set(i1, a2.get(i2));
    a2.set(i2, temp);
  }

  public static <T> void swap(List<T> a, int i1, int i2)
  {
    swap(a, i1, a, i2);
  }

  public static <T> void swap(T[] a1, int i1, List<T> a2, int i2)
  {
    T temp = a1[i1];
    a1[i1] = a2.get(i2);
    a2.set(i2, temp);
  }

  public static <T> void drain(Iterator<? extends T> from, Collection<T> into,
      int count)
  {
    for(int i = 0; i < count; i++)
    {
      into.add(from.next());
    }
  }

  public static <T> T removeLast(List<T> collection)
  {
    return collection.remove(collection.size() - 1);
  }

  public static <T> T getLast(Iterable<T> iterable)
  {
    if(iterable instanceof List)
    {
      List<T> list = (List<T>) iterable;
      return list.get(list.size() - 1);
    }

    for(Iterator<T> iterator = iterable.iterator();;)
    {
      T current = iterator.next();
      if(!iterator.hasNext())
      {
        return current;
      }
    }
  }

  public static <T> List<T> list(Iterable<T> iterable)
  {
    return Lists.newArrayList(iterable);
  }

  public static <T> List<T> removeFirstN(List<T> original, int n)
  {
    List<T> sublistToClear = original.subList(0, n);
    List<T> copiedSublist = new ArrayList<T>(sublistToClear);
    sublistToClear.clear();

    return copiedSublist;
  }

  public static int getDifferenceIndex(List<?> listA, List<?> listB)
  {
    int i;
    for(i = 0; i < min(listA.size(), listB.size()); i++)
    {
      Object a = listA.get(i);
      Object b = listB.get(i);
      if(!a.equals(b))
      {
        return i;
      }
    }
    return i;
  }

  public static <T> Iterable<T> concat(Iterable<? extends T> a,
      Iterable<? extends T> b, Iterable<? extends T> c)
  {
    List<Iterable<? extends T>> iterables =
        new ArrayList<Iterable<? extends T>>(3);
    iterables.add(a);
    iterables.add(b);
    iterables.add(c);
    return Iterables.concat(iterables);
  }
}
