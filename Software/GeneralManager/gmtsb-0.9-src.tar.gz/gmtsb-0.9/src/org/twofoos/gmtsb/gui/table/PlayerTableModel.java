/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.table;

import static java.awt.Cursor.HAND_CURSOR;
import static java.awt.Cursor.getPredefinedCursor;
import static java.util.Collections.synchronizedList;
import static org.twofoos.gmtsb.util.CollectionUtilities.list;
import static org.twofoos.gmtsb.util.iterators.Pair.pairIterable;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.AttributeValue;
import org.twofoos.gmtsb.core.Depth;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.util.RowKeyedTable;
import org.twofoos.gmtsb.gui.util.RowKeyedTableModel;
import org.twofoos.gmtsb.util.iterators.Pair;

public class PlayerTableModel extends AbstractTableModel implements
    RowKeyedTableModel<Player>
{
  private static final long serialVersionUID = -5580778470106621833L;

  private final League league;
  private final MainFrame mainFrame;

  private Position position;
  private List<Player> players;

  private List<TsbColumn<?>> tsbColumns;

  public PlayerTableModel(League league, Position position, MainFrame mainFrame)
  {
    this.league = league;
    this.position = position;
    this.mainFrame = mainFrame;

    updateFromData();
  }

  void playerIntrinsicUpdate(Player player)
  {
    int index = players.indexOf(player);
    if(index > -1)
    {
      fireTableRowsUpdated(index, index);
    }
  }

  void possibleRowStructureChange()
  {
    players = synchronizedList(list(league.getAllPlayersAtPosition(position)));
    fireTableDataChanged();
  }

  private synchronized void updateFromData()
  {
    List<TsbColumn<?>> columns = new ArrayList<TsbColumn<?>>();
    columns.add(new LastNameColumn());
    columns.add(new FirstNameColumn());
    for(Attribute attribute : position.getAttributeList()
        .displayOrderAttributes())
    {
      columns.add(new AttributeColumn(attribute));
    }
    columns.add(new ShowTeamColumn());
    this.tsbColumns = synchronizedList(columns);

    players = synchronizedList(list(league.getAllPlayersAtPosition(position)));

    fireTableStructureChanged();
    fireTableDataChanged();
  }

  Position getPosition()
  {
    return position;
  }

  // TODO left-align column headers
  private void initColumnModel(TableColumnModel columnModel)
  {
    for(Pair<TsbColumn<?>, TableColumn> columnAndTableColumn : pairIterable(
        tsbColumns, columnList(columnModel)))
    {
      TsbColumn<?> tsbColumn = columnAndTableColumn.getFirst();
      TableColumn tableColumn = columnAndTableColumn.getSecond();

      tsbColumn.initColumn(tableColumn);
    }
  }

  void initTable(final RowKeyedTable<Player> table)
  {
    initColumnModel(table.getColumnModel());

    /*
     * MouseAdapter does not implement MouseMotionListener until 1.6. I could
     * still extend it to save myself the trouble of dummy implementations of a
     * few methods, but then there's the question of whether to put @Override on
     * mouseDragged(), etc. Eclipse will issue a warning telling me to add it
     * for Java 1.6 but will issue an error for Java 1.5 if I do.
     */
    class MyMouseListener implements MouseListener, MouseMotionListener
    {
      public void mouseDragged(MouseEvent e)
      {
        mouseEvent(e);
      }

      public void mouseMoved(MouseEvent e)
      {
        mouseEvent(e);
      }

      private int getModelColumnAtPoint(Point point)
      {
        return table.convertColumnIndexToModel(table.columnAtPoint(point));
      }

      private int getModelRowAtPoint(Point point)
      {
        // Do NOT call table.convertRowIndexToModel(), a 1.6-only method.
        return table.rowAtPoint(point);
      }

      // TODO users should be able to activate this with the keyboard
      public void mouseClicked(MouseEvent e)
      {
        int colIndex = getModelColumnAtPoint(e.getPoint());
        int rowIndex = getModelRowAtPoint(e.getPoint());
        if(colIndex > -1 && rowIndex > -1)
        {
          TsbColumn<?> column = tsbColumns.get(colIndex);
          column.actionPerformed(table.getModel().getRowKey(rowIndex));
        }
      }

      private void mouseEvent(MouseEvent e)
      {
        int colIndex = getModelColumnAtPoint(e.getPoint());
        if(colIndex > -1)
        {
          TsbColumn<?> column = tsbColumns.get(colIndex);
          table.setCursor(column.getCursor());
        }
      }

      public void mouseEntered(MouseEvent e)
      {
      }

      public void mouseExited(MouseEvent e)
      {
      }

      public void mousePressed(MouseEvent e)
      {
      }

      public void mouseReleased(MouseEvent e)
      {
      }
    }

    MyMouseListener mouseListener = new MyMouseListener();
    table.addMouseMotionListener(mouseListener);
    table.addMouseListener(mouseListener);
  }

  private static enum ShrinkOrExpand
  {
    SHRINK(), EXPAND();

    private void doSizing(TableColumn tableColumn)
    {
      switch(this)
      {
        case SHRINK:
          tableColumn.setPreferredWidth(tableColumn.getMinWidth());
        case EXPAND:
          tableColumn.setMinWidth(tableColumn.getPreferredWidth());
      }
    }
  }

  // TODO make top-level class?
  private static List<TableColumn> columnList(TableColumnModel model)
  {
    return new TableColumnList(model);
  }

  private static class TableColumnList extends AbstractList<TableColumn>
  {
    private final TableColumnModel model;

    private TableColumnList(TableColumnModel model)
    {
      this.model = model;
    }

    @Override
    public TableColumn get(int index)
    {
      return model.getColumn(index);
    }

    @Override
    public int size()
    {
      return model.getColumnCount();
    }
  }

  public synchronized int getColumnCount()
  {
    return tsbColumns.size();
  }

  public synchronized int getRowCount()
  {
    return players.size();
  }

  public synchronized Object getValueAt(int rowIndex, int columnIndex)
  {
    return tsbColumns.get(columnIndex).getColumnValue(rowIndex);
  }

  @Override
  public Class<?> getColumnClass(int columnIndex)
  {
    return tsbColumns.get(columnIndex).getColumnClass();
  }

  @Override
  public String getColumnName(int column)
  {
    return tsbColumns.get(column).getColumnName();
  }

  private abstract class TsbColumn<T>
  {
    private final Class<T> clazz;
    private final ShrinkOrExpand shrinkOrExpand;
    private final TableCellRenderer cellRenderer;
    private final Cursor cursor;

    protected TsbColumn(Class<T> clazz, ShrinkOrExpand shrinkOrExpand,
        TableCellRenderer cellRenderer, Cursor cursor)
    {
      this.clazz = clazz;
      this.shrinkOrExpand = shrinkOrExpand;
      this.cellRenderer = cellRenderer;
      this.cursor = cursor;
    }

    protected void actionPerformed(Player player)
    {
    }

    // So named to avoid conflict with Object.getClass().
    private Class<T> getColumnClass()
    {
      return clazz;
    }

    protected abstract String getColumnName();

    private final T getColumnValue(int row)
    {
      return getColumnValue(players.get(row));
    }

    protected abstract T getColumnValue(Player player);

    private void initColumn(TableColumn tableColumn)
    {
      shrinkOrExpand.doSizing(tableColumn);

      tableColumn.setCellRenderer(cellRenderer);
    }

    private final Cursor getCursor()
    {
      return cursor;
    }
  }

  private static final TableCellRenderer NAME_RENDERER =
      createRenderer(JLabel.LEADING);

  private static final TableCellRenderer ATTRIBUTE_RENDERER =
      createRenderer(JLabel.RIGHT);

  private static final TableCellRenderer SHOW_TEAM_RENDERER =
      createRenderer(JLabel.CENTER);

  private static TableCellRenderer createRenderer(int alignment)
  {
    DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
    renderer.setHorizontalAlignment(alignment);
    return renderer;
  }

  private class FirstNameColumn extends TsbColumn<String>
  {
    private FirstNameColumn()
    {
      super(String.class, ShrinkOrExpand.EXPAND, NAME_RENDERER, null);
    }

    @Override
    protected String getColumnName()
    {
      return "First";
    }

    @Override
    protected String getColumnValue(Player player)
    {
      return player.getFirst();
    }
  }

  private class LastNameColumn extends TsbColumn<String>
  {
    private LastNameColumn()
    {
      super(String.class, ShrinkOrExpand.EXPAND, NAME_RENDERER, null);
    }

    @Override
    protected String getColumnName()
    {
      return "Last";
    }

    @Override
    protected String getColumnValue(Player player)
    {
      return player.getLast();
    }
  }

  private class AttributeColumn extends TsbColumn<AttributeValue>
  {
    private final Attribute attribute;

    private AttributeColumn(Attribute attribute)
    {
      super(AttributeValue.class, ShrinkOrExpand.SHRINK, ATTRIBUTE_RENDERER,
          null);

      this.attribute = attribute;
    }

    @Override
    protected String getColumnName()
    {
      return attribute.getAbbreviation();
    }

    @Override
    protected AttributeValue getColumnValue(Player player)
    {
      return player.getAttribute(attribute);
    }
  }

  private class ShowTeamColumn extends TsbColumn<String>
  {
    private ShowTeamColumn()
    {
      super(String.class, ShrinkOrExpand.EXPAND, SHOW_TEAM_RENDERER,
          getPredefinedCursor(HAND_CURSOR));
    }

    @Override
    protected String getColumnName()
    {
      return "Jump to team";
    }

    @Override
    protected String getColumnValue(Player player)
    {
      return "<html><a href=\"\">Show player</a>";
    }

    @Override
    protected void actionPerformed(Player player)
    {
      Depth depth = league.findPlayer(position, player);
      mainFrame.showTeamFrame(depth);
    }
  }

  public Player getRowKey(int rowIndex)
  {
    return players.get(rowIndex);
  }
}
