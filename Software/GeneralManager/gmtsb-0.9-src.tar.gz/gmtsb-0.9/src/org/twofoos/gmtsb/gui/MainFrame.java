/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui;

import static com.google.common.collect.Sets.newHashSet;
import static java.awt.Event.CTRL_MASK;
import static java.awt.event.KeyEvent.VK_TAB;
import static java.util.Collections.synchronizedList;
import static java.util.Collections.unmodifiableSet;
import static java.util.regex.Pattern.CASE_INSENSITIVE;
import static java.util.regex.Pattern.compile;
import static java.util.regex.Pattern.quote;
import static javax.swing.BorderFactory.createEtchedBorder;
import static javax.swing.BorderFactory.createTitledBorder;
import static javax.swing.JFileChooser.APPROVE_OPTION;
import static javax.swing.JOptionPane.CANCEL_OPTION;
import static javax.swing.JOptionPane.ERROR_MESSAGE;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import static javax.swing.JOptionPane.NO_OPTION;
import static javax.swing.JOptionPane.WARNING_MESSAGE;
import static javax.swing.JOptionPane.YES_NO_CANCEL_OPTION;
import static javax.swing.JOptionPane.YES_OPTION;
import static javax.swing.JOptionPane.showConfirmDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.KeyStroke.getKeyStroke;
import static org.twofoos.gmtsb.gui.util.MacApplication.formatMainWindowBrushMetalRounded;
import static org.twofoos.gmtsb.util.StringUtilities.replaceAll;

import java.awt.AWTKeyStroke;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.KeyboardFocusManager;
import java.awt.Point;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;

import org.twofoos.gmtsb.core.Depth;
import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Notable;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.file.NesFileFormatException;
import org.twofoos.gmtsb.file.SupplementFileFormatException;
import org.twofoos.gmtsb.file.SupplementedNesFile;
import org.twofoos.gmtsb.gui.dnd.TSBTransferHandler;
import org.twofoos.gmtsb.gui.player.PlayerPanel;
import org.twofoos.gmtsb.gui.player.TeamFrame;
import org.twofoos.gmtsb.gui.table.TableFrame;
import org.twofoos.gmtsb.gui.team.LeagueFrame;
import org.twofoos.gmtsb.gui.team.TeamPanel;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.gui.util.MacApplication;
import org.twofoos.gmtsb.gui.util.RegexFileFilter;
import org.twofoos.gmtsb.userevent.UndoHandler;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.UserEventAggregator;
import org.twofoos.gmtsb.userevent.UserEventListener;

import com.google.common.collect.ImmutableList;

public class MainFrame extends JFrame implements UserEventListener,
    MacApplication.Listener
{
  private static final ImmutableList<Integer> ALL_TRAVERSAL_KEY_SETS =
      ImmutableList.of(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,
          KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,
          KeyboardFocusManager.UP_CYCLE_TRAVERSAL_KEYS,
          KeyboardFocusManager.DOWN_CYCLE_TRAVERSAL_KEYS);

  private static final long serialVersionUID = 2833517924640205563L;

  private final MainMenuBar menuBar;
  private final JDesktopPane desktopPane;

  private final League league;
  private final SupplementedNesFile supplementedNesFile;

  private int frameCount = 0;

  private static final int X_OFFSET = 30;
  private static final int Y_OFFSET = 30;

  public static final String APPLICATION_NAME = "General Manager for TSB";
  private static final String BASE_WINDOW_TITLE = APPLICATION_NAME;
  private static final String DIRTY_WINDOW_TITLE = "*" + BASE_WINDOW_TITLE;

  private LeagueFrame leagueFrame = null;
  private final Object leagueFrameLock = new Object();

  private final List<TeamFrame> teamFrames =
      synchronizedList(new ArrayList<TeamFrame>());

  private final TSBTransferHandler<PlayerPanel, Player> playerTransferHandler =
      new TSBTransferHandler<PlayerPanel, Player>(PlayerPanel.class,
          Player.class, this);
  private final TSBTransferHandler<TeamPanel, Team> teamTransferHandler =
      new TSBTransferHandler<TeamPanel, Team>(TeamPanel.class, Team.class, this);

  private final UserEventAggregator userEventAggregator =
      new UserEventAggregator();

  private final UndoHandler undoHandler;

  private final Object notesFramesLock = new Object();
  private final Map<Notable, NotesFrame<?>> notesFrames =
      new HashMap<Notable, NotesFrame<?>>();

  // TODO maybe move some of this save/load/exit-prompt logic to its own class?
  private boolean promptIfDirty()
  {
    if(!isDirty())
    {
      return true;
    }

    // TODO include league information in message
    switch(showConfirmDialog(this, "Save changes to league?", "Save changes?",
        YES_NO_CANCEL_OPTION, WARNING_MESSAGE))
    {
      case YES_OPTION:
        if(promptForSave())
        {
          return true;
        }
        return false;

      case NO_OPTION:
        return true;

      case CANCEL_OPTION:
        // Necessary in case anyone closes the window without selecting an
        // option.
      default:
        return false;
    }
  }

  public boolean promptForSave()
  {
    if(supplementedNesFile.hasNoSupplementFile())
    {
      JFileChooser tsbsupFileChooser = new JFileChooser();
      tsbsupFileChooser.setFileFilter(TSBSUP_FILE_FILTER);
      tsbsupFileChooser
          .setAccessory(createAccessory(SAVE_TSBSUP_ACCESSORY_TEXT));
      tsbsupFileChooser.setSelectedFile(guessSupplementFile(supplementedNesFile
          .getNESFile()));
      // TODO prompt if the user chooses to overwrite a supplement file?
      if(tsbsupFileChooser.showSaveDialog(this) != APPROVE_OPTION)
      {
        return false;
      }

      supplementedNesFile
          .setSupplementFile(tsbsupFileChooser.getSelectedFile());
    }

    return save();
  }

  public void promptForExit()
  {
    if(promptIfDirty())
    {
      System.exit(0);
    }
  }

  private MainFrame(SupplementedNesFile supplementedNesFile)
    throws IOException, NesFileFormatException, SupplementFileFormatException
  {
    // TODO include league information in title
    super(BASE_WINDOW_TITLE);

    this.league = supplementedNesFile.readLeague();
    this.supplementedNesFile = supplementedNesFile;

    GUIUtils.setBoundsToMaximum(this);

    setIconImage(GUIUtils.createImage("programicon.png"));

    undoHandler = new UndoHandler(userEventAggregator);
    userEventAggregator.subscribe(undoHandler);

    desktopPane = new JDesktopPane();
    setContentPane(desktopPane);

    // Need to create menu bar after undo handler because it checks undo status.
    menuBar = new MainMenuBar(this);
    setJMenuBar(menuBar);
    // Need to subscribe the menu bar after the undo handler so that when the
    // undo and redo menu items check the undo status, it has already been
    // updated.
    userEventAggregator.subscribe(menuBar);
    // Similarly for this, since we update the title bar to indicate whether the
    // file has been saved since the last change.
    userEventAggregator.subscribe(this);

    formatMainWindowBrushMetalRounded(desktopPane);

    for(Integer keySetId : ALL_TRAVERSAL_KEY_SETS)
    {
      Set<AWTKeyStroke> keys = newHashSet(getFocusTraversalKeys(keySetId));
      keys.remove(getKeyStroke(VK_TAB, CTRL_MASK));
      setFocusTraversalKeys(keySetId, unmodifiableSet(keys));
    }

    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    addWindowListener(new WindowAdapter()
    {
      @Override
      public void windowClosing(WindowEvent e)
      {
        promptForExit();
      }
    });
  }

  public void showLeagueFrame()
  {
    synchronized(leagueFrameLock)
    {
      if(leagueFrameAdded)
      {
        getLeagueFrame().tryToSelect();
      }
      else
      {
        getLeagueFrame().addToMainFrame();
        leagueFrameAdded = true;
      }
    }
  }

  private boolean leagueFrameAdded = false;

  public LeagueFrame getLeagueFrame()
  {
    synchronized(leagueFrameLock)
    {
      if(leagueFrame == null)
      {
        leagueFrame = new LeagueFrame(this);
      }
    }

    return leagueFrame;
  }

  public Point nextFrameLocation()
  {
    // TODO do this better, based on the size of the window
    Point p =
        new Point(X_OFFSET * (frameCount % 10), Y_OFFSET * (frameCount % 10));
    frameCount++;
    return p;
  }

  /*
   * TODO create one of these in the background and keep it around for when the
   * user wants it? If so, need to set it to the right team when creating. Also,
   * keep in mind that even before it is visible, it may need to respond to
   * events like the deletion of a team
   */
  private TeamFrame createTeamFrame(Team team)
  {
    return new TeamFrame(this, team);
  }

  private TeamFrame createTeamFrame(Depth depth)
  {
    return new TeamFrame(this, depth.getTeam(), depth.getPosition());
  }

  public void showTeamFrame(Team team)
  {
    createTeamFrame(team).addToMainFrame();
  }

  public void showTeamFrame(Depth depth)
  {
    createTeamFrame(depth).addToMainFrame();
  }

  public void showTeamFrame()
  {
    if(league.getTeamCount() == 0)
    {
      showMessageDialog(this, "Cannot show team frame because no teams exist.",
          "Cannot show team frame", WARNING_MESSAGE);
      return;
    }

    createTeamFrame(league.teams().iterator().next()).addToMainFrame();
  }

  public void showTableFrame()
  {
    new TableFrame(this).addToMainFrame();
  }

  public <D extends TSBTransferableData<D> & Notable> void showNotesFrame(
      D notable)
  {
    // TODO perhaps have a list of notes frames like the team-frames list
    synchronized(notesFramesLock)
    {
      NotesFrame<?> notesFrame = notesFrames.get(notable);
      if(notesFrame == null)
      {
        notesFrame = new NotesFrame<D>(this, notable);
        notesFrames.put(notable, notesFrame);
        notesFrame.addToMainFrame();
      }
      else
      {
        notesFrame.tryToSelect();
      }
    }
  }

  public void removeNotesFrame(Notable notable)
  {
    synchronized(notesFramesLock)
    {
      notesFrames.remove(notable);
    }
  }

  public void selectNextFrame()
  {
    int count = getDesktopPane().getComponentCount();
    if(count == 0)
    {
      return;
    }
    for(int i = count - 1; i >= 0; i--)
    {
      JInternalFrame newFront =
          (JInternalFrame) getDesktopPane().getComponent(i);
      // TODO see if this check is necessary
      if(newFront.isVisible())
      {
        tryToSelect(newFront);
        break;
      }
    }
  }

  private static void tryToSelect(JInternalFrame internalFrame)
  {
    try
    {
      internalFrame.setSelected(true);
    }
    catch(PropertyVetoException e)
    {
      System.err.println("Could not select window: " + e);
    }
  }

  public JDesktopPane getDesktopPane()
  {
    return desktopPane;
  }

  public List<TeamFrame> getTeamFrames()
  {
    return teamFrames;
  }

  public League getLeague()
  {
    return league;
  }

  public void promptForOpen()
  {
    if(promptIfDirty())
    {
      openAnother();
    }
  }

  private static final Pattern createExtensionPattern(String extension)
  {
    return compile(quote("." + extension) + "$", CASE_INSENSITIVE);
  }

  private static final String NES_FILE_EXTENSION = "nes";
  private static final String SUPPLEMENT_FILE_EXTENSION = "tsbsup";
  private static final String SUPPLEMENT_FILE_EXTENSION_WITH_DOT =
      "." + SUPPLEMENT_FILE_EXTENSION;

  private static final Pattern NES_FILE_EXTENSION_PATTERN =
      createExtensionPattern(NES_FILE_EXTENSION);
  private static final Pattern SUPPLEMENT_FILE_EXTENSION_PATTERN =
      createExtensionPattern(SUPPLEMENT_FILE_EXTENSION);

  private static final FileFilter NES_FILE_FILTER =
      new RegexFileFilter(NES_FILE_EXTENSION_PATTERN, "NES ROM Files");
  private static final FileFilter TSBSUP_FILE_FILTER =
      new RegexFileFilter(SUPPLEMENT_FILE_EXTENSION_PATTERN, "Supplement Files");

  private static final String OPEN_NES_ROM_DIALOG_TITLE =
      BASE_WINDOW_TITLE + " - Open NES ROM";
  private static final String OPEN_TSBSUP_DIALOG_TITLE =
      BASE_WINDOW_TITLE + " - Open Supplement File (OPTIONAL)";
  private static final String OPEN_TSBSUP_ACCESSORY_TEXT =
      "Supplement files are optional.  If you have not used "
          + BASE_WINDOW_TITLE
          + " before, then you probably do not have one.  Simply press Cancel to open the NES ROM without any supplement file.";
  private static final String SAVE_TSBSUP_ACCESSORY_TEXT =
      "A supplement file allows you to store players and teams beyond the maximum number that fit in the NES ROM.  You must save a supplement file; if you cancel, your changes to the ROM will not be saved.";

  private static JComponent createAccessory(String text)
  {
    // TODO JTextPane might be better
    JTextArea tsbsupInfoArea = new JTextArea(text, 10, 20);
    tsbsupInfoArea.setEditable(false);
    tsbsupInfoArea.setLineWrap(true);
    tsbsupInfoArea.setWrapStyleWord(true);
    tsbsupInfoArea.setOpaque(false);
    tsbsupInfoArea.setBorder(createTitledBorder(createEtchedBorder(), "Note"));
    return tsbsupInfoArea;
  }

  private static File guessSupplementFile(File nesFile)
  {
    return new File(replaceAll(NES_FILE_EXTENSION_PATTERN, nesFile
        .getAbsolutePath(), SUPPLEMENT_FILE_EXTENSION_WITH_DOT));
  }

  private static boolean openGivenParentWindow(Component parent)
  {
    JFileChooser nesFileChooser = new JFileChooser();
    nesFileChooser.setDialogTitle(OPEN_NES_ROM_DIALOG_TITLE);
    nesFileChooser.setFileFilter(NES_FILE_FILTER);

    if(nesFileChooser.showOpenDialog(parent) != APPROVE_OPTION)
    {
      return false;
    }

    File nesFile = nesFileChooser.getSelectedFile();
    File tsbsupFile = null;

    File assumedTsbsupFile = guessSupplementFile(nesFile);

    JFileChooser tsbsupFileChooser = new JFileChooser();
    tsbsupFileChooser.setDialogTitle(OPEN_TSBSUP_DIALOG_TITLE);
    tsbsupFileChooser.setFileFilter(TSBSUP_FILE_FILTER);
    tsbsupFileChooser.setAccessory(createAccessory(OPEN_TSBSUP_ACCESSORY_TEXT));

    if(assumedTsbsupFile.canRead())
    {
      tsbsupFileChooser.setSelectedFile(assumedTsbsupFile);
    }

    if(tsbsupFileChooser.showOpenDialog(parent) == APPROVE_OPTION)
    {
      tsbsupFile = tsbsupFileChooser.getSelectedFile();
    }

    try
    {
      createAndShowNewMainFrame(new SupplementedNesFile(nesFile, tsbsupFile));
    }
    catch(Exception e)
    {
      e.printStackTrace();
      showMessageDialog(parent, "Error loading league:" + e, "Error loading",
          ERROR_MESSAGE);
      return false;
    }

    return true;
  }

  public static void openFirst()
  {
    openGivenParentWindow(null);
  }

  private void openAnother()
  {
    if(openGivenParentWindow(this))
    {
      dispose();
    }
  }

  private boolean save()
  {
    try
    {
      supplementedNesFile.writeLeague(getLeague());
      getUndoHandler().markSavePoint();
      updateTitle();
      return true;
    }
    catch(Exception e)
    {
      e.printStackTrace();
      showMessageDialog(this, "Error saving league:" + e, "Error saving",
          ERROR_MESSAGE);
      return false;
    }
  }

  static void createAndShowNewMainFrame(SupplementedNesFile newNESFile)
    throws Exception
  {
    new MainFrameCreatorAndShower(newNESFile);
  }

  private static final class MainFrameCreatorAndShower
  {
    private SupplementedNesFile newNESFile;
    private MainFrame newMainFrame;
    private Exception exception;

    private class MainFrameGUISetupRunnable implements Runnable
    {
      public void run()
      {
        try
        {
          newMainFrame = new MainFrame(newNESFile);

          /*
           * Do this here so that the reference doesn't escape from the
           * constructor.
           */
          MacApplication.addApplicationListener(newMainFrame);

          newMainFrame.setVisible(true);
        }
        catch(Exception e)
        {
          exception = e;
        }
      }
    }

    /**
     * Everything is done in the constructor.
     */
    private MainFrameCreatorAndShower(SupplementedNesFile newNESFile)
      throws Exception
    {
      this.newNESFile = newNESFile;

      Runnable mainFrameGUISetupRunnable = new MainFrameGUISetupRunnable();

      // TODO is this OK?
      if(EventQueue.isDispatchThread())
      {
        mainFrameGUISetupRunnable.run();
      }
      else
      {
        EventQueue.invokeAndWait(mainFrameGUISetupRunnable);
      }

      if(exception != null)
      {
        throw exception;
      }

      // Load some stuff in the background.
      newMainFrame.getLeagueFrame();
      // newMainFrame.createTeamFrame();
    }
  }

  public TSBTransferHandler<PlayerPanel, Player> getPlayerTransferHandler()
  {
    return playerTransferHandler;
  }

  public TSBTransferHandler<TeamPanel, Team> getTeamTransferHandler()
  {
    return teamTransferHandler;
  }

  public UserEventAggregator getUserEventAggregator()
  {
    return userEventAggregator;
  }

  public void performAndPublish(UserEvent e)
  {
    getUserEventAggregator().performAndPublish(e);
  }

  public UndoHandler getUndoHandler()
  {
    return undoHandler;
  }

  public void userEventPerformed(UserEvent e, boolean isUndoRedoEvent)
  {
    updateTitle();
  }

  private boolean isDirty()
  {
    return getUndoHandler().isDirty();
  }

  private void updateTitle()
  {
    setTitle(isDirty() ? DIRTY_WINDOW_TITLE : BASE_WINDOW_TITLE);
  }

  private static final String VERSION = "0.9";

  // TODO link to libraries and turn e-mail address into a link
  private static final String ABOUT_STRING =
      BASE_WINDOW_TITLE
          + " "
          + "("
          + "version"
          + " "
          + VERSION
          + ")"
          + "\n\n"
          + "http://twofoos.org/content/gmtsb/"
          + "\n\n"
          + "Copyright 2008 Chris Povirk"
          + "\n"
          + "beigetangerine@gmail.com"
          + "\n\n"
          + "Licensed under version 2 of the GNU GPL."
          + "\n\n"
          + "Many thanks to all those who wrote previous editors and\n"
          + "documented the file format.  Emuware's editors and bruddog's\n"
          + "documentation were particularly useful, and thanks to Jlstout123\n"
          + "and SBlueman for the location of the team run/pass ratios.\n"
          + "Thanks also to the creators of Weka, which I used to generate\n"
          + "the functions that calculate simulation codes, and to the\n"
          + "developers of the Google Collections Library and the Xerces XML\n"
          + "Parser, both of which are used by this program.";

  public void showAbout()
  {
    showMessageDialog(this, ABOUT_STRING, "About " + BASE_WINDOW_TITLE,
        INFORMATION_MESSAGE);
  }

  @Override
  public void dispose()
  {
    super.dispose();
    MacApplication.removeApplicationListener(this);
  }

  public void handleAbout()
  {
    showAbout();
  }

  public void handleOpenApplication()
  {
    // TODO Auto-generated method stub
  }

  public void handleOpenFile()
  {
    // TODO Auto-generated method stub
  }

  public void handlePreferences()
  {
  }

  public void handlePrintFile()
  {
  }

  public void handleQuit()
  {
    promptForExit();
  }

  public void handleReOpenApplication()
  {
    // TODO Auto-generated method stub
  }
}
