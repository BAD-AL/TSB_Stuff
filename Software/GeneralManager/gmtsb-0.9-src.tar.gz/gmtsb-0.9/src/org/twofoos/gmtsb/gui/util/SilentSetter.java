/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import static javax.swing.SwingUtilities.invokeLater;

import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;

public class SilentSetter
{
  private static class SilentSetterWorker implements Runnable
  {
    private final JTextComponent textComponent;
    private final String value;
    private final DocumentListener listener;

    private SilentSetterWorker(JTextComponent textComponent, String value,
        DocumentListener listener)
    {
      this.textComponent = textComponent;
      this.value = value;
      this.listener = listener;
    }

    public void run()
    {
      // This turns off listeners so that we don't cause infinite recursion.
      Document document = textComponent.getDocument();
      document.removeDocumentListener(listener);
      textComponent.setText(value);
      document.addDocumentListener(listener);
    }
  }

  public static void setTextSilent(JTextComponent textComponent, String value,
      DocumentListener listener)
  {
    // We use invokeLater() to avoid illegally modifying the field:
    // java.lang.IllegalStateException: Attempt to mutate in notification
    invokeLater(new SilentSetterWorker(textComponent, value, listener));
  }

  private SilentSetter()
  {
  }
}
