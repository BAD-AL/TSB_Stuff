/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player;

import javax.swing.ImageIcon;

import org.twofoos.gmtsb.core.Appearance;
import org.twofoos.gmtsb.gui.util.GUIUtils;

public class Faces
{
  private Faces()
  {
  }

  private static final ImageIcon[][] faces;

  static
  {
    faces = new ImageIcon[2][];
    faces[Appearance.WHITE] = new ImageIcon[Appearance.WHITE_FACE_COUNT];
    faces[Appearance.BLACK] = new ImageIcon[Appearance.BLACK_FACE_COUNT];

    for(int raceCode = 0; raceCode <= 1; raceCode++)
    {
      int shiftedRaceCode = raceCode << 7;
      for(int faceCode = 0; (raceCode == Appearance.WHITE && faceCode < Appearance.WHITE_FACE_COUNT)
          || (raceCode == Appearance.BLACK && faceCode < Appearance.BLACK_FACE_COUNT); faceCode++)
      {
        int completeCode = shiftedRaceCode | faceCode;
        String hexString = Integer.toHexString(completeCode).toUpperCase();
        if(hexString.length() == 1)
        {
          hexString = "0" + hexString;
        }
        faces[raceCode][faceCode] =
            GUIUtils.createImageIcon("faces/" + hexString + ".png");
      }
    }
  }

  public static ImageIcon getImageIcon(Appearance appearance)
  {
    return faces[appearance.getRaceCode()][appearance.getFaceCode()];
  }
}
