/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import static org.twofoos.gmtsb.gui.util.GUIUtils.resetCursor;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import javax.swing.JComboBox;

import org.twofoos.gmtsb.core.OffensiveFormation;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.OffensiveFormationChangeEvent;

public class OffensiveFormationComboBox extends JComboBox implements
    ItemListener
{
  private static final long serialVersionUID = -821807633136187998L;

  private static final Vector<OffensiveFormation> ALL_FORMATIONS =
      new Vector<OffensiveFormation>(OffensiveFormation.getAll());

  private final TeamPanel teamPanel;

  public OffensiveFormationComboBox(TeamPanel teamPanel)
  {
    super(ALL_FORMATIONS);

    this.teamPanel = teamPanel;

    setSelectedItem(teamPanel.getTeam().getOffensiveFormation());

    // Add listener after setting selected item so that we don't set it off.
    addItemListener(this);

    resetCursor(this);
  }

  private Team getTeam()
  {
    return teamPanel.getTeam();
  }

  public void performAndPublish(UserEvent e)
  {
    teamPanel.performAndPublish(e);
  }

  public void itemStateChanged(ItemEvent e)
  {
    OffensiveFormation from = getTeam().getOffensiveFormation();
    OffensiveFormation to = (OffensiveFormation) getSelectedItem();
    OffensiveFormationChangeEvent offensiveFormationChangeEvent =
        new OffensiveFormationChangeEvent(getTeam(), from, to);
    performAndPublish(offensiveFormationChangeEvent);
  }
}
