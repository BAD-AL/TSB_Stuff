/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent;

import java.util.concurrent.CopyOnWriteArraySet;

public class UserEventAggregator
{
  /*
   * Needs to be insertion-ordered to guarantee that the UndoHandler will be
   * notified before the MainMenuBar. This way, the Undo and Redo entries in the
   * menu are correct.
   */
  /*
   * TeamFrame dispose itself in its userEventPerformed() method, concurrently
   * modifying the listener set as we iterate over it. As a result, we need to
   * iterate over a snapshot. This means that any changes to the listener set
   * during the notification process will be ignored until the next event.
   * 
   * See Observable.notifyObservers(Object) for a similar discussion.
   */
  private final CopyOnWriteArraySet<UserEventListener> subscribers =
      new CopyOnWriteArraySet<UserEventListener>();

  public UserEventAggregator()
  {
  }

  public synchronized void subscribe(UserEventListener l)
  {
    subscribers.add(l);
  }

  /**
   * Returns true if the given listener was subscribed; false otherwise.
   */
  public synchronized boolean unsubscribe(UserEventListener l)
  {
    return subscribers.remove(l);
  }

  // TODO do I need to synchronize so that multiple actions aren't performed at
  // once?
  /**
   * If the UserEvent has an effect, perform it, and publish it for listeners.
   * Otherwise, do neither.
   */
  public void performAndPublish(UserEvent e)
  {
    if(e.doEvent())
    {
      publish(e, false);
    }
  }

  public void undoAndPublish(UserEvent e)
  {
    e.undoEvent();
    publish(e, true);
  }

  public void redoAndPublish(UserEvent e)
  {
    e.doEvent();
    publish(e, true);
  }

  /**
   * You should probably call performAndPublish(). It both performs the event
   * for you and publishes it only if it has an effect.
   */
  public void publish(UserEvent e)
  {
    publish(e, false);
  }

  private void publish(UserEvent e, boolean isUndoRedoEvent)
  {
    for(UserEventListener l : subscribers)
    {
      l.userEventPerformed(e, isUndoRedoEvent);
    }
  }
}
