/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.play;

import static org.twofoos.gmtsb.gui.util.GUIUtils.BUTTON_VERTICAL_INSETS;

import java.awt.event.ActionEvent;

import org.twofoos.gmtsb.gui.team.TeamDetailButton;
import org.twofoos.gmtsb.gui.team.TeamPanel;

public class PlaybookButton extends TeamDetailButton
{
  private static final long serialVersionUID = -5752051027935900633L;

  public PlaybookButton(TeamPanel teamPanel)
  {
    super(teamPanel, "Plays");
    setMargin(BUTTON_VERTICAL_INSETS);
  }

  @Override
  public void actionPerformed(ActionEvent e)
  {
    new PlaybookDialog(getMainFrame(), getTeam()).setVisible(true);
  }
}
