/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.util.iterators;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Range implements Iterable<Integer>
{
  private final int start;
  private final int end;
  private final int increment;

  private Range(int end)
  {
    this(0, end, 1);
  }

  public static Range range(int end)
  {
    return new Range(end);
  }

  public static Range range(int start, int end, int increment)
  {
    return new Range(start, end, increment);
  }

  private Range(int start, int end, int increment)
  {
    this.start = start;
    this.end = end;
    this.increment = increment;
  }

  public Iterator<Integer> iterator()
  {
    return new RangeIterator();
  }

  private class RangeIterator implements Iterator<Integer>
  {
    private int current;

    public RangeIterator()
    {
      current = start;
    }

    public boolean hasNext()
    {
      return current < end;
    }

    public Integer next()
    {
      if(!hasNext())
      {
        throw new NoSuchElementException();
      }
      int returnValue = current;
      current += increment;
      return returnValue;
    }

    public void remove()
    {
      throw new UnsupportedOperationException("remove() not supported");
    }
  }
}
