/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Iterables.concat;
import static com.google.common.collect.Iterables.limit;
import static java.util.Collections.nCopies;

import java.util.ArrayList;
import java.util.Collections;

public class Division extends ArrayList<Team>
{
  private static final long serialVersionUID = -1966353681996253029L;

  private final Conference conference;
  // TODO capitalize them all?
  private String name;
  private final int nesTeamCount;

  public Division(Conference conference, int nesTeamCount, String name)
  {
    super(5);

    this.conference = conference;
    this.name = name;
    this.nesTeamCount = nesTeamCount;
  }

  // TODO arguably this should be in SupplementedNesFile
  public Iterable<Team> nesTeams(boolean shouldPadWithDummies)
  {
    if(shouldPadWithDummies)
    {
      int dummiesNeeded = getNESTeamCount() - size();
      if(dummiesNeeded < 0)
      {
        dummiesNeeded = 0;
      }

      Team team = new Team();
      // We need a playbook to write to the file.
      team.fillPlaybookWithDefaultPlays(getConference().getLeague());

      Iterable<Team> dummies = nCopies(dummiesNeeded, team);

      Iterable<Team> thisWithDummies = concat(this, dummies);

      return limit(thisWithDummies, getNESTeamCount());
    }
    else
    {
      return limit(this, getNESTeamCount());
    }
  }

  public Iterable<Team> nonNESTeams()
  {
    int nesTeamCount = getNESTeamCount();
    if(size() <= nesTeamCount)
    {
      return Collections.emptyList();
    }

    return subList(nesTeamCount, size());
  }

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  // TODO stop using this in favor of nesTeams where possible
  public int getNESTeamCount()
  {
    return nesTeamCount;
  }

  public Conference getConference()
  {
    return conference;
  }
}
