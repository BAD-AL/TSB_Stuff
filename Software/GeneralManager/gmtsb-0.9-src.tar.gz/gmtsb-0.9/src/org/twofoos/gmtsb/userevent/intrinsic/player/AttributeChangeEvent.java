/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.intrinsic.player;

import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.AttributeValue;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.MergeableIntrinsicEvent;

public class AttributeChangeEvent extends
    MergeableIntrinsicEvent<AttributeChangeEvent, Player, AttributeValue>
{
  private final Attribute attribute;

  public AttributeChangeEvent(Player player, Attribute attribute,
      AttributeValue from, AttributeValue to, Object source)
  {
    super(player, from, to, source);
    this.attribute = attribute;
  }

  public Attribute getAttribute()
  {
    return attribute;
  }

  public String getDescription()
  {
    return "Change " + attribute.getAbbreviation() + " from "
        + getFrom().getHumanValue() + " to " + getTo().getHumanValue();
  }

  @Override
  protected UserEvent newEventForMerge(AttributeValue from, AttributeValue to)
  {
    return new AttributeChangeEvent(getSubject(), getAttribute(), from, to,
        getSource());
  }

  @Override
  protected void changeSubjectAttribute(AttributeValue value)
  {
    getSubject().setAttribute(getAttribute(), value);
  }
}
