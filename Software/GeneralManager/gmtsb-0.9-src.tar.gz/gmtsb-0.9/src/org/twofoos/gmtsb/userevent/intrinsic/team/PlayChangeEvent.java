/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.intrinsic.team;

import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.core.play.Page;
import org.twofoos.gmtsb.core.play.Play;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

public class PlayChangeEvent extends IntrinsicEvent<Team, Play>
{
  private final Page page;

  public PlayChangeEvent(Team subject, Page page, Play from, Play to)
  {
    super(subject, from, to);

    this.page = page;
  }

  @Override
  protected void changeSubjectAttribute(Play value)
  {
    getSubject().getPlaybook().put(getPage(), value);
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }

  public String getDescription()
  {
    return "Change " + getSubject() + " play page " + getPage() + " from "
        + getFrom() + " to " + getTo();
  }

  public Page getPage()
  {
    return page;
  }
}
