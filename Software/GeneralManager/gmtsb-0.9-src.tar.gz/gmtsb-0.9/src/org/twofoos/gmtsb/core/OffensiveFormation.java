/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Sets.immutableSortedSet;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeMap;

public class OffensiveFormation extends Formation
{
  private final byte positionSectionsID;
  private final byte positionLabelsID;
  private final String shortName;
  private final String supplementID;

  private static final boolean isValidByte(int i)
  {
    return ((byte) i) == i;
  }

  private static final SortedSet<Integer> OFFENSIVE_STARTING_POSITIONS_INDEXES =
      immutableSortedSet(0, 2, 3, 6, 7, 10);

  private static class OffensiveStarterIdentifier implements StarterIdentifier
  {
    private OffensiveStarterIdentifier()
    {
      // Call getInstance().
    }

    public boolean isStarter(int index)
    {
      return OFFENSIVE_STARTING_POSITIONS_INDEXES.contains(new Integer(index));
    }

    private static final OffensiveStarterIdentifier instance =
        new OffensiveStarterIdentifier();

    public static OffensiveStarterIdentifier getInstance()
    {
      return instance;
    }
  }

  public static final OffensiveFormation OFF_2RB_2WR_1TE =
      new OffensiveFormation(Arrays.asList(Slot.QB, Slot.QB, Slot.HB, Slot.FB,
          Slot.RB, Slot.RB, Slot.SE, Slot.FL, Slot.WR, Slot.WR, Slot.TE,
          Slot.TE), "Pro", "2RB_2WR_1TE", 0);

  public static final OffensiveFormation OFF_1RB_4WR_0TE =
      new OffensiveFormation(Arrays.asList(Slot.QB, Slot.QB, Slot.RB,
          Slot.LSLOT, Slot.RB, Slot.RB, Slot.LSE, Slot.RSE, Slot.RB, Slot.WR,
          Slot.RSLOT, Slot.WR), "4WR", "1RB_4WR_0TE", 1);

  public static final OffensiveFormation OFF_1RB_3WR_1TE =
      new OffensiveFormation(Arrays.asList(Slot.QB, Slot.QB, Slot.RB,
          Slot.SLOT, Slot.RB, Slot.RB, Slot.LWR, Slot.RWR, Slot.RB, Slot.WR,
          Slot.TE, Slot.TE), "3WR", "1RB_3WR_1TE", 2);

  public static final OffensiveFormation OFF_1RB_2WR_2TE =
      new OffensiveFormation(Arrays.asList(Slot.QB, Slot.QB, Slot.RB,
          Slot.LTE_SLOT, Slot.RB, Slot.RB, Slot.LWR, Slot.RWR, Slot.RB,
          Slot.WR, Slot.RTE, Slot.TE), "2TE", "1RB_2WR_2TE", 2);

  private static final Map<Byte, OffensiveFormation> FORMATION_FROM_NES_ID;
  private static final Map<String, OffensiveFormation> FORMATION_FROM_SUPPLEMENT_ID;

  private static void registerNESFormation(
      Map<Byte, OffensiveFormation> formationFromID,
      Map<String, OffensiveFormation> formationFromName,
      OffensiveFormation formation)
  {
    registerFormation(formationFromID, formationFromName, formation, false);
  }

  private static void registerFakeFormation(
      Map<Byte, OffensiveFormation> formationFromID,
      Map<String, OffensiveFormation> formationFromName,
      OffensiveFormation formation)
  {
    registerFormation(formationFromID, formationFromName, formation, true);
  }

  private static void registerFormation(
      Map<Byte, OffensiveFormation> formationFromID,
      Map<String, OffensiveFormation> formationFromName,
      OffensiveFormation formation, boolean allowDuplicateID)
  {
    registerFormation(formationFromID, formationFromName, formation, formation
        .getPositionSectionsID(), formation.getSupplementID(), allowDuplicateID);
  }

  private static void registerFormation(
      Map<Byte, OffensiveFormation> formationFromID,
      Map<String, OffensiveFormation> formationFromName,
      OffensiveFormation formation, byte id, String abbreviation,
      boolean allowDuplicateID)
  {
    if(formationFromName.containsKey(abbreviation))
    {
      // Duplicate abbreviations are never OK.
      throw new IllegalArgumentException("formation with abbreviation "
          + abbreviation + " already exists");
    }

    if(formationFromID.containsKey(id))
    {
      if(!allowDuplicateID)
      {
        throw new IllegalArgumentException("formation with ID " + id
            + " already exists");
      }
      // If we get here, then duplicates are OK, but still, we don't overwrite
      // the existing formation.
    }
    else
    {
      formationFromID.put(id, formation);
    }

    formationFromName.put(abbreviation, formation);
  }

  static
  {
    Map<Byte, OffensiveFormation> formationFromNESID =
        new TreeMap<Byte, OffensiveFormation>();
    Map<String, OffensiveFormation> formationFromSupplementID =
        new TreeMap<String, OffensiveFormation>();
    registerNESFormation(formationFromNESID, formationFromSupplementID,
        OFF_2RB_2WR_1TE);
    registerNESFormation(formationFromNESID, formationFromSupplementID,
        OFF_1RB_4WR_0TE);
    registerNESFormation(formationFromNESID, formationFromSupplementID,
        OFF_1RB_3WR_1TE);
    registerFakeFormation(formationFromNESID, formationFromSupplementID,
        OFF_1RB_2WR_2TE);
    FORMATION_FROM_NES_ID = Collections.unmodifiableMap(formationFromNESID);
    FORMATION_FROM_SUPPLEMENT_ID =
        Collections.unmodifiableMap(formationFromSupplementID);
  }

  public static Collection<OffensiveFormation> getAll()
  {
    return Collections.unmodifiableCollection(FORMATION_FROM_SUPPLEMENT_ID
        .values());
  }

  public static OffensiveFormation getFormationFromID(byte positionBothID)
  {
    return FORMATION_FROM_NES_ID.get(positionBothID);
  }

  public static OffensiveFormation getFormationFromAbbreviation(
      String abbreviation)
  {
    return FORMATION_FROM_SUPPLEMENT_ID.get(abbreviation);
  }

  // Not publically instantiable.
  private OffensiveFormation(List<Slot> slots, String shortName,
      String supplementID, int positionSectionsID, int positionLabelsID)
  {
    super(slots, OffensiveStarterIdentifier.getInstance());

    if(!isValidByte(positionLabelsID) || !isValidByte(positionSectionsID))
    {
      throw new IllegalArgumentException("positions ID is not a valid byte");
    }

    this.shortName = shortName;
    this.supplementID = supplementID;

    this.positionSectionsID = (byte) positionSectionsID;
    this.positionLabelsID = (byte) positionLabelsID;
  }

  private OffensiveFormation(List<Slot> slots, String shortName,
      String supplementID, int positionBothID)
  {
    this(slots, shortName, supplementID, positionBothID, positionBothID);
  }

  public byte getPositionSectionsID()
  {
    return positionSectionsID;
  }

  public byte getPositionLabelsID()
  {
    return positionLabelsID;
  }

  public String getSupplementID()
  {
    return supplementID;
  }

  public String getShortName()
  {
    return shortName;
  }

  @Override
  public String toString()
  {
    return getShortName();
  }

  @Override
  public int hashCode()
  {
    return supplementID.hashCode();
  }

  @Override
  public boolean equals(Object obj)
  {
    if(!(obj instanceof OffensiveFormation))
    {
      return false;
    }
    OffensiveFormation that = (OffensiveFormation) obj;
    return this.supplementID.equals(that.supplementID);
  }
}
