/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import static com.google.common.collect.Maps.newHashMap;

import java.util.Map;

import javax.swing.JComponent;

import com.apple.eawt.Application;
import com.apple.eawt.ApplicationEvent;
import com.apple.eawt.ApplicationListener;

public class MacApplication
{
  private MacApplication()
  {
  }

  public static interface Listener
  {
    public void handleAbout();

    public void handleOpenApplication();

    public void handleOpenFile();

    public void handlePreferences();

    public void handlePrintFile();

    public void handleQuit();

    public void handleReOpenApplication();
  }

  static final Delegate DELEGATE;
  static
  {
    DELEGATE = createDelegate();
  }

  private static Delegate createDelegate()
  {
    /*
     * I'd prefer to just check for the NoClassDefFoundError, but I have those
     * classes in my CLASSPATH when I run from Eclipse, and a couple minutes
     * wasn't long enough to figure out how to change that without removing them
     * altogether and screwing up compilation. Thus:
     */
    // http://java.sun.com/developer/technicalArticles/JavaLP/JavaToMac2/
    if(System.getProperty("mrj.version") == null)
    {
      return DummyDelegate.INSTANCE;
    }

    try
    {
      return MacDelegate.INSTANCE;
    }
    catch(NoClassDefFoundError notAMac)
    {
      return DummyDelegate.INSTANCE;
    }
  }

  public static void addApplicationListener(Listener listener)
  {
    DELEGATE.addApplicationListener(listener);
  }

  public static void removeApplicationListener(Listener listener)
  {
    DELEGATE.removeApplicationListener(listener);
  }

  public static boolean isMac()
  {
    // This would require Application, etc. to be loaded:
    // return DELEGATE instanceof MacDelegate;
    return !(DELEGATE instanceof DummyDelegate);
  }

  public static void formatMainWindowBrushMetalRounded(JComponent component)
  {
    /*
     * Doesn't work. Might be fixed in Mustang:
     * http://weblogs.java.net/blog/lordy/archive/2006/08/mustang_and_mac_1.html
     * 
     * Eventually the JDesktopPane should just go away, anyway.
     */
    component.getRootPane().putClientProperty("apple.awt.brushMetalRounded",
        "true");
  }

  public static void initMacLookAndFeelProperties()
  {
    /*
     * This first property is probably out of date, but just to be safe:
     * http://java.sun.com/developer/technicalArticles/JavaLP/JavaToMac/
     */
    System.setProperty("com.apple.macos.useScreenMenuBar", "true");
    System.setProperty("apple.laf.useScreenMenuBar", "true");
    /*
     * On a Mac, the resize button of TeamFrame is inaccessible because of the
     * Create Player button. Fortunately, there is a fix:
     * 
     * http://java.sun.com/developer/technicalArticles/JavaLP/JavaToMac/
     * 
     * The result doesn't actually look like that on my Mac, but it at least
     * allows you to resize windows.
     */
    System.setProperty("com.apple.mrj.application.growbox.intrudes", "false");
  }

  private static interface Delegate
  {
    public void addApplicationListener(Listener listener);

    public void removeApplicationListener(Listener listener);
  }

  private static class DummyDelegate implements Delegate
  {
    private static final DummyDelegate INSTANCE = new DummyDelegate();

    public void addApplicationListener(Listener listener)
    {
    }

    public void removeApplicationListener(Listener listener)
    {
    }
  }

  private static class MacDelegate implements Delegate
  {
    static
    {
      /*
       * Do it as soon as the class is loaded so that we fail up front and know
       * to use the dummy.
       */
      Application.getApplication();
    }

    private static final MacDelegate INSTANCE = new MacDelegate();

    private final Map<Listener, ApplicationListener> listeners = newHashMap();

    private MacDelegate()
    {
    }

    public synchronized void addApplicationListener(Listener listener)
    {
      ApplicationListener delegate = new ApplicationListenerDelegate(listener);
      listeners.put(listener, delegate);
      Application.getApplication().addApplicationListener(delegate);
    }

    public synchronized void removeApplicationListener(Listener listener)
    {
      ApplicationListener delegate = listeners.remove(listener);
      Application.getApplication().removeApplicationListener(delegate);
    }

    private static class ApplicationListenerDelegate implements
        ApplicationListener
    {
      private final Listener delegate;

      private ApplicationListenerDelegate(Listener delegate)
      {
        this.delegate = delegate;
      }

      public void handleAbout(ApplicationEvent event)
      {
        delegate.handleAbout();
        event.setHandled(true);
      }

      public void handleOpenApplication(ApplicationEvent event)
      {
        delegate.handleOpenApplication();
      }

      public void handleOpenFile(ApplicationEvent event)
      {
        delegate.handleOpenFile();
      }

      public void handlePreferences(ApplicationEvent event)
      {
        delegate.handlePreferences();
      }

      public void handlePrintFile(ApplicationEvent event)
      {
        delegate.handlePrintFile();
      }

      public void handleQuit(ApplicationEvent event)
      {
        delegate.handleQuit();
        event.setHandled(false);
      }

      public void handleReOpenApplication(ApplicationEvent event)
      {
        delegate.handleReOpenApplication();
      }
    }
  }
}
