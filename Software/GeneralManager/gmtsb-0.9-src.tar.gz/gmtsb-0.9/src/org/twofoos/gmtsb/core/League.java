/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Iterables.concat;
import static org.twofoos.gmtsb.core.Team.FULL_NAME_COMPARATOR;
import static org.twofoos.gmtsb.util.iterators.Pair.iterableWithIndexes;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.twofoos.gmtsb.core.play.Binder;
import org.twofoos.gmtsb.util.CollectionUtilities;
import org.twofoos.gmtsb.util.iterators.AbstractMapper;
import org.twofoos.gmtsb.util.iterators.Mapper;
import org.twofoos.gmtsb.util.iterators.Pair;

public class League
{
  // TODO data, creator, etc. data?

  private List<String> otherTeamRelatedStrings;
  // TODO names
  private final Conference afc = new Conference(this, AFC_NFC_Other.AFC, "AFC");
  private final Conference nfc = new Conference(this, AFC_NFC_Other.NFC, "NFC");
  private final Conference other =
      new Conference(this, AFC_NFC_Other.OTHER, "OTHER");

  private final Binder binder = new Binder(true);

  // TODO presumably could derive this from the number of divisions and their
  // sizes
  public static final int NES_TEAMS_COUNT = 28;
  public static final int NES_DIVISIONS_COUNT = 6;

  public static final int CONFERENCE_TEAM_COUNT = NES_TEAMS_COUNT / 2;

  public League()
  {
  }

  public Iterable<Division> divisions()
  {
    return CollectionUtilities.concat(afcDivisions(), nfcDivisions(),
        otherDivisions());
  }

  public Vector<Team> teamsVector()
  {
    Vector<Team> teams = new Vector<Team>(NES_TEAMS_COUNT);

    for(Division division : divisions())
    {
      teams.addAll(division);
    }

    Collections.sort(teams, FULL_NAME_COMPARATOR);

    return teams;
  }

  public int getTeamCount()
  {
    return teamsVector().size();
  }

  public Iterable<Team> teams()
  {
    return Collections.unmodifiableList(teamsVector());
  }

  public Iterable<Division> nesDivisions()
  {
    return concat(afcDivisions(), nfcDivisions());
  }

  public Iterable<Division> afcDivisions()
  {
    return afc.getDivisions();
  }

  public Iterable<Division> nfcDivisions()
  {
    return nfc.getDivisions();
  }

  private Iterable<Division> otherDivisions()
  {
    return other.getDivisions();
  }

  public Division getExtraDivision()
  {
    return otherDivisions().iterator().next();
  }

  private static class DivisionToNESTeamsMapper extends
      AbstractMapper<Division, Iterable<Team>>
  {
    private final boolean shouldPadWithDummies;

    private DivisionToNESTeamsMapper(boolean shouldPadWithDummies)
    {
      this.shouldPadWithDummies = shouldPadWithDummies;
    }

    @Override
    public Iterable<Team> apply(Division division)
    {
      return division.nesTeams(shouldPadWithDummies);
    }
  }

  private static final Mapper<Division, Iterable<Team>> DIVISION_TO_NES_TEAMS_OR_DUMMIES_MAPPER =
      new DivisionToNESTeamsMapper(true);

  private static Mapper<Division, Iterable<Team>> getDivisionToNESTeamsOrDummiesMapper()
  {
    return DIVISION_TO_NES_TEAMS_OR_DUMMIES_MAPPER;
  }

  private Iterable<Iterable<Team>> nesTeamsOrDummiesInDivisions()
  {
    return getDivisionToNESTeamsOrDummiesMapper().applyAll(nesDivisions());
  }

  public Iterable<Team> nesTeamsOrDummies()
  {
    return concat(nesTeamsOrDummiesInDivisions());
  }

  public Iterable<Pair<Team, Integer>> nesTeamsOrDummiesWithIndexes()
  {
    return iterableWithIndexes(nesTeamsOrDummies());
  }

  public Map<Team, Integer> nesTeamsOrDummiesToIndexes()
  {
    Map<Team, Integer> map = new HashMap<Team, Integer>();

    for(Pair<Team, Integer> teamAndIndex : nesTeamsOrDummiesWithIndexes())
    {
      Team team = teamAndIndex.getFirst();
      Integer index = teamAndIndex.getSecond();

      map.put(team, index);
    }

    return map;
  }

  private static class DivisionToNonNESTeamsMapper extends
      AbstractMapper<Division, Iterable<Team>>
  {
    private DivisionToNonNESTeamsMapper()
    {
    }

    @Override
    public Iterable<Team> apply(Division division)
    {
      return division.nonNESTeams();
    }
  }

  private static final Mapper<Division, Iterable<Team>> DIVISION_TO_NON_NES_TEAMS_OR_DUMMIES_MAPPER =
      new DivisionToNonNESTeamsMapper();

  private static Mapper<Division, Iterable<Team>> getDivisionToNonNESTeamsOrDummiesMapper()
  {
    return DIVISION_TO_NON_NES_TEAMS_OR_DUMMIES_MAPPER;
  }

  private Iterable<Iterable<Team>> nonNESTeamsInDivisions()
  {
    return getDivisionToNonNESTeamsOrDummiesMapper().applyAll(divisions());
  }

  public Iterable<Team> nonNESTeamsOrDummies()
  {
    return concat(nonNESTeamsInDivisions());
  }

  public Iterable<Pair<Team, Integer>> nonNESTeamsWithIndexes()
  {
    return iterableWithIndexes(nonNESTeamsOrDummies(), NES_TEAMS_COUNT);
  }

  public List<String> getOtherTeamRelatedStrings()
  {
    return otherTeamRelatedStrings;
  }

  public void setOtherTeamRelatedStrings(List<String> otherTeamRelatedStrings)
  {
    this.otherTeamRelatedStrings = otherTeamRelatedStrings;
  }

  public Conference getConference(AFC_NFC_Other afcNFCOther)
  {
    switch(afcNFCOther)
    {
      case AFC:
        return afc;

      case NFC:
        return nfc;

      case OTHER:
      default:
        return other;
    }
  }

  public Conference getAFC()
  {
    return afc;
  }

  public Conference getNFC()
  {
    return nfc;
  }

  public Iterable<Conference> getConferences()
  {
    return Arrays.asList(afc, nfc, other);
  }

  public Conference getConferenceWithTeam(Team team)
  {
    for(Conference conference : getConferences())
    {
      if(conference.containsTeam(team))
      {
        return conference;
      }
    }

    return null;
  }

  public Binder getBinder()
  {
    return binder;
  }

  private class TeamToPlayersAtPositionIterable extends
      AbstractMapper<Team, Iterable<Player>>
  {
    private final Position position;

    private TeamToPlayersAtPositionIterable(Position position)
    {
      this.position = position;
    }

    @Override
    public Iterable<Player> apply(Team input)
    {
      return input.getDepth(position);
    }
  }

  private Iterable<Iterable<Player>> iterablesOfAllPlayerAtPosition(
      Position position)
  {
    return new TeamToPlayersAtPositionIterable(position).applyAll(teams());
  }

  public Iterable<Player> getAllPlayersAtPosition(Position position)
  {
    return concat(iterablesOfAllPlayerAtPosition(position));
  }

  public Depth findPlayer(Position position, Player player)
  {
    for(Team team : concat(divisions()))
    {
      Depth depth = team.getDepth(position);
      if(depth.contains(player))
      {
        return depth;
      }
    }

    throw new IllegalArgumentException("Unknown player: " + player);
  }
}
