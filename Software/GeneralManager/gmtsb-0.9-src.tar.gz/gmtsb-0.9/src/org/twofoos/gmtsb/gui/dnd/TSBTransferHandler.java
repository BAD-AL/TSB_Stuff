/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.dnd;

import java.awt.Component;
import java.awt.Point;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.util.List;
import java.util.TooManyListenersException;

import javax.swing.JComponent;

import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.TSBDropReceiver;
import org.twofoos.gmtsb.gui.TransferablePanel;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.extrinsic.CopyEvent;
import org.twofoos.gmtsb.userevent.extrinsic.MoveEvent;
import org.twofoos.gmtsb.util.iterators.Pair;

// TODO maybe combine with parent class?
public class TSBTransferHandler<T extends TransferablePanel<D>, D extends TSBTransferableData<D>>
    extends SimpleTransferHandler implements DropTargetListener
{
  private static final long serialVersionUID = -6626229534598662676L;

  private final MainFrame mainFrame;
  private final Class<T> transferablePanelClass;
  private final Class<D> dataClass;

  protected UserEvent copyEvent;
  protected UserEvent moveEvent;
  protected UserEvent swapEvent;
  private boolean isMove;
  private boolean isSwap;
  private Component panelToDropAbove;
  private Component panelToDropBelow;
  private Component swapTarget;

  public TSBTransferHandler(Class<T> transferablePanelClass,
      Class<D> dataClass, MainFrame mainFrame)
  {
    super(createDataFlavorForClass(dataClass));

    this.transferablePanelClass = transferablePanelClass;
    this.dataClass = dataClass;

    this.mainFrame = mainFrame;
  }

  public void registerTransferHandler(JComponent component)
  {
    component.setTransferHandler(this);

    try
    {
      component.getDropTarget().addDropTargetListener(this);
    }
    catch(TooManyListenersException e)
    {
      System.err.println("Warning: Cannot show drop location preview");
    }
  }

  @Override
  public int getSourceActions(JComponent c)
  {
    TransferablePanel<? extends TSBTransferableData<?>> transferablePanel =
        transferablePanelClass.cast(c);
    TSBTransferableData<?> data = transferablePanel.getData();

    if(data.isCopyable())
    {
      return COPY_OR_MOVE;
    }
    else
    {
      return MOVE;
    }
  }

  private void performAndPublish(UserEvent e)
  {
    mainFrame.performAndPublish(e);
  }

  @Override
  protected Transferable createTransferable(JComponent c)
  {
    try
    {
      return super.createTransferable(c);
    }
    finally
    {
      copyEvent = null;
      moveEvent = null;
      isMove = false;
    }
  }

  @Override
  protected void exportDone(JComponent c, Transferable transferable, int action)
  {
    super.exportDone(c, transferable, action);

    // Events can be null; a drop on a component that won't accept input won't
    // produce events.
    // TODO clean up
    if(isSwap)
    {
      if(swapEvent != null)
      {
        performAndPublish(swapEvent);
      }
    }
    else if(isMove)
    {
      if(moveEvent != null)
      {
        performAndPublish(moveEvent);
      }
    }
    else
    {
      if(copyEvent != null)
      {
        performAndPublish(copyEvent);
      }
    }
  }

  @Override
  protected void handleImportedData(JComponent source, JComponent target,
      Object uncastData)
  {
    T fromPanel = transferablePanelClass.cast(source);
    List<D> fromList = fromPanel.getList();
    D data = dataClass.cast(uncastData);

    @SuppressWarnings("unchecked")
    TSBDropReceiver<D> dropReceiver = (TSBDropReceiver<D>) target;

    // TODO clean this up
    Pair<CopyEvent<D>, MoveEvent<D>> copyAndMoveEvents =
        dropReceiver.createCopyAndMoveEvents(fromList, data);

    isSwap = (copyAndMoveEvents == null);

    if(isSwap)
    {
      swapEvent = dropReceiver.createSwapEvent(fromList, data);
      return;
    }

    copyEvent = copyAndMoveEvents.getFirst();
    moveEvent = copyAndMoveEvents.getSecond();
  }

  @Override
  protected Object getTransferableData(JComponent c)
  {
    T fromPanel = transferablePanelClass.cast(c);
    return fromPanel.getData();
  }

  @Override
  protected void remove(JComponent source)
  {
    isMove = true;
  }

  private boolean inside = false;

  private void repaintUnlessNull(Component component)
  {
    if(component != null)
    {
      component.repaint();
    }
  }

  private void changeAndRepaintPanels(
      Pair<TransferablePanel<?>, TransferablePanel<?>> panelsToDropBetween,
      TransferablePanel<?> swapTarget)
  {
    changeAndRepaintPanels(panelsToDropBetween.getFirst(), panelsToDropBetween
        .getSecond(), swapTarget);
  }

  private void changeAndRepaintPanels(Component newPanelToDropBelow,
      Component newPanelToDropAbove, Component newSwapTarget)
  {
    Component oldPanelToDropAbove = panelToDropAbove;
    Component oldPanelToDropBelow = panelToDropBelow;
    Component oldSwapTarget = swapTarget;

    panelToDropAbove = newPanelToDropAbove;
    panelToDropBelow = newPanelToDropBelow;
    swapTarget = newSwapTarget;

    repaintUnlessNull(oldPanelToDropAbove);
    repaintUnlessNull(oldPanelToDropBelow);
    repaintUnlessNull(oldSwapTarget);

    repaintUnlessNull(panelToDropAbove);
    repaintUnlessNull(panelToDropBelow);
    repaintUnlessNull(swapTarget);
  }

  private void updateDropLocationPreview(DropTargetDragEvent dtde)
  {
    // Avoid infinite recursion.
    if(!inside)
    {
      inside = true;
      DropTargetDragEventProxy proxy = new DropTargetDragEventProxy(dtde);
      DropTarget dropTarget = (DropTarget) dtde.getSource();
      dropTarget.dragOver(proxy);
      inside = false;

      if(!proxy.isAccepted())
      {
        return;
      }

      // TODO Is there a good way to enforce that this be a TSBDropReceiver?
      TSBDropReceiver<?> component =
          (TSBDropReceiver<?>) dropTarget.getComponent();
      Point point = dtde.getLocation();

      changeAndRepaintPanels(component.getPanelsToDropBetween(point), component
          .getSwapTarget(point));
    }
  }

  public void dragEnter(DropTargetDragEvent dtde)
  {
    updateDropLocationPreview(dtde);
  }

  public void dragOver(DropTargetDragEvent dtde)
  {
    updateDropLocationPreview(dtde);
  }

  public void dropActionChanged(DropTargetDragEvent dtde)
  {
    updateDropLocationPreview(dtde);
  }

  public void dragExit(DropTargetEvent dte)
  {
    changeAndRepaintPanels(null, null, null);
  }

  public void drop(DropTargetDropEvent dtde)
  {
    changeAndRepaintPanels(null, null, null);
  }

  // The JavaDoc makes it seem like subclassing DropTargetContext is the way to
  // go. Unfortunately, that's impossible because it has only a package-visible
  // constructor.
  private static class DropTargetDragEventProxy extends DropTargetDragEvent
  {
    private static final long serialVersionUID = 5231383515239894887L;

    private final DropTargetDragEvent implementation;
    private boolean isAccepted;

    private DropTargetDragEventProxy(DropTargetDragEvent implementation)
    {
      super(implementation.getDropTargetContext(),
          implementation.getLocation(), implementation.getDropAction(),
          implementation.getSourceActions());
      this.implementation = implementation;
    }

    private boolean isAccepted()
    {
      return isAccepted;
    }

    @Override
    public void acceptDrag(int dragOperation)
    {
      implementation.acceptDrag(dragOperation);
      isAccepted = true;
    }

    @Override
    public void rejectDrag()
    {
      implementation.rejectDrag();
      isAccepted = false;
    }
  }

  public boolean isPanelToDropAbove(TransferablePanel<D> panel)
  {
    return panel == panelToDropAbove;
  }

  public boolean isPanelToDropBelow(TransferablePanel<D> panel)
  {
    return panel == panelToDropBelow;
  }

  public boolean isSwapTarget(TransferablePanel<D> panel)
  {
    return panel == swapTarget;
  }
}
