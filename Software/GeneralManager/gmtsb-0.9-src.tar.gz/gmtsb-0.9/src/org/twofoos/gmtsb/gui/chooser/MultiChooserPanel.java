/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.chooser;

import static javax.swing.BoxLayout.Y_AXIS;

import java.awt.Frame;
import java.util.List;

import javax.swing.BoxLayout;

import org.twofoos.gmtsb.util.iterators.AbstractMapper;

import com.google.common.collect.ImmutableList;

public class MultiChooserPanel<T> extends ChooserPanel<Iterable<T>>
{
  private static final long serialVersionUID = 6557985947460356472L;

  private final List<ChooserPanel<T>> chooserPanels;

  private final SelectedDataMapper<T> selectedDataMapper;

  public MultiChooserPanel(Frame chooserOwner, String title,
      Iterable<ChooserPanel<T>> chooserPanels)
  {
    super(chooserOwner, title);

    this.chooserPanels = ImmutableList.copyOf(chooserPanels);

    if(this.chooserPanels.isEmpty())
    {
      throw new IllegalArgumentException("chooserPanels is empty");
    }

    setLayout(new BoxLayout(this, Y_AXIS));

    for(ChooserPanel<T> chooserPanel : chooserPanels)
    {
      add(chooserPanel);
    }

    selectedDataMapper = new SelectedDataMapper<T>();
  }

  private static class SelectedDataMapper<T> extends
      AbstractMapper<ChooserPanel<T>, T>
  {
    private SelectedDataMapper()
    {
    }

    @Override
    public T apply(ChooserPanel<T> input)
    {
      return input.getSelectedData();
    }
  }

  protected Iterable<ChooserPanel<T>> getChooserPanels()
  {
    return chooserPanels;
  }

  @Override
  public Iterable<T> getSelectedData()
  {
    return selectedDataMapper.applyAll(getChooserPanels());
  }

  // TODO why can't this be protected (see ChooserPanel.java)?
  @Override
  public void setChooser(Chooser<?> chooser)
  {
    for(ChooserPanel<T> chooserPanel : getChooserPanels())
    {
      chooserPanel.setChooser(chooser);
    }
  }

  @Override
  public Chooser<?> getChooser()
  {
    return chooserPanels.get(0).getChooser();
  }
}
