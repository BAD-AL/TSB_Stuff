/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent;

import org.twofoos.gmtsb.core.Conference;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.ProBowlSlot;
import org.twofoos.gmtsb.core.ProBowlTeam;

public class ProBowlSlotChangeEvent implements UserEvent
{
  private final ProBowlTeam proBowlTeam;

  private final ProBowlSlot slot;
  private final Player player;

  private final ProBowlSlot oldSlot;
  private final Player oldPlayer;

  public ProBowlSlotChangeEvent(Conference conference, ProBowlSlot slot,
      Player player)
  {
    this(conference.getProBowlTeam(), slot, player);
  }

  public ProBowlSlotChangeEvent(ProBowlTeam proBowlTeam, ProBowlSlot slot,
      Player player)
  {
    this.proBowlTeam = proBowlTeam;

    this.slot = slot;
    this.player = player;

    oldSlot = proBowlTeam.getSlot(player);
    oldPlayer = proBowlTeam.getPlayer(slot);
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }

  public boolean doEvent()
  {
    if(player == oldPlayer)
    {
      return false;
    }

    proBowlTeam.clearSlot(slot);

    if(oldSlot != null)
    {
      proBowlTeam.clearSlot(oldSlot);
    }

    proBowlTeam.putPlayer(slot, player);

    if(oldSlot != null)
    {
      proBowlTeam.putPlayer(oldSlot, oldPlayer);
    }

    return true;
  }

  public String getDescription()
  {
    if(oldPlayer == null)
    {
      return "Set " + proBowlTeam.getConference() + " Pro Bowl " + slot
          + " to " + player.getFullName();
    }
    else
    {
      return "Change " + proBowlTeam.getConference() + " Pro Bowl " + slot
          + " from " + oldPlayer.getFullName() + " to " + player.getFullName();
    }
  }

  public void undoEvent()
  {
    proBowlTeam.clearSlot(slot);

    if(oldSlot != null)
    {
      proBowlTeam.clearSlot(oldSlot);
    }

    proBowlTeam.putPlayer(slot, oldPlayer);

    if(oldSlot != null)
    {
      proBowlTeam.putPlayer(oldSlot, player);
    }
  }
}
