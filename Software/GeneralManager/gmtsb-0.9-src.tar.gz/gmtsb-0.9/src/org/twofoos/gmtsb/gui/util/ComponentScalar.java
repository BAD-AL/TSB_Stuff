/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import java.awt.Component;
import java.awt.Font;
import java.util.HashMap;
import java.util.Map;

public class ComponentScalar
{
  private final float scalar;

  // Don't create a new Font each time.
  private final Map<Font, Font> fontToScaledFont;

  public ComponentScalar(float scalar)
  {
    this.scalar = scalar;
    this.fontToScaledFont = new HashMap<Font, Font>(4);
  }

  public Font scaleFont(Font oldFont)
  {
    Font newFont;

    if(fontToScaledFont.containsKey(oldFont))
    {
      newFont = fontToScaledFont.get(oldFont);
    }
    else
    {
      float oldSize = oldFont.getSize2D();
      newFont = oldFont.deriveFont(oldSize * scalar);
      fontToScaledFont.put(oldFont, newFont);
    }

    return newFont;
  }

  public <C extends Component> C scaleComponent(C component)
  {
    Font oldFont = component.getFont();

    component.setFont(scaleFont(oldFont));

    return component;
  }
}
