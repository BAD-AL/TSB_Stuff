/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import static org.twofoos.gmtsb.gui.team.LeagueFrame.scaleComponent;
import static org.twofoos.gmtsb.gui.util.GUIUtils.resetCursor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.JButton;

import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.userevent.UserEvent;

public abstract class TeamDetailButton extends JButton implements
    ActionListener
{
  private final TeamPanel teamPanel;

  protected TeamDetailButton(TeamPanel teamPanel, Icon icon)
  {
    this(teamPanel, null, icon);
  }

  protected TeamDetailButton(TeamPanel teamPanel, String text)
  {
    this(teamPanel, text, null);
  }

  protected TeamDetailButton(TeamPanel teamPanel, String text, Icon icon)
  {
    super(text, icon);
    this.teamPanel = teamPanel;
    addActionListener(this);
    resetCursor(this);
    scaleComponent(this);
  }

  protected MainFrame getMainFrame()
  {
    return teamPanel.getMainFrame();
  }

  protected Team getTeam()
  {
    return teamPanel.getTeam();
  }

  protected String getTeamName()
  {
    return getTeam().getFullName();
  }

  public void performAndPublish(UserEvent e)
  {
    getMainFrame().performAndPublish(e);
  }

  public League getLeague()
  {
    return getMainFrame().getLeague();
  }

  public abstract void actionPerformed(ActionEvent e);
}
