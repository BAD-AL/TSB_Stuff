/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player;

import org.twofoos.gmtsb.core.Depth;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.Slot;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.ListPanel;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.TransferablePanel;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.OffensiveFormationChangeEvent;

public class DepthPanel extends ListPanel<Player>
{
  private static final long serialVersionUID = -5675326709531794483L;

  DepthPanel(MainFrame mainFrame, Depth depth)
  {
    super(mainFrame, mainFrame.getPlayerTransferHandler(), depth);
  }

  @Override
  protected void initOverlays()
  {
    int index = 0;
    for(int i = 0; i < getTeam().getStarterCountForPosition(getPosition()); i++)
    {
      addOverlay(new StarterOverlay(index++));
    }
    for(int i = 0; i < getTeam().getBackupCountForPosition(getPosition()); i++)
    {
      addOverlay(new BackupOverlay(index++));
    }
  }

  public Position getPosition()
  {
    return getDepth().getPosition();
  }

  public Team getTeam()
  {
    return getDepth().getTeam();
  }

  private Slot getSlot(int index)
  {
    return getTeam().getSlotAtPosition(getPosition(), index);
  }

  public Depth getDepth()
  {
    return (Depth) getList();
  }

  public void changeDepth(Depth depth)
  {
    changeList(depth);
  }

  private abstract class PlayerOverlay extends Overlay
  {
    protected PlayerOverlay(int index)
    {
      super(getSlot(index).getSlotAbbreviation(), index);
    }

    @Override
    protected int getTransferablePanelHeight()
    {
      return TeamFrame.PLAYER_PANEL_SIZE.height;
    }
  }

  private class StarterOverlay extends PlayerOverlay
  {
    private static final long serialVersionUID = -6269865934881350173L;

    private StarterOverlay(int index)
    {
      super(index);
    }
  }

  private class BackupOverlay extends PlayerOverlay
  {
    private static final long serialVersionUID = 4200351985646447057L;

    private BackupOverlay(int index)
    {
      super(index);
      setForeground(java.awt.SystemColor.textInactiveText);
    }
  }

  @Override
  protected TransferablePanel<Player> newTransferablePanel(Player data)
  {
    return new PlayerPanel(this, data);
  }

  public void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    if(event instanceof OffensiveFormationChangeEvent)
    {
      updateOverlays();
      repaint();
    }

    // TODO might be nice to do this only for to and from for returner changes
    for(TransferablePanel<Player> transferablePanel : getTransferablePanels())
    {
      ((PlayerPanel) transferablePanel).intrinsicTeamEventPerformed(event,
          isUndoRedoEvent);
    }
  }

  // Events are delegated from TeamFrame; DepthPanel isn't actually a listener.
  public void intrinsicPlayerEventPerformed(IntrinsicEvent<Player, ?> event,
      boolean isUndoRedoEvent)
  {
    Player player = event.getSubject();

    PlayerPanel playerPanel = (PlayerPanel) findPanel(player);

    if(playerPanel == null)
    {
      // Player involved not in this frame.
      return;
    }

    playerPanel.intrinsicPlayerEventPerformed(event, isUndoRedoEvent);
  }

  public void otherEventPerformed(UserEvent event, boolean isUndoRedoEvent)
  {
    // TODO might be nice to do this only for Pro Bowl changes that affect them
    for(TransferablePanel<Player> transferablePanel : getTransferablePanels())
    {
      ((PlayerPanel) transferablePanel).otherEventPerformed(event,
          isUndoRedoEvent);
    }
  }
}
