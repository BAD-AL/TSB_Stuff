/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.gui.dnd.TSBTransferHandler;
import org.twofoos.gmtsb.userevent.extrinsic.CopyEvent;
import org.twofoos.gmtsb.userevent.extrinsic.ExtrinsicEvent;
import org.twofoos.gmtsb.userevent.extrinsic.MoveEvent;
import org.twofoos.gmtsb.userevent.extrinsic.SwapEvent;
import org.twofoos.gmtsb.util.iterators.Pair;

public abstract class ListPanel<D extends TSBTransferableData<D>> extends
    JPanel implements TSBDropReceiver<D>
{
  private final MainFrame mainFrame;
  private final List<TransferablePanel<D>> transferablePanels =
      new ArrayList<TransferablePanel<D>>(4);
  private List<D> list;

  protected ListPanel(MainFrame mainFrame,
      TSBTransferHandler<?, ?> transferHandler, List<D> list)
  {
    this.mainFrame = mainFrame;

    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

    changeList(list);

    transferHandler.registerTransferHandler(this);
  }

  public MainFrame getMainFrame()
  {
    return mainFrame;
  }

  protected int indexOfComponent(Component child)
  {
    return Arrays.asList(getComponents()).indexOf(child);
  }

  public Component getComponentBefore(Component referenceComponent)
  {
    int index = indexOfComponent(referenceComponent) - 1;

    if(index >= 0)
    {
      return getComponent(index);
    }

    return null;
  }

  public Component getComponentAfter(Component referenceComponent)
  {
    int index = indexOfComponent(referenceComponent) + 1;

    if(index < getComponentCount())
    {
      return getComponent(index);
    }

    return null;
  }

  public Component getLast()
  {
    if(getComponentCount() == 0)
    {
      return null;
    }

    return getComponent(getComponentCount() - 1);
  }

  public TransferablePanel<?> getSwapTarget(Point point)
  {
    return null;
  }

  public Pair<TransferablePanel<?>, TransferablePanel<?>> getPanelsToDropBetween(
      Point point)
  {
    return new Pair<TransferablePanel<?>, TransferablePanel<?>>(
        (TransferablePanel<?>) getLast(), null);
  }

  public SwapEvent<D> createSwapEvent(List<D> fromList, D data)
  {
    // A drop on a ListPanel is never a swap.
    return null;
  }

  public Pair<CopyEvent<D>, MoveEvent<D>> createCopyAndMoveEvents(
      List<D> fromList, D data)
  {
    CopyEvent<D> copyEvent =
        CopyEvent.createCopyToEndEvent(fromList, getList(), data);
    MoveEvent<D> moveEvent =
        MoveEvent.createMoveToEndEvent(fromList, getList(), data);
    return new Pair<CopyEvent<D>, MoveEvent<D>>(copyEvent, moveEvent);
  }

  public List<D> getList()
  {
    return list;
  }

  private void initList(List<D> list)
  {
    this.list = list;

    removeAll();
    transferablePanels.clear();

    for(D current : list)
    {
      TransferablePanel<D> transferablePanel = newTransferablePanel(current);
      transferablePanels.add(transferablePanel);
      add(transferablePanel);
    }
  }

  protected void changeList(List<D> list)
  {
    initList(list);
    updateOverlays();
  }

  protected void updateOverlays()
  {
    overlays.clear();
    initOverlays();
    registerOverlayMouseListeners();
  }

  protected void addOverlay(Overlay overlay)
  {
    overlays.add(overlay);
  }

  private final List<Overlay> overlays = new ArrayList<Overlay>(4);

  private void registerOverlayMouseListeners()
  {
    for(int i = 0; i < overlays.size() && i < getComponentCount(); i++)
    {
      TransferablePanel<?> transferablePanel =
          (TransferablePanel<?>) getComponent(i);

      Overlay overlay = overlays.get(i);
      transferablePanel.addMouseListener(overlay);
      transferablePanel.addMouseMotionListener(overlay);
    }
  }

  private static int overlayClipLength;
  private static Font monospaceFont;

  public void paintOverlayOnTransferablePanel(
      TransferablePanel<?> transferablePanel, Graphics g)
  {
    paintOverlayOnTransferablePanel(indexOfComponent(transferablePanel), g);
  }

  private void paintOverlayOnTransferablePanel(int index, Graphics g)
  {
    paintOverlay(index, g, true);
  }

  private void paintOverlayOnListPanel(int index, Graphics g)
  {
    paintOverlay(index, g, false);
  }

  private void paintOverlay(int index, Graphics g,
      boolean isRelativeToTransferablePanel)
  {
    if(index >= overlays.size())
    {
      return;
    }

    Overlay overlay = overlays.get(index);

    overlay.setBounds(overlay
        .getOverlayBoundsForSwing(isRelativeToTransferablePanel));

    Rectangle boundsForPaint =
        overlay.getOverlayBoundsForPaint(isRelativeToTransferablePanel);
    Graphics overlayGraphics =
        g.create(boundsForPaint.x, boundsForPaint.y, boundsForPaint.width,
            boundsForPaint.height);
    try
    {
      overlay.paint(overlayGraphics);
    }
    finally
    {
      overlayGraphics.dispose();
    }
  }

  protected abstract class Overlay extends JLabel implements MouseListener,
      MouseMotionListener
  {
    private static final long serialVersionUID = -3431125428212429857L;

    private boolean paintOverlay = true;
    private final int index;

    protected Overlay(String text, int index)
    {
      // TODO put some kind of padding around the text?
      super(text);
      setOpaque(true);
      setFont(getMonospaceFont());

      int oldComponentWidth = getPreferredSize().width;
      // TODO play with this color
      setBorder(BorderFactory.createCompoundBorder(BorderFactory
          .createLineBorder(SystemColor.text, 1), BorderFactory
          .createRaisedBevelBorder()));
      int newComponentWidth = getPreferredSize().width;

      int bevelBorderWidth = newComponentWidth - oldComponentWidth;
      overlayClipLength = bevelBorderWidth / 2;

      this.index = index;
    }

    private int getMaxX()
    {
      return ListPanel.this.getWidth();
    }

    private int getMinY()
    {
      return 0;
    }

    private Rectangle getOverlayBoundsForMouse(
        boolean isRelativeToTransferablePanel)
    {
      Dimension d = getPreferredSize();
      Rectangle bounds =
          new Rectangle(getMaxX() - d.width + overlayClipLength, getMinY(),
              d.width, d.height);
      if(!isRelativeToTransferablePanel)
      {
        bounds.y += getTransferablePanelHeight() * index;
      }

      return bounds;
    }

    protected abstract int getTransferablePanelHeight();

    private Rectangle getOverlayBoundsForSwing(
        boolean isRelativeToTransferablePanel)
    {
      Rectangle bounds =
          getOverlayBoundsForMouse(isRelativeToTransferablePanel);
      if(!paintOverlay)
      {
        bounds.x = getMaxX() - overlayClipLength;
      }
      return bounds;
    }

    // Fold over to side if necessary.
    private Rectangle getOverlayBoundsForPaint(
        boolean isRelativeToTransferablePanel)
    {
      Rectangle bounds =
          getOverlayBoundsForSwing(isRelativeToTransferablePanel);
      if(!paintOverlay)
      {
        bounds.width = overlayClipLength;
      }
      else
      {
        bounds.width -= overlayClipLength;
      }
      return bounds;
    }

    private void updatePaintOverlay(MouseEvent e)
    {
      updatePaintOverlay(!getOverlayBoundsForMouse(true).contains(e.getPoint()));
    }

    private void updatePaintOverlay(boolean newPaintOverlay)
    {
      boolean oldPaintOverlay = paintOverlay;
      paintOverlay = newPaintOverlay;

      if(newPaintOverlay != oldPaintOverlay)
      {
        // The overlay may hang over into the ListPanel if the user resizes the
        // frame.
        repaint();
        ListPanel.this.repaint();
        ListPanel.this.getComponent(index).repaint();
      }
    }

    public void mouseClicked(MouseEvent e)
    {
    }

    public void mousePressed(MouseEvent e)
    {
    }

    public void mouseReleased(MouseEvent e)
    {
    }

    public void mouseEntered(MouseEvent e)
    {
      updatePaintOverlay(e);
    }

    public void mouseExited(MouseEvent e)
    {
      updatePaintOverlay(true);
    }

    public void mouseDragged(MouseEvent e)
    {
      updatePaintOverlay(e);
    }

    public void mouseMoved(MouseEvent e)
    {
      updatePaintOverlay(e);
    }

    private Font getMonospaceFont()
    {
      if(monospaceFont == null)
      {
        monospaceFont =
            new Font("Monospaced", getFont().getStyle(), getFont().getSize());
      }
      return monospaceFont;
    }
  }

  void paintOverlays(Graphics g)
  {
    // Note that it is necessary to paint overlays for players/teams that exist,
    // even though they are painted by calls from TransferablePanel, for the
    // user may have enlarged the frame, moving the overlays off the
    // TransferablePanels.
    for(int i = 0; i < overlays.size(); i++)
    {
      paintOverlayOnListPanel(i, g);
    }
  }

  @Override
  public void paint(Graphics g)
  {
    super.paint(g);
    paintOverlays(g);
  }

  /**
   * Returns null if the given Player/Team doesn't appear in this
   * DepthPanel/DivisionPanel.
   */
  public TransferablePanel<D> findPanel(D data)
  {
    int index = getList().indexOf(data);
    if(index > -1)
    {
      return transferablePanels.get(index);
    }
    else
    {
      return null;
    }
  }

  protected List<TransferablePanel<D>> getTransferablePanels()
  {
    return transferablePanels;
  }

  protected abstract void initOverlays();

  protected abstract TransferablePanel<D> newTransferablePanel(D data);

  // Events are delegated from TeamFrame/LeagueFrame; ListPanel isn't actually a
  // listener.
  public void extrinsicEventPerformed(ExtrinsicEvent event,
      boolean isUndoRedoEvent)
  {
    if(event.isListAffected(getList()))
    {
      refreshList();
    }
  }

  private void refreshList()
  {
    changeList(list);
    revalidate();
    // We might have removed something.
    repaint();
  }
}
