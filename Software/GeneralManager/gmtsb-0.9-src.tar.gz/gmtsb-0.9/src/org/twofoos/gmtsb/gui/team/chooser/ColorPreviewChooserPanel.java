/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team.chooser;

import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.JLabel;

import org.twofoos.gmtsb.gui.chooser.Chooser;
import org.twofoos.gmtsb.gui.chooser.ChooserPanel;
import org.twofoos.gmtsb.gui.chooser.SelectionListener;
import org.twofoos.gmtsb.gui.util.ImageIconWithPalette;

public abstract class ColorPreviewChooserPanel<T> extends ChooserPanel<T>
{
  private static final long serialVersionUID = -6322360139894796450L;

  private final ChooserPanel<T> realChooserPanel;
  private final ImageIconWithPalette preview;
  private final JLabel previewLabel;

  protected ColorPreviewChooserPanel(ChooserPanel<T> realChooserPanel,
      Image image)
  {
    super(realChooserPanel.getChooserOwner(), realChooserPanel.getTitle());

    this.realChooserPanel = realChooserPanel;

    preview = new ImageIconWithPalette(image);
    previewLabel = new JLabel(preview);

    updatePreviewPalette();

    setLayout(new FlowLayout());

    add(realChooserPanel);
    add(previewLabel);
  }

  private class Listener implements SelectionListener
  {
    private Listener()
    {
    }

    public void selectionChanged()
    {
      updatePreviewPalette();
    }
  }

  private void updatePreviewPalette()
  {
    updatePreviewPalette(preview);
    previewLabel.repaint();
  }

  protected abstract void updatePreviewPalette(ImageIconWithPalette preview);

  @Override
  public Chooser<?> getChooser()
  {
    return realChooserPanel.getChooser();
  }

  @Override
  public T getSelectedData()
  {
    return realChooserPanel.getSelectedData();
  }

  @Override
  public void setChooser(Chooser<?> chooser)
  {
    realChooserPanel.setChooser(chooser);

    chooser.addSelectionListener(new Listener());
  }
}
