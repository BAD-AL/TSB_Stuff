/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team.chooser;

import static org.twofoos.gmtsb.util.iterators.Pair.pairIterable;

import java.awt.Frame;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.twofoos.gmtsb.core.PaletteColor;
import org.twofoos.gmtsb.gui.chooser.ChooserPanel;
import org.twofoos.gmtsb.gui.chooser.MultiChooserPanel;
import org.twofoos.gmtsb.gui.team.SpritePreviewImageIconUtil;
import org.twofoos.gmtsb.gui.util.ImageIconWithPalette;
import org.twofoos.gmtsb.util.iterators.Pair;

public class SpriteColorChooser extends
    ColorPreviewChooserPanel<Iterable<PaletteColor>>
{
  private static final long serialVersionUID = -2241358320492265308L;

  private SpriteColorChooser(Frame chooserOwner, String teamName,
      Iterable<PaletteColor> initialSpriteColors)
  {
    super(new MultiChooserPanel<PaletteColor>(chooserOwner,
        "Uniform Color Chooser - " + teamName, createChooserPanels(
            chooserOwner, initialSpriteColors)),
        SpritePreviewImageIconUtil.SPRITE_PREVIEW_IMAGE_LARGE);
  }

  private static Iterable<ChooserPanel<PaletteColor>> createChooserPanels(
      Frame chooserOwner, Iterable<PaletteColor> initialSpriteColors)
  {
    List<ChooserPanel<PaletteColor>> chooserPanels =
        new ArrayList<ChooserPanel<PaletteColor>>();

    for(Pair<PaletteColor, Iterable<PaletteColor>> initialsAndChoices : pairIterable(
        initialSpriteColors, COLOR_CHOICES_FOR_EACH_COMPONENT))
    {
      PaletteColor initialColor = initialsAndChoices.getFirst();
      Iterable<PaletteColor> colorChoices = initialsAndChoices.getSecond();

      chooserPanels.add(new ColorChooserPanel(chooserOwner, "subchooser",
          initialColor, colorChoices));
    }

    return chooserPanels;
  }

  private static final Iterable<Iterable<PaletteColor>> COLOR_CHOICES_FOR_EACH_COMPONENT;

  static
  {
    List<Iterable<PaletteColor>> colorChoicesForEachComponent =
        new ArrayList<Iterable<PaletteColor>>();
    colorChoicesForEachComponent.add(PaletteColor.getAllColors());
    colorChoicesForEachComponent.add(PaletteColor.getAllColors());
    colorChoicesForEachComponent.add(PaletteColor.getSkinColors());

    COLOR_CHOICES_FOR_EACH_COMPONENT =
        Collections.unmodifiableList(colorChoicesForEachComponent);
  }

  public static Iterable<PaletteColor> showDialog(Frame owner, String teamName,
      Iterable<PaletteColor> initialSpriteColors)
  {
    SpriteColorChooser chooser =
        new SpriteColorChooser(owner, teamName, initialSpriteColors);
    return showDialog(chooser);
  }

  @Override
  protected void updatePreviewPalette(ImageIconWithPalette preview)
  {
    SpritePreviewImageIconUtil.updateImagePalette(getSelectedData(), preview);
  }
}
