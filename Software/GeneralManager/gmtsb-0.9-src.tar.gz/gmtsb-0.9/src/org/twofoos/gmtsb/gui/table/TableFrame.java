/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.table;

import static org.twofoos.gmtsb.gui.util.SortableTableModel.sortable;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableColumnModelEvent;
import javax.swing.event.TableColumnModelListener;

import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.core.Position;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.InternalFrame;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.util.RowKeyedTable;
import org.twofoos.gmtsb.gui.util.SortableTableModel;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.extrinsic.ExtrinsicEvent;
import org.twofoos.gmtsb.userevent.intrinsic.IntrinsicEvent;

// TODO have a list like the TeamFrame list
public class TableFrame extends InternalFrame implements
    TableColumnModelListener, ActionListener
{
  private static final long serialVersionUID = 3332992547416903640L;

  private final JComboBox positionBox;
  private RowKeyedTable<Player> table;
  private PlayerTableModel tableModel;
  private JScrollPane scrollPane;

  public TableFrame(MainFrame mainFrame)
  {
    this(mainFrame, Position.QB);
  }

  public TableFrame(MainFrame mainFrame, Position position)
  {
    super(mainFrame);

    getContentPane().setLayout(new BorderLayout());
    positionBox = new JComboBox(Position.allPositionsVector());
    positionBox.addActionListener(this);
    getContentPane().add(positionBox, BorderLayout.NORTH);

    initPosition(position);

    pack();
  }

  private void initPosition(Position position)
  {
    if(getContentPane().getComponentCount() == 2)
    {
      getContentPane().remove(scrollPane);
    }

    tableModel = new PlayerTableModel(getLeague(), position, getMainFrame());

    SortableTableModel<Player> sortableTableModel = sortable(tableModel);

    table = new RowKeyedTable<Player>(sortableTableModel);

    sortableTableModel.addMouseListenerToHeaderInTable(table);

    // // TODO doesn't seem to work -- also, breaks SortableTableModel
    // table.getColumnModel().setColumnSelectionAllowed(true);
    // table.getColumnModel().addColumnModelListener(this);

    scrollPane = new JScrollPane(table);
    getContentPane().add(scrollPane, BorderLayout.CENTER);

    tableModel.initTable(table);

    setTitle();

    // Necessary on the Mac.
    revalidate();
  }

  private void setTitle()
  {
    setTitle("All Players of Position " + tableModel.getPosition());
  }

  @Override
  protected void extrinsicEventPerformed(ExtrinsicEvent event,
      boolean isUndoRedoEvent)
  {
    tableModel.possibleRowStructureChange();
  }

  @Override
  protected void intrinsicPlayerEventPerformed(IntrinsicEvent<Player, ?> event,
      boolean isUndoRedoEvent)
  {
    tableModel.playerIntrinsicUpdate(event.getSubject());
  }

  @Override
  protected void intrinsicTeamEventPerformed(IntrinsicEvent<Team, ?> event,
      boolean isUndoRedoEvent)
  {
    // A renamed team can move players, especially in an unsorted table.
    tableModel.possibleRowStructureChange();
  }

  @Override
  protected void otherEventPerformed(UserEvent event, boolean isUndoRedoEvent)
  {
  }

  public void columnAdded(TableColumnModelEvent e)
  {
  }

  public void columnMarginChanged(ChangeEvent e)
  {
  }

  public void columnMoved(TableColumnModelEvent e)
  {
  }

  public void columnRemoved(TableColumnModelEvent e)
  {
  }

  public void columnSelectionChanged(ListSelectionEvent e)
  {
    // int columnIndexes[] = table.getColumnModel().getSelectedColumns();
    // if(columnIndexes.length == 1)
    // {
    // Column column = columns.get(columnIndexes[0]);
    // }
    // TODO graph
  }

  public void actionPerformed(ActionEvent e)
  {
    initPosition((Position) positionBox.getSelectedItem());
  }
}
