/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import static com.google.common.collect.Sets.newHashSet;
import static java.awt.event.KeyEvent.VK_A;
import static java.awt.event.KeyEvent.VK_D;
import static java.awt.event.KeyEvent.VK_P;
import static java.awt.event.KeyEvent.VK_S;
import static org.twofoos.gmtsb.gui.team.SpritePreviewImageIconUtil.newSpriteImageIconWithPaletteSmall;
import static org.twofoos.gmtsb.gui.team.SpritePreviewImageIconUtil.updateImagePalette;
import static org.twofoos.gmtsb.util.iterators.Pair.pair;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Set;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import org.twofoos.gmtsb.core.League;
import org.twofoos.gmtsb.core.PaletteColor;
import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.gui.MainFrame;
import org.twofoos.gmtsb.gui.team.chooser.PlayerDataColorChooserPanel;
import org.twofoos.gmtsb.gui.team.chooser.SpriteColorChooser;
import org.twofoos.gmtsb.gui.util.GUIUtils;
import org.twofoos.gmtsb.gui.util.ImageIconWithPalette;
import org.twofoos.gmtsb.gui.util.MenuButton;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.AlternateUniformCodeChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.PlayerDataColorChangeEvent;
import org.twofoos.gmtsb.userevent.intrinsic.team.SpriteColorsChangeEvent;
import org.twofoos.gmtsb.util.iterators.Pair;

import com.google.common.base.Supplier;

public class SpriteColorsButton extends MenuButton implements ActionListener
{
  private static final long serialVersionUID = -3839240874305966174L;

  private final TeamPanel teamPanel;
  private final ImageIconWithPalette spriteIcon;

  public void updateIcon()
  {
    updateImagePalette(getTeam(), spriteIcon, 1);
    repaint();
  }

  private SpriteColorsButton(TeamPanel teamPanel,
      ImageIconWithPalette spriteIcon)
  {
    super(newIconButtonSupplier(spriteIcon), "Colors");

    this.spriteIcon = spriteIcon;
    this.teamPanel = teamPanel;
  }

  private static Supplier<JButton> newIconButtonSupplier(final Icon spriteIcon)
  {
    return new Supplier<JButton>()
    {
      public JButton get()
      {
        JButton button = new JButton(spriteIcon);
        button.setMargin(GUIUtils.BUTTON_VERTICAL_INSETS);
        return button;
      }
    };
  }

  public SpriteColorsButton(TeamPanel teamPanel)
  {
    this(teamPanel, newSpriteImageIconWithPaletteSmall(teamPanel.getTeam(), 1));
  }

  private void showPlayerDataColorPrompt()
  {
    PaletteColor result =
        PlayerDataColorChooserPanel.showDialog(getMainFrame(), getTeamName(),
            getTeam().getPlayerDataColor());

    if(result == null)
    {
      return;
    }

    performAndPublish(new PlayerDataColorChangeEvent(getTeam(), getTeam()
        .getPlayerDataColor(), result));
  }

  private void showSpriteColorsPrompt(int oneOrTwo)
  {
    Iterable<PaletteColor> result =
        SpriteColorChooser.showDialog(getMainFrame(), getTeamName(), getTeam()
            .getSpriteColors(oneOrTwo));

    if(result == null)
    {
      return;
    }

    performAndPublish(new SpriteColorsChangeEvent(getTeam(), oneOrTwo,
        getTeam().getSpriteColors(oneOrTwo), result));
  }

  private Pair<Set<Team>, Set<Team>> getExistingAlternateUniformCases()
  {
    Set<Team> thisTeamsWearsAlternateUniformVs =
        getTeam().getAlternateUniformWhenPlayingTeams();

    Set<Team> otherTeamsThatWearAlternateUniformThis = newHashSet();

    for(Team otherTeam : getLeague().teams())
    {
      if(otherTeam.getWearsAlternateUniformWhenPlayingTeam(getTeam()))
      {
        otherTeamsThatWearAlternateUniformThis.add(otherTeam);
      }
    }

    return pair(thisTeamsWearsAlternateUniformVs,
        otherTeamsThatWearAlternateUniformThis);
  }

  private void showAlternateUniformCasesPrompt()
  {
    Pair<Set<Team>, Set<Team>> result =
        new AlternateUniformCodeDialog(teamPanel).prompt();

    if(result == null)
    {
      return;
    }

    performAndPublish(new AlternateUniformCodeChangeEvent(getLeague(),
        getTeam(), getExistingAlternateUniformCases(), result));
  }

  private League getLeague()
  {
    return getMainFrame().getLeague();
  }

  protected MainFrame getMainFrame()
  {
    return teamPanel.getMainFrame();
  }

  protected Team getTeam()
  {
    return teamPanel.getTeam();
  }

  protected String getTeamName()
  {
    return getTeam().getFullName();
  }

  public void performAndPublish(UserEvent e)
  {
    getMainFrame().performAndPublish(e);
  }

  private JMenuItem createMenuItem(String name, int mnemonic)
  {
    JMenuItem item = new JMenuItem(name, mnemonic);
    item.addActionListener(this);
    return item;
  }

  private final JMenuItem primaryUniformColorsButton =
      createMenuItem("Edit Primary Uniform Colors", VK_P);;
  private final JMenuItem secondaryUniformColorsButton =
      createMenuItem("Edit Secondary Uniform Colors", VK_S);;
  private final JMenuItem playerDataColorButton =
      createMenuItem("Edit Player-Data Color", VK_D);;
  private final JMenuItem alternateUniformCasesButton =
      createMenuItem("Edit Alternate Uniform Cases", VK_A);;

  @Override
  protected void menuActivated(JMenu menu)
  {
    menu.removeAll();

    playerDataColorButton.setDisplayedMnemonicIndex(12);

    menu.add(primaryUniformColorsButton);
    menu.add(secondaryUniformColorsButton);
    menu.add(playerDataColorButton);
    menu.add(alternateUniformCasesButton);
  }

  public void actionPerformed(ActionEvent e)
  {
    Object source = e.getSource();
    if(source == primaryUniformColorsButton)
    {
      showSpriteColorsPrompt(1);
    }
    else if(source == secondaryUniformColorsButton)
    {
      showSpriteColorsPrompt(2);
    }
    else if(source == playerDataColorButton)
    {
      showPlayerDataColorPrompt();
    }
    else if(source == alternateUniformCasesButton)
    {
      showAlternateUniformCasesPrompt();
    }
  }
}
