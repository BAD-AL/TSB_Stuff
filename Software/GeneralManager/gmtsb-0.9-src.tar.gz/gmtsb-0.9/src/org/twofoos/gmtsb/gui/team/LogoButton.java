/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.team;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

import org.twofoos.gmtsb.gui.util.GUIUtils;

// TODO implement
public class LogoButton extends TeamDetailButton implements ActionListener
{
  private static final long serialVersionUID = -5986527491247361461L;

  public LogoButton(TeamPanel teamPanel)
  {
    // TODO replace with real image
    super(teamPanel, new ImageIcon()
    {
      private static final long serialVersionUID = -7263875746254497579L;

      @Override
      public int getIconHeight()
      {
        return 36;
      }

      @Override
      public int getIconWidth()
      {
        return 36;
      }
    });

    setMargin(GUIUtils.BUTTON_VERTICAL_INSETS);
    // Produces an exception apparently because we have a null icon.
    // setEnabled(false);
  }

  @Override
  public void actionPerformed(ActionEvent e)
  {
    // TODO Auto-generated method stub
  }
}
