/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.dnd;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

import javax.swing.JComponent;
import javax.swing.TransferHandler;

public abstract class SimpleTransferHandler extends TransferHandler
{
  private final DataFlavor flavor;

  private JComponent source;
  // TODO why does shouldRemove exist?
  private boolean shouldRemove;

  protected static final DataFlavor createDataFlavorForClass(Class<?> clazz)
  {
    return new DataFlavor(clazz, "GM for TSB " + clazz.getName());
  }

  protected SimpleTransferHandler(DataFlavor flavor)
  {
    super();
    this.flavor = flavor;
  }

  @Override
  public boolean canImport(JComponent c, DataFlavor[] flavors)
  {
    for(int i = 0; i < flavors.length; i++)
    {
      if(flavor.equals(flavors[i]))
      {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean importData(JComponent target, Transferable transferable)
  {
    if(canImport(target, transferable.getTransferDataFlavors()))
    {
      try
      {
        handleImportedData(source, target, transferable.getTransferData(flavor));
        return true;
      }
      catch(UnsupportedFlavorException ufe)
      {
        // TODO proper error handling
        System.err.println("importData: unsupported data flavor");
      }
      catch(IOException ioe)
      {
        System.err.println("importData: I/O exception");
      }
    }
    return false;
  }

  @Override
  protected Transferable createTransferable(JComponent c)
  {
    source = c;
    shouldRemove = true;
    return new SimpleTransferable(getTransferableData(c), flavor);
  }

  @Override
  protected void exportDone(JComponent c, Transferable transferable, int action)
  {
    if(shouldRemove && (action == MOVE))
    {
      remove(source);
    }
    source = null;
  }

  protected abstract Object getTransferableData(JComponent c);

  protected abstract void remove(JComponent source);

  protected abstract void handleImportedData(JComponent source,
      JComponent target, Object data);

  protected class SimpleTransferable implements Transferable
  {
    private final Object data;
    private final DataFlavor flavor;

    protected SimpleTransferable(Object data, DataFlavor flavor)
    {
      this.data = data;
      this.flavor = flavor;
    }

    public Object getTransferData(DataFlavor flavor)
      throws UnsupportedFlavorException
    {
      if(!isDataFlavorSupported(flavor))
      {
        throw new UnsupportedFlavorException(flavor);
      }
      return data;
    }

    public DataFlavor[] getTransferDataFlavors()
    {
      return new DataFlavor[] { flavor };
    }

    public boolean isDataFlavorSupported(DataFlavor flavor)
    {
      return this.flavor.equals(flavor);
    }
  }
}
