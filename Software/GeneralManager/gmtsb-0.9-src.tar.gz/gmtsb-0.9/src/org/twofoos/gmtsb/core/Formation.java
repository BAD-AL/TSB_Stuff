/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Multimaps.newArrayListMultimap;
import static org.twofoos.gmtsb.util.iterators.Pair.firstHalfIterable;
import static org.twofoos.gmtsb.util.iterators.Pair.iterableWithIndexes;
import static org.twofoos.gmtsb.util.iterators.Range.range;

import java.util.List;

import org.twofoos.gmtsb.util.iterators.AbstractFilter;
import org.twofoos.gmtsb.util.iterators.AbstractMapper;
import org.twofoos.gmtsb.util.iterators.Mapper;
import org.twofoos.gmtsb.util.iterators.Pair;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Multimap;

// TODO support 3-4 and 4-3?
// TODO in light of the new ways I'm using this, there's probably a better way
// to store the data
public class Formation
{
  private final List<Slot> slots;

  private final StarterIdentifier starterIdentifier;

  private final ListMultimap<Position, Slot> starterSlotsAtPosition;
  private final ListMultimap<Position, Slot> backupSlotsAtPosition;

  protected static interface StarterIdentifier
  {
    public boolean isStarter(int index);
  }

  private static class AllStarterIdentifier implements StarterIdentifier
  {
    private AllStarterIdentifier()
    {
      // Call getInstance().
    }

    public boolean isStarter(int index)
    {
      return true;
    }

    private static final AllStarterIdentifier instance =
        new AllStarterIdentifier();

    public static AllStarterIdentifier getInstance()
    {
      return instance;
    }
  }

  private Formation(List<Slot> slots)
  {
    this(slots, AllStarterIdentifier.getInstance());
  }

  // Not publicly instantiable.
  protected Formation(List<Slot> slots, StarterIdentifier starterIdentifier)
  {
    this.slots = ImmutableList.copyOf(slots);

    this.starterIdentifier = starterIdentifier;

    starterSlotsAtPosition = newArrayListMultimap();
    backupSlotsAtPosition = newArrayListMultimap();

    for(int i = 0; i < slots.size(); i++)
    {
      Slot slot = slots.get(i);

      Multimap<Position, Slot> slotsAtPosition;

      if(starterIdentifier.isStarter(i))
      {
        slotsAtPosition = starterSlotsAtPosition;
      }
      else
      {
        slotsAtPosition = backupSlotsAtPosition;
      }

      Position position = slot.getPosition();

      slotsAtPosition.put(position, slot);
    }
  }

  public int getStarterCountForPosition(Position position)
  {
    return starterSlotsAtPosition.get(position).size();
  }

  public int getBackupCountForPosition(Position position)
  {
    return backupSlotsAtPosition.get(position).size();
  }

  public int getTotalCountForPosition(Position position)
  {
    return getStarterCountForPosition(position)
        + getBackupCountForPosition(position);
  }

  public Slot getSlotAtPosition(Position position, int index)
  {
    if(index >= getStarterCountForPosition(position))
    {
      index -= getStarterCountForPosition(position);
      return backupSlotsAtPosition.get(position).get(index);
    }
    return starterSlotsAtPosition.get(position).get(index);
  }

  public Iterable<Position> rosterPositions()
  {
    return Slot.getSlotToPositionMapper().applyAll(slots);
  }

  public Iterable<Pair<Position, Integer>> rosterPositionsAndIndexes()
  {
    return iterableWithIndexes(rosterPositions());
  }

  private class StarterOrBackupAndIndexFilter extends
      AbstractFilter<Pair<Position, Integer>>
  {
    private final boolean isStarterFilter;

    private StarterOrBackupAndIndexFilter(boolean isStarterFilter)
    {
      this.isStarterFilter = isStarterFilter;
    }

    @Override
    public boolean apply(Pair<Position, Integer> input)
    {
      return starterIdentifier.isStarter(input.getSecond()) == isStarterFilter;
    }
  }

  private Iterable<Pair<Position, Integer>> starterOrBackupPositionsAndIndexes(
      boolean wantStarters)
  {
    return new StarterOrBackupAndIndexFilter(wantStarters)
        .applyAll(rosterPositionsAndIndexes());
  }

  public Iterable<Position> starterOrBackupPositions(boolean wantStarters)
  {
    return firstHalfIterable(starterOrBackupPositionsAndIndexes(wantStarters));
  }

  private static final class FormationToStarterOrBackupPositionsMapper extends
      AbstractMapper<Formation, Iterable<Position>>
  {
    private final boolean wantStarters;

    private FormationToStarterOrBackupPositionsMapper(boolean wantStarters)
    {
      this.wantStarters = wantStarters;
    }

    @Override
    public Iterable<Position> apply(Formation input)
    {
      return input.starterOrBackupPositions(wantStarters);
    }
  }

  public static Mapper<Formation, Iterable<Position>> getFormationToStarterOrBackupPositionsMapper(
      boolean wantStarters)
  {
    return new FormationToStarterOrBackupPositionsMapper(wantStarters);
  }

  private class IsStarterMapper extends AbstractMapper<Integer, Boolean>
  {
    @Override
    public Boolean apply(Integer index)
    {
      return starterIdentifier.isStarter(index);
    }
  }

  private Iterable<Boolean> getIsStarterList()
  {
    return new IsStarterMapper().applyAll(range(slots.size()));
  }

  private static final class FormationToIsStarterListMapper extends
      AbstractMapper<Formation, Iterable<Boolean>>
  {
    private FormationToIsStarterListMapper()
    {
    }

    @Override
    public Iterable<Boolean> apply(Formation input)
    {
      return input.getIsStarterList();
    }
  }

  private static final Mapper<Formation, Iterable<Boolean>> FORMATION_TO_IS_STARTER_LIST_MAPPER =
      new FormationToIsStarterListMapper();

  public static Mapper<Formation, Iterable<Boolean>> getFormationToIsStarterListMapper()
  {
    return FORMATION_TO_IS_STARTER_LIST_MAPPER;
  }

  private static final class FormationToRosterPositionsMapper extends
      AbstractMapper<Formation, Iterable<Position>>
  {
    private FormationToRosterPositionsMapper()
    {
    }

    @Override
    public Iterable<Position> apply(Formation input)
    {
      return input.rosterPositions();
    }
  }

  private static final Mapper<Formation, Iterable<Position>> FORMATION_TO_ROSTER_POSITIONS_MAPPER =
      new FormationToRosterPositionsMapper();

  public static Mapper<Formation, Iterable<Position>> getFormationToRosterPositionsMapper()
  {
    return FORMATION_TO_ROSTER_POSITIONS_MAPPER;
  }

  public static final Formation OL =
      new Formation(ImmutableList
          .of(Slot.C, Slot.LG, Slot.RG, Slot.LT, Slot.RT));

  public static final Formation DEF =
      new Formation(ImmutableList
          .of(Slot.RDE, Slot.NT, Slot.LDE, Slot.ROLB, Slot.RILB, Slot.LILB,
              Slot.LOLB, Slot.RCB, Slot.LCB, Slot.FS, Slot.SS));

  public static final Formation ST =
      new Formation(ImmutableList.of(Slot.K, Slot.P));

  public static final Formation DUMMY =
      new Formation(ImmutableList.<Slot> of());
}
