/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

import static com.google.common.collect.Maps.newHashMapWithExpectedSize;

import java.util.Map;

// TODO see if there are places to leverage the Enum-ness of this and other
// classes (using .values(), etc.)
public enum AttributeValue
{
  // Follow the lead of TSB Manager and make the last value 99.
  // This way we don't have to make the spinners three digits wide.
  _6(6), _13(13), _19(19), _25(25), _31(31), _38(38), _44(44), _50(50), _56(56), _63(
      63), _69(69), _75(75), _81(81), _88(88), _94(94), _99(99);

  private static final Map<Integer, AttributeValue> HUMAN_VALUE_TO_ATTRIBUTE_VALUE;

  private static final Map<Integer, AttributeValue> createHumanToAttributeValue()
  {
    Map<Integer, AttributeValue> humanValueToAttributeValue =
        newHashMapWithExpectedSize(values().length);

    for(AttributeValue attributeValue : values())
    {
      humanValueToAttributeValue.put(attributeValue.getHumanValue(),
          attributeValue);
    }

    return humanValueToAttributeValue;
  }

  static
  {
    HUMAN_VALUE_TO_ATTRIBUTE_VALUE = createHumanToAttributeValue();
  }

  public static int humanToComputer(Integer human)
  {
    return forHumanValue(human).getComputerValue();
  }

  public static int computerToHuman(int computer)
  {
    return forComputerValue(computer).getHumanValue();
  }

  private final int human;
  private final String toString;

  private AttributeValue(int human)
  {
    this.human = human;
    String toString = Integer.toString(getHumanValue());
    if(toString.length() == 1)
    {
      toString = '0' + toString;
    }
    this.toString = toString;
  }

  public static AttributeValue forComputerValue(int value)
  {
    return values()[value];
  }

  public static AttributeValue forHumanValue(Integer value)
  {
    return HUMAN_VALUE_TO_ATTRIBUTE_VALUE.get(value);
  }

  public int getComputerValue()
  {
    return ordinal();
  }

  public int getHumanValue()
  {
    return human;
  }

  @Override
  public String toString()
  {
    return toString;
  }
}
