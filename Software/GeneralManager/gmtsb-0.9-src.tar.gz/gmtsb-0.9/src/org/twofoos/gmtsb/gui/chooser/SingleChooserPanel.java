/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.chooser;

import static java.awt.event.ItemEvent.DESELECTED;
import static java.awt.event.ItemEvent.SELECTED;
import static javax.swing.BorderFactory.createEmptyBorder;
import static org.twofoos.gmtsb.gui.util.GUIUtils.EMPTY_INSETS;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

public abstract class SingleChooserPanel<T> extends ChooserPanel<T>
{
  private Chooser<?> chooser;
  private final ButtonGroup buttonGroup;
  private ChooserRadioButton selectedButton;

  protected SingleChooserPanel(Frame chooserOwner, String title)
  {
    super(chooserOwner, title);

    buttonGroup = new ButtonGroup();
  }

  // TODO use platform-specific? (see SystemColor)
  // private static final Color SELECTED_COLOR = new Color(57, 189,
  // 255).darker();
  // private static final Color SELECTED_COLOR = new Color(153, 153,
  // 204).darker().darker();
  private static final Color SELECTED_COLOR =
      new Color(128, 255, 0).darker().darker();
  private static final int OUTER_BORDER_THICKNESS = 2;

  private static final Border SELECTED_BORDER;
  private static final Border UNSELECTED_BORDER;

  static
  {
    Border innerBorder =
        BorderFactory.createBevelBorder(BevelBorder.LOWERED, SELECTED_COLOR,
            SELECTED_COLOR.darker().darker());
    Border outerBorder =
        BorderFactory.createLineBorder(SELECTED_COLOR, OUTER_BORDER_THICKNESS);
    SELECTED_BORDER =
        BorderFactory.createCompoundBorder(outerBorder, innerBorder);
  }

  static
  {
    Border innerBorder = BorderFactory.createBevelBorder(BevelBorder.RAISED);
    Border outerBorder =
        BorderFactory.createEmptyBorder(OUTER_BORDER_THICKNESS,
            OUTER_BORDER_THICKNESS, OUTER_BORDER_THICKNESS,
            OUTER_BORDER_THICKNESS);
    UNSELECTED_BORDER =
        BorderFactory.createCompoundBorder(outerBorder, innerBorder);
  }

  private final ChooserButtonListener chooserButtonListener =
      new ChooserButtonListener();

  private class ChooserButtonListener implements MouseListener, ItemListener
  {
    private ChooserButtonListener()
    {
    }

    public void mouseClicked(MouseEvent e)
    {
      if(e.getClickCount() == 2)
      {
        getChooser().ok();
      }
    }

    public void mousePressed(MouseEvent e)
    {
    }

    public void mouseReleased(MouseEvent e)
    {
    }

    public void mouseEntered(MouseEvent e)
    {
    }

    public void mouseExited(MouseEvent e)
    {
    }

    @SuppressWarnings("unchecked")
    private ChooserRadioButton getSource(ItemEvent e)
    {
      return (ChooserRadioButton) e.getSource();
    }

    public void itemStateChanged(ItemEvent e)
    {
      ChooserRadioButton source = getSource(e);

      if(e.getStateChange() == SELECTED)
      {
        selectedButton = source;

        notifySelectionListeners();

        source.getBorderedContainer().setBorder(SELECTED_BORDER);
      }
      else if(e.getStateChange() == DESELECTED)
      {
        source.getBorderedContainer().setBorder(UNSELECTED_BORDER);
      }
    }
  }

  // TODO and why can't this be protected?
  public abstract class ChooserRadioButton extends JRadioButton
  {
    private final T data;
    private final JPanel borderedContainer;

    protected ChooserRadioButton(T data)
    {
      this.data = data;

      /*
       * A Mac button won't show the border I set until I actually click on it.
       * Thus, we wrap the button in a JPanel, to which we have no problem
       * attaching a border.
       */

      setMargin(EMPTY_INSETS);
      setBorder(createEmptyBorder());
      setBorderPainted(false);

      borderedContainer = new JPanel();
      borderedContainer.setLayout(new BorderLayout());
      borderedContainer.add(this, BorderLayout.CENTER);

      borderedContainer.setBorder(UNSELECTED_BORDER);

      buttonGroup.add(this);

      addMouseListener(chooserButtonListener);
      addItemListener(chooserButtonListener);
    }

    protected T getData()
    {
      return data;
    }

    public JPanel getBorderedContainer()
    {
      return borderedContainer;
    }
  }

  private void notifySelectionListeners()
  {
    if(getChooser() != null)
    {
      getChooser().notifySelectionListeners();
    }
  }

  @Override
  public T getSelectedData()
  {
    return selectedButton.getData();
  }

  // TODO why can't this be protected (see ChooserPanel)?
  @Override
  public void setChooser(Chooser<?> chooser)
  {
    this.chooser = chooser;
  }

  @Override
  public Chooser<?> getChooser()
  {
    return chooser;
  }
}
