/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

// TODO also disallow non-alphanumeric characters at the beginning of the field?
// TODO limit first and last name fields together to 16 characters (including
// spaces/periods)
public class UpperCaseTextField extends JTextField
{
  private static final long serialVersionUID = -4296030549316592321L;

  public UpperCaseTextField(String text, int columns)
  {
    super(text, columns);
  }

  public UpperCaseTextField(String text)
  {
    super(text);
  }

  public UpperCaseTextField(int columns)
  {
    super(columns);
  }

  public UpperCaseTextField()
  {
    super();
  }

  @Override
  protected Document createDefaultModel()
  {
    return new UpperCaseDocument();
  }

  private class UpperCaseDocument extends PlainDocument
  {
    private static final long serialVersionUID = -6787485347318712481L;

    private UpperCaseDocument()
    {
      super();
    }

    @Override
    public void insertString(int offs, String str, AttributeSet a)
      throws BadLocationException
    {
      super.insertString(offs, str.toUpperCase(), a);
    }
  }
}
