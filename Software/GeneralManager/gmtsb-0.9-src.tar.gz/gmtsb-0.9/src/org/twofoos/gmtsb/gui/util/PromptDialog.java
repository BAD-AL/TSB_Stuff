/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

public abstract class PromptDialog<T> extends JDialog
{
  private boolean wasCancelled = false;

  public void ok()
  {
    dispose();
  }

  private void cancel()
  {
    wasCancelled = true;
    dispose();
  }

  protected PromptDialog(Frame owner, String title, Component promptPanel)
  {
    super(owner, title, true);

    JPanel buttonPanel = new JPanel();

    JButton okButton = new JButton("OK");
    okButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        ok();
      }
    });

    JButton cancelButton = new JButton("Cancel");
    cancelButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        cancel();
      }
    });

    buttonPanel.add(okButton);
    buttonPanel.add(cancelButton);

    Container contentPane = getContentPane();
    contentPane.setLayout(new BorderLayout());

    contentPane.add(promptPanel, BorderLayout.CENTER);
    contentPane.add(buttonPanel, BorderLayout.SOUTH);

    getRootPane().setDefaultButton(okButton);

    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    addWindowListener(new WindowAdapter()
    {
      @Override
      public void windowClosing(WindowEvent e)
      {
        cancel();
      }
    });
    setResizable(false);
    pack();

    setLocationRelativeTo(owner);
  }

  public T prompt()
  {
    setVisible(true);

    if(wasCancelled)
    {
      return null;
    }

    return getSelectedData();
  }

  protected abstract T getSelectedData();
}
