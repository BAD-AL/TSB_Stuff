/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import javax.swing.JTable;
import javax.swing.table.TableModel;

public class RowKeyedTable<K> extends JTable
{
  private static final long serialVersionUID = 7547538905411081450L;

  public RowKeyedTable(RowKeyedTableModel<K> tableModel)
  {
    super(tableModel);
  }

  @SuppressWarnings("unchecked")
  @Override
  public RowKeyedTableModel<K> getModel()
  {
    return (RowKeyedTableModel<K>) super.getModel();
  }

  @SuppressWarnings("cast")
  @Override
  public void setModel(TableModel dataModel)
  {
    super.setModel((RowKeyedTableModel<?>) dataModel);
  }
}
