/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.FilteredImageSource;
import java.awt.image.RGBImageFilter;

import javax.swing.Icon;
import javax.swing.ImageIcon;

public class ImageIconWithPalette implements Icon
{
  private final PaletteFilter paletteFilter;
  private final FilteredImageSource filteredImageSource;
  private final ImageIcon impl;

  public ImageIconWithPalette(Image image)
  {
    paletteFilter = new PaletteFilter();
    filteredImageSource =
        new FilteredImageSource(image.getSource(), paletteFilter);
    Image filteredImage =
        Toolkit.getDefaultToolkit().createImage(filteredImageSource);
    this.impl = new ImageIcon(filteredImage);
  }

  public void putPaletteColor(Color key, Color value)
  {
    paletteFilter.put(key.getRGB(), value.getRGB());
    updateImageFromPalette();
  }

  private void updateImageFromPalette()
  {
    // TODO it might be nice to find a better way of saying "redraw this"
    Image filteredImage =
        Toolkit.getDefaultToolkit().createImage(filteredImageSource);
    impl.setImage(filteredImage);
  }

  private static class PaletteFilter extends RGBImageFilter
  {
    private static final int COUNT = 4;
    private static final int TABLE_SIZE = COUNT * 2;

    // This takes 1/10 the time of a HashMap with autoboxing/unboxing.
    private final int[] transforms = new int[TABLE_SIZE];

    public void put(int in, int out)
    {
      for(int i = 0; i < TABLE_SIZE; i += 2)
      {
        if(transforms[i] == 0 || transforms[i] == in)
        {
          transforms[i] = in;
          transforms[i + 1] = out;
          return;
        }
      }
      throw new IllegalStateException("table full");
    }

    private PaletteFilter()
    {
    }

    @Override
    public int filterRGB(int x, int y, int rgb)
    {
      for(int i = 0; i < TABLE_SIZE; i += 2)
      {
        if(transforms[i] == rgb)
        {
          return transforms[i + 1];
        }
      }
      return rgb;
    }
  }

  public int getIconHeight()
  {
    return impl.getIconHeight();
  }

  public int getIconWidth()
  {
    return impl.getIconWidth();
  }

  public void paintIcon(Component c, Graphics g, int x, int y)
  {
    impl.paintIcon(c, g, x, y);
  }
}
