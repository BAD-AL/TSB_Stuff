/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core;

public enum RunPassRatio
{
  RUSH_HEAVY((byte) 1, "rush-heavy"), //
  RUSH_FIRST((byte) 0, "rush-first"), //
  PASS_FIRST((byte) 2, "pass-first"), //
  PASS_HEAVY((byte) 3, "pass-heavy");

  private final byte computerValue;
  private final String humanValue;

  private RunPassRatio(byte computerValue, String humanValue)
  {
    this.computerValue = computerValue;
    this.humanValue = humanValue;
  }

  @Override
  public String toString()
  {
    return humanValue;
  }

  public byte getComputerValue()
  {
    return computerValue;
  }

  public static RunPassRatio forComputerValue(int computerValue)
  {
    for(RunPassRatio ratio : values())
    {
      if(ratio.computerValue == computerValue)
      {
        return ratio;
      }
    }
    throw new IllegalArgumentException("run-pass ratio code: " + computerValue);
  }
}
