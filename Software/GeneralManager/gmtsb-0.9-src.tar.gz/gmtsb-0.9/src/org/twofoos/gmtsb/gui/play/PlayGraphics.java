/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.play;

import static org.twofoos.gmtsb.gui.util.GUIUtils.gridBagAdd;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.twofoos.gmtsb.core.Team;
import org.twofoos.gmtsb.core.play.Play;

public class PlayGraphics extends JPanel
{
  private static final long serialVersionUID = 1689069128751091038L;

  private static final JLabel newAnnotationLabel(String text)
  {
    // TODO possibly scale this down, too, if the names are too long
    JLabel label = new JLabel(text);
    label.setHorizontalAlignment(JLabel.CENTER);
    label.setOpaque(false);
    return label;
  }

  public PlayGraphics(Team team, Play play)
  {
    // TODO seems like there ought to be a simpler way of doing this
    GridBagLayout layout = new GridBagLayout();
    setLayout(layout);

    JLabel playerNameLabel =
        newAnnotationLabel(play.getBallCarrierPlayerName(team));
    JLabel playNameLabel = newAnnotationLabel(play.getName());

    JPanel graphics = new JPanel();
    graphics.setOpaque(false);
    graphics.setLayout(new GridLayout(Play.TILE_ROWS, Play.TILE_COLS));

    for(int i : play.getGraphics())
    {
      graphics.add(new JLabel(Tiles.getImageIcon(i)));
    }

    graphics.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));

    graphics.setMaximumSize(graphics.getPreferredSize());
    graphics.setMinimumSize(graphics.getPreferredSize());

    GridBagConstraints constraints = new GridBagConstraints();

    constraints.gridheight = 1;
    constraints.gridwidth = GridBagConstraints.REMAINDER;
    constraints.weightx = 1.0;
    constraints.weighty = 1.0;
    constraints.gridx = 0;
    constraints.gridy = 0;

    gridBagAdd(this, layout, constraints, playerNameLabel);

    constraints.gridheight = 1;
    constraints.gridwidth = GridBagConstraints.REMAINDER;
    constraints.weightx = 1.0;
    constraints.weighty = 1.0;
    constraints.gridx = 0;
    constraints.gridy = 2;

    gridBagAdd(this, layout, constraints, playNameLabel);

    constraints.gridheight = 1;
    constraints.gridwidth = 1;
    constraints.weightx = 0.0;
    constraints.weighty = 1.0;
    constraints.gridx = 1;
    constraints.gridy = 1;

    gridBagAdd(this, layout, constraints, graphics);
  }
}
