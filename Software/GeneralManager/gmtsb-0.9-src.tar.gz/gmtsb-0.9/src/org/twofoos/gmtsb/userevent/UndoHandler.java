/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent;

import java.util.LinkedList;

import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

public class UndoHandler implements UserEventListener
{
  private static class LinkedListStack<T> extends LinkedList<T>
  {
    private static final long serialVersionUID = -8389538530937657005L;

    public T pop()
    {
      return removeLast();
    }

    @Override
    public T peek()
    {
      return getLast();
    }

    public void push(T t)
    {
      addLast(t);
    }

    private T peekOrNull()
    {
      if(isEmpty())
      {
        return null;
      }

      return peek();
    }
  }

  // TODO may want to play with this number -- might let user adjust it
  private static final int STACK_LIMIT = 50;

  private UserEvent topOfUndoStackAtLastSave = null;

  public UndoHandler(UserEventAggregator userEventAggregator)
  {
    this.userEventAggregator = userEventAggregator;
  }

  private final UserEventAggregator userEventAggregator;

  // We want to be able to delete from the beginning when the list is too large,
  // so we use a linked list.
  private final LinkedListStack<UserEvent> undoStack =
      new LinkedListStack<UserEvent>();
  private final LinkedListStack<UserEvent> redoStack =
      new LinkedListStack<UserEvent>();

  public void userEventPerformed(UserEvent currentEvent, boolean isUndoRedoEvent)
  {
    if(isUndoRedoEvent)
    {
      return;
    }

    redoStack.clear();

    if(!undoStack.isEmpty())
    {
      UserEvent previousEvent = undoStack.peek();
      UserEvent possibleMergedEvent =
          currentEvent.attemptToMergeWithPrevious(previousEvent);

      if(possibleMergedEvent != null)
      {
        undoStack.pop();
        undoStack.push(possibleMergedEvent);
        return;
      }
    }

    undoStack.push(currentEvent);

    if(undoStack.size() > STACK_LIMIT)
    {
      undoStack.removeFirst();
    }
  }

  public boolean canUndo()
  {
    return !undoStack.isEmpty();
  }

  public boolean canRedo()
  {
    return !redoStack.isEmpty();
  }

  private void checkUndo()
  {
    if(!canUndo())
    {
      throw new CannotUndoException();
    }
  }

  private void checkRedo()
  {
    if(!canRedo())
    {
      throw new CannotRedoException();
    }
  }

  public String getEventToUndoDescription()
  {
    checkUndo();
    return undoStack.peek().getDescription();
  }

  public String getEventToRedoDescription()
  {
    checkRedo();
    return redoStack.peek().getDescription();
  }

  public void redo()
  {
    checkRedo();

    // pop() and push() before publishing so that the MainMenuBar can properly
    // update.
    UserEvent e = redoStack.pop();
    undoStack.push(e);
    userEventAggregator.redoAndPublish(e);
  }

  public void undo()
  {
    checkUndo();

    // pop() and push() before publishing so that the MainMenuBar can properly
    // update.
    UserEvent e = undoStack.pop();
    redoStack.push(e);
    userEventAggregator.undoAndPublish(e);
  }

  public void markSavePoint()
  {
    topOfUndoStackAtLastSave = undoStack.peekOrNull();
  }

  // TODO this isn't perfect, notably when dealing with name events, since they
  // are combined together to form new events
  // TODO handle special case where the user starts with an empty undo stack,
  // does more than 50 things, and then undoes them all
  public boolean isDirty()
  {
    return undoStack.peekOrNull() != topOfUndoStackAtLastSave;
  }
}
