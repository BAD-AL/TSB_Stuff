/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core.play;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Page implements Comparable<Page>
{
  private static final List<Page> PAGES;

  static
  {
    List<Page> pages = new ArrayList<Page>();

    for(int i = 0; i < Play.PAGES; i++)
    {
      pages.add(new Page(i));
    }

    PAGES = Collections.unmodifiableList(pages);
  }

  private final int index;

  private Page(int index)
  {
    this.index = index;
  }

  public RunPass getRunPass()
  {
    return (index < Play.PAGES / 2) ? RunPass.RUN : RunPass.PASS;
  }

  public boolean isRush()
  {
    return getRunPass() == RunPass.RUN;
  }

  public boolean isPass()
  {
    return getRunPass() == RunPass.PASS;
  }

  public static Collection<Page> values()
  {
    return PAGES;
  }

  public Integer getIndex()
  {
    return index;
  }

  public int compareTo(Page o)
  {
    return getIndex().compareTo(o.getIndex());
  }

  @Override
  public String toString()
  {
    return getIndex().toString();
  }
}
