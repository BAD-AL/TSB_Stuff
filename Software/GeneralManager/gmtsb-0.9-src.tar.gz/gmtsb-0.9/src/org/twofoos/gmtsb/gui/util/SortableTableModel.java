/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.util;

import static org.twofoos.gmtsb.util.SortOrder.Direction.ASCENDING;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import org.twofoos.gmtsb.util.SortOrder;
import org.twofoos.gmtsb.util.SortOrder.Direction;
import org.twofoos.gmtsb.util.SortOrder.Table;

public class SortableTableModel<K> implements TableModel, TableModelListener,
    RowKeyedTableModel<K>
{
  private final RowKeyedTableModel<K> delegate;
  @SuppressWarnings("unchecked")
  private final Table<Integer, Integer, Comparable> delegateAsTable;
  private final SortOrder<Integer, Integer> sortOrder = SortOrder.create();
  private List<Integer> rowIndexes;
  private final Vector<TableModelListener> listeners =
      new Vector<TableModelListener>();

  public static <K> SortableTableModel<K> sortable(
      RowKeyedTableModel<K> delegate)
  {
    SortableTableModel<K> returnValue = new SortableTableModel<K>(delegate);
    /*
     * We don't want the reference to escape from the constructor, so we have
     * this helper method.
     */
    // TODO I'm sure I make that mistake in other classes
    delegate.addTableModelListener(returnValue);
    return returnValue;
  }

  private SortableTableModel(RowKeyedTableModel<K> delegate)
  {
    this.delegate = delegate;
    delegateAsTable = asTable(delegate);
    updateOrder();
  }

  public void addMouseListenerToHeaderInTable(final JTable table)
  {
    table.setColumnSelectionAllowed(false);

    MouseAdapter listMouseListener = new MouseAdapter()
    {
      @Override
      public void mouseClicked(MouseEvent e)
      {
        TableColumnModel columnModel = table.getColumnModel();

        int viewColumn = columnModel.getColumnIndexAtX(e.getX());
        int column = table.convertColumnIndexToModel(viewColumn);

        if(column != -1)
        {
          Direction direction = sort(column);

          updateColumnHeaders(viewColumn, direction);

          updateOrder();

          /*
           * Necessary when the user clicks near the edge of a column header
           * (where he would click to resize).
           */
          table.getTableHeader().resizeAndRepaint();
        }
      }

      private void updateColumnHeaders(int sortViewColumn, Direction direction)
      {
        // String arrow = ascending ? "\u2191" : "\u2193"; // full arrows
        // String arrow = ascending ? "\uffea" : "\uffec"; // shorter arrows;
        // N/A
        // String arrow = ascending ? "\u2303" : "\u2304"; // carets; N/A
        // String arrow = ascending ? "\u25b4" : "\u25be"; // great, but N/A
        String arrow = direction == ASCENDING ? "\u25b2" : "\u25bc";

        for(int viewColumn = 0; viewColumn < getColumnCount(); viewColumn++)
        {
          String name =
              getColumnName(table.convertColumnIndexToModel(viewColumn));

          if(viewColumn == sortViewColumn)
          {
            name += arrow;
          }

          table.getColumnModel().getColumn(viewColumn).setHeaderValue(name);
        }
      }
    };

    JTableHeader th = table.getTableHeader();
    th.addMouseListener(listMouseListener);
  }

  public void addTableModelListener(TableModelListener l)
  {
    listeners.add(l);
  }

  public Class<?> getColumnClass(int columnIndex)
  {
    return delegate.getColumnClass(columnIndex);
  }

  public int getColumnCount()
  {
    return delegate.getColumnCount();
  }

  public String getColumnName(int columnIndex)
  {
    return delegate.getColumnName(columnIndex);
  }

  public int getRowCount()
  {
    return delegate.getRowCount();
  }

  public Object getValueAt(int rowIndex, int columnIndex)
  {
    return delegate.getValueAt(translateRow(rowIndex), columnIndex);
  }

  public boolean isCellEditable(int rowIndex, int columnIndex)
  {
    return delegate.isCellEditable(translateRow(rowIndex), columnIndex);
  }

  public void removeTableModelListener(TableModelListener l)
  {
    listeners.remove(l);
  }

  public void setValueAt(Object value, int rowIndex, int columnIndex)
  {
    delegate.setValueAt(value, translateRow(rowIndex), columnIndex);
  }

  private static final TableModelListener[] TO_TABLE_MODEL_LISTENER_ARRAY =
      new TableModelListener[0];

  public final void tableChanged(TableModelEvent unused)
  {
    updateOrder();
  }

  private void fireTableChanged()
  {
    TableModelEvent everythingChangedEvent = new TableModelEvent(this);

    // Copy to avoid concurrent modification.
    for(TableModelListener l : listeners.toArray(TO_TABLE_MODEL_LISTENER_ARRAY))
    {
      l.tableChanged(everythingChangedEvent);
    }
  }

  private synchronized Direction sort(int column)
  {
    return sortOrder.sorted(column);
  }

  private synchronized int translateRow(int rowIndex)
  {
    return rowIndexes.get(rowIndex);
  }

  @SuppressWarnings("unchecked")
  private void updateOrder()
  {
    synchronized(this)
    {
      rowIndexes = createUnsortedRowIndexes();
      sortOrder.sort(rowIndexes, delegateAsTable);
    }

    fireTableChanged();
  }

  private List<Integer> createUnsortedRowIndexes()
  {
    int rows = delegate.getRowCount();
    List<Integer> rowIndexes = new ArrayList<Integer>(rows);
    for(int i = 0; i < rows; i++)
    {
      rowIndexes.add(i);
    }
    return rowIndexes;
  }

  @SuppressWarnings("unchecked")
  private static Table<Integer, Integer, Comparable> asTable(
      final TableModel tableModel)
  {
    return new Table<Integer, Integer, Comparable>()
    {
      public Comparable get(Integer rowIndex, Integer columnIndex)
      {
        return (Comparable) tableModel.getValueAt(rowIndex, columnIndex);
      }
    };
  }

  public K getRowKey(int rowIndex)
  {
    return delegate.getRowKey(translateRow(rowIndex));
  }
}
