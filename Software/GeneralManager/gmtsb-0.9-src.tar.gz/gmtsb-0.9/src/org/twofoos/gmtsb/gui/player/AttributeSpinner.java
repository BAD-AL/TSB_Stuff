/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.gui.player;

import static org.twofoos.gmtsb.gui.util.GUIUtils.resetCursor;

import java.util.List;

import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.twofoos.gmtsb.core.Attribute;
import org.twofoos.gmtsb.core.AttributeValue;
import org.twofoos.gmtsb.core.Player;
import org.twofoos.gmtsb.userevent.UserEvent;
import org.twofoos.gmtsb.userevent.intrinsic.player.AttributeChangeEvent;

import com.google.common.collect.ImmutableList;

// If autocompletion of "6" to "63" is annoying, just type "06."
public class AttributeSpinner extends JSpinner implements ChangeListener
{
  private static final long serialVersionUID = -9086998920846302165L;

  private static final List<AttributeValue> ATTRIBUTE_VALUES =
      ImmutableList.of(AttributeValue.values());

  private static class AttributeSpinnerModel extends SpinnerListModel
  {
    private static final long serialVersionUID = 2366737677688054896L;

    private AttributeSpinnerModel()
    {
      super(ATTRIBUTE_VALUES);
    }
  }

  private final PlayerPanel playerPanel;
  private final Attribute attribute;

  public AttributeSpinner(PlayerPanel playerPanel, Attribute attribute)
  {
    super(new AttributeSpinnerModel());

    this.playerPanel = playerPanel;
    this.attribute = attribute;

    AttributeValue currentAttributeValue =
        playerPanel.getPlayer().getAttribute(attribute);
    setValue(currentAttributeValue);
    // Add ChangeListener after setting value so as not to set it off.
    addChangeListener(this);

    resetCursor(this);
  }

  private static void throwSetValueException(Object elt)
  {
    throw new IllegalArgumentException(elt + ": invalid sequence element");
  }

  @Override
  public void setValue(Object elt)
  {
    if(elt instanceof AttributeValue)
    {
      super.setValue(elt);
    }
    else if(elt instanceof String)
    {
      int humanValue = 0;

      try
      {
        humanValue = Integer.parseInt((String) elt);
      }
      catch(NumberFormatException e)
      {
        throwSetValueException(elt);
      }

      int i;
      // Don't go past the end of the array. If it's greater than 94, then it's
      // 100 (or 99 for our purposes -- see AttributeValue).
      for(i = 0; i < ATTRIBUTE_VALUES.size() - 1; i++)
      {
        if(humanValue <= AttributeValue.computerToHuman(i))
        {
          break;
        }
      }

      setValue(AttributeValue.forComputerValue(i));
    }
    else
    {
      throwSetValueException(elt);
    }
  }

  private Player getPlayer()
  {
    return playerPanel.getPlayer();
  }

  public void performAndPublish(UserEvent e)
  {
    playerPanel.performAndPublish(e);
  }

  public void stateChanged(ChangeEvent jSpinnerChangeEvent)
  {
    AttributeValue from = getPlayer().getAttribute(attribute);
    AttributeValue to = (AttributeValue) getValue();
    AttributeChangeEvent attributeChangeEvent =
        new AttributeChangeEvent(getPlayer(), attribute, from, to,
            jSpinnerChangeEvent.getSource());
    performAndPublish(attributeChangeEvent);
  }
}
