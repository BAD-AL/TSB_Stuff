/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.core.play;

import static com.google.common.collect.Iterables.concat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

public class Binder
{
  private final SortedMap<Page, List<Play>> PAGES;

  public Binder()
  {
    this(false);
  }

  public Binder(boolean makeDummyPlays)
  {
    SortedMap<Page, List<Play>> pages = new TreeMap<Page, List<Play>>();

    for(Page page : Page.values())
    {
      List<Play> plays = new ArrayList<Play>();

      pages.put(page, plays);

      RunPass runPass = page.getRunPass();

      if(makeDummyPlays)
      {
        for(int j = 0; j < Play.PLAYS_PER_PAGE; j++)
        {
          plays.add(new Play(runPass));
        }
      }
    }

    PAGES = Collections.unmodifiableSortedMap(pages);
  }

  public List<Play> getPlaysByPage(Page page)
  {
    return PAGES.get(page);
  }

  public Iterable<Play> getAllPlays()
  {
    return concat(PAGES.values());
  }

  public int indexOfPlayInPage(Page page, Play play)
  {
    return getPlaysByPage(page).indexOf(play);
  }
}
