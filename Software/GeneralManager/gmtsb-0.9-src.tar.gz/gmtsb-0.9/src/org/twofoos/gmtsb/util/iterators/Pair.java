/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.util.iterators;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Pair<A, B>
{
  private final A a;
  private final B b;

  public Pair(A a, B b)
  {
    this.a = a;
    this.b = b;
  }

  public A getFirst()
  {
    return a;
  }

  public B getSecond()
  {
    return b;
  }

  private static boolean bothNullOrEqual(Object o1, Object o2)
  {
    return (o1 == null) ? (o2 == null) : o1.equals(o2);
  }

  private static int hashCodeOrZero(Object o)
  {
    return (o == null) ? 0 : o.hashCode();
  }

  @Override
  public boolean equals(Object o)
  {
    if(!(o instanceof Pair))
    {
      return false;
    }

    Pair<?, ?> other = (Pair<?, ?>) o;

    return bothNullOrEqual(this.getFirst(), other.getFirst())
        && bothNullOrEqual(this.getSecond(), other.getSecond());
  }

  @Override
  public int hashCode()
  {
    return hashCodeOrZero(getFirst()) << 16 ^ hashCodeOrZero(getSecond());
  }

  public static <A, B> Pair<A, B> pair(A a, B b)
  {
    return new Pair<A, B>(a, b);
  }

  private static class PairIterator<A, B> implements Iterator<Pair<A, B>>
  {
    private final Iterator<A> aIterator;
    private final Iterator<B> bIterator;

    private PairIterator(Iterator<A> aIterator, Iterator<B> bIterator)
    {
      this.aIterator = aIterator;
      this.bIterator = bIterator;
    }

    public boolean hasNext()
    {
      return aIterator.hasNext() && bIterator.hasNext();
    }

    public Pair<A, B> next()
    {
      return new Pair<A, B>(aIterator.next(), bIterator.next());
    }

    public void remove()
    {
      throw new UnsupportedOperationException("remove() not supported");
    }
  }

  private static class PairIterable<A, B> implements Iterable<Pair<A, B>>
  {
    private final Iterable<A> aIterable;
    private final Iterable<B> bIterable;

    public PairIterable(Iterable<A> aIterable, Iterable<B> bIterable)
    {
      this.aIterable = aIterable;
      this.bIterable = bIterable;
    }

    public Iterator<Pair<A, B>> iterator()
    {
      return new PairIterator<A, B>(aIterable.iterator(), bIterable.iterator());
    }
  }

  public static <A, B> Iterable<Pair<A, B>> pairIterable(Iterable<A> aIterable,
      Iterable<B> bIterable)
  {
    return new PairIterable<A, B>(aIterable, bIterable);
  }

  private static class IteratorWithIndexes<T> implements
      Iterator<Pair<T, Integer>>
  {
    private final Iterator<T> iterator;
    private int nextIndex;

    private IteratorWithIndexes(Iterator<T> iterator, int firstIndex)
    {
      this.iterator = iterator;
      this.nextIndex = firstIndex;
    }

    public boolean hasNext()
    {
      return iterator.hasNext();
    }

    public Pair<T, Integer> next()
    {
      if(!hasNext())
      {
        throw new NoSuchElementException();
      }

      try
      {
        return new Pair<T, Integer>(iterator.next(), nextIndex);
      }
      finally
      {
        nextIndex++;
      }
    }

    public void remove()
    {
      iterator.remove();
    }
  }

  private static class IterableWithIndexes<T> implements
      Iterable<Pair<T, Integer>>
  {
    private final Iterable<T> iterable;
    private final int firstIndex;

    private IterableWithIndexes(Iterable<T> iterable, int firstIndex)
    {
      this.iterable = iterable;
      this.firstIndex = firstIndex;
    }

    public Iterator<Pair<T, Integer>> iterator()
    {
      return new IteratorWithIndexes<T>(iterable.iterator(), firstIndex);
    }
  }

  public static <T> Iterable<Pair<T, Integer>> iterableWithIndexes(
      Iterable<T> iterable)
  {
    return new IterableWithIndexes<T>(iterable, 0);
  }

  public static <T> Iterable<Pair<T, Integer>> iterableWithIndexes(
      Iterable<T> iterable, int firstIndex)
  {
    return new IterableWithIndexes<T>(iterable, firstIndex);
  }

  // TODO I feel like I should be able to get away with Pair<T, ?>, but I can't
  private static class FirstHalfIterable<T, X> extends
      AbstractMapper<Pair<T, X>, T>
  {
    @Override
    public T apply(Pair<T, X> input)
    {
      return input.getFirst();
    }
  }

  public static <T, X> Iterable<T> firstHalfIterable(
      Iterable<Pair<T, X>> pairIterable)
  {
    return new FirstHalfIterable<T, X>().applyAll(pairIterable);
  }

  // TODO SecondHalfIterable and associated public method

  @Override
  public String toString()
  {
    return "<" + a + ", " + b + ">";
  }
}
