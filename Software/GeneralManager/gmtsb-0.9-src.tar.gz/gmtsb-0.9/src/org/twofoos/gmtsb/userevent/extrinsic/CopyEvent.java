/*
 * Copyright 2008 Chris Povirk
 * 
 * This file is part of General Manager for Tecmo Super Bowl.
 * 
 * General Manager for Tecmo Super Bowl is free software: you can redistribute
 * it and/or modify it under the terms of version 2 of the GNU General Public
 * License as published by the Free Software Foundation.
 * 
 * General Manager for Tecmo Super Bowl is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * General Manager for Tecmo Super Bowl. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package org.twofoos.gmtsb.userevent.extrinsic;

import java.util.List;

import org.twofoos.gmtsb.core.Division;
import org.twofoos.gmtsb.core.IncompatiblePositionsException;
import org.twofoos.gmtsb.core.TSBTransferableData;
import org.twofoos.gmtsb.userevent.UserEvent;

public class CopyEvent<D extends TSBTransferableData<D>> extends ExtrinsicEvent
{
  private final List<D> fromList;
  private final List<D> toList;
  private final int fromIndex;
  private final int toIndex;
  private final String name;

  private CopyEvent(List<D> fromList, List<D> toList, int fromIndex, int toIndex)
  {
    this.fromList = fromList;
    this.toList = toList;
    this.fromIndex = fromIndex;
    this.toIndex = toIndex;
    this.name = fromList.get(fromIndex).toString();
  }

  public static <D extends TSBTransferableData<D>> CopyEvent<D> createCopyEvent(
      List<D> fromList, List<D> toList, int fromIndex, int toIndex)
  {
    return new CopyEvent<D>(fromList, toList, fromIndex, toIndex);
  }

  public boolean doEvent() throws IncompatiblePositionsException
  {
    // See note at testPositionCompatibility() method.
    possiblyTestDepthPositionCompatibility(fromList, toList);

    D data = fromList.get(fromIndex);
    toList.add(toIndex, data.copyOrSelfIfCopyNotSupported());

    return true;
  }

  public void undoEvent()
  {
    toList.remove(toIndex);
  }

  public static <D extends TSBTransferableData<D>> CopyEvent<D> createCopyToBeforeEvent(
      List<D> fromList, List<D> toList, D data, D before)
  {
    return new CopyEvent<D>(fromList, toList, fromList.indexOf(data), toList
        .indexOf(before));
  }

  public static <D extends TSBTransferableData<D>> CopyEvent<D> createCopyToAfterEvent(
      List<D> fromList, List<D> toList, D data, D after)
  {
    return new CopyEvent<D>(fromList, toList, fromList.indexOf(data), toList
        .indexOf(after) + 1);
  }

  public static <D extends TSBTransferableData<D>> CopyEvent<D> createCopyToEndEvent(
      List<D> fromList, List<D> toList, D data)
  {
    return new CopyEvent<D>(fromList, toList, fromList.indexOf(data), toList
        .size());
  }

  public String getDescription()
  {
    return "Copy " + name;
  }

  @Override
  public boolean isListAffected(List<?> list)
  {
    return list == fromList || list == toList;
  }

  public List<D> getFromList()
  {
    return fromList;
  }

  public List<D> getToList()
  {
    return toList;
  }

  public int getFromIndex()
  {
    return fromIndex;
  }

  public int getToIndex()
  {
    return toIndex;
  }

  public UserEvent attemptToMergeWithPrevious(UserEvent otherEvent)
  {
    return null;
  }

  // javac rejects without the cast
  @SuppressWarnings("cast")
  @Override
  public boolean isTeamEvent()
  {
    return (Object) fromList instanceof Division;
  }
}
