----------------------------------------------------------------------
- Tecmo Super Bowl III Manger | Version 1.0302                       -
------------------------------+---------------------------------------
- Brought by The Flash, 1999  | flash@emuware.com                    -
------------------------------+---------------------------------------
- Flash EmuWare Services      | http://flash.emuware.com             -
======================================================================

 Here is Flash EmuWare's third manager, and its better than ever. 
 Check it out, we are sure that you will find it useful! Stop in at
 http://agd.emuware.com or drop The Flash a line at flash@emuware.com

 Having trouble? Post a message on The Flash message board. 
 Find Bugs? Send them to flash@emuware.com! 

 __________
/ Features \__________________________________________________________

 o Can Edit All Teams, Including Free Agents and Great Players
   - City 
   - Team Name
   - Default Playbooks
   - Starting Returners
   - Rosters
 o Can Edit Players
   - Name
   - Attributes
   - Skin Color
 o Manager Options
   - Trade Players
   - Adjust the Free Agency Points
   - Scramble Players
   - Edit the Schedule 	-------===========================*** NEW 
 o Can Individual Leaders
   - Sort by any Attribute
   - Sort by Multiple Attributes
 o Can Export to Other Games
   - Tecmo Bowl (NES) 
     = Team Names
     = Team Rosters
     = Player Names
   - Tecmo Super Bowl (NES) 
     = Team Names
     = Team Rosters
     = Player Names
     = Player Attributes

 _________________
/ Release History \___________________________________________________

 Version 1.0302
 --------------
 o Schedule Editor Added - thanks to Dalamar for the info

 Version 1.0220
 --------------
 o First Public Release

 _________
/ Credits \___________________________________________________________

 The following people have helped make TSB3m in some fashion, great or
small:

 o The Flash:     Programmer and Lead Hacker
 o SixMan:        Beta Tester, Idea Maker, and overall Motivator
 o Dalamar:       Miscellaneous Information Getter
 o The MadHacker: Tutor for hacking the NES Tecmo Super Bowl

 Thanks to www.zophar.net, www.retrogames.com, and 
www.vintagegaming.com for posting news regarding to Flash EmuWare 
releases! 